import {
  boolean,
  customType,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

const bytea = customType<{ data: Buffer; driverData: Buffer }>({
  dataType() {
    return "bytea";
  },
});

const ts = (name: string) => timestamp(name, { withTimezone: true, mode: "date" });

/** Academic departments. List-like fields are stored one item per line so they are easy to edit. */
export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  code: text("code").notNull(),
  name: text("name").notNull(),
  nameBn: text("name_bn").notNull().default(""),
  tagline: text("tagline").notNull().default(""),
  overview: text("overview").notNull().default(""),
  image: text("image").notNull().default(""),
  programs: text("programs").notNull().default(""),
  curriculum: text("curriculum").notNull().default(""),
  labs: text("labs").notNull().default(""),
  research: text("research").notNull().default(""),
  publications: text("publications").notNull().default(""),
  email: text("email").notNull().default(""),
  phone: text("phone").notNull().default(""),
  office: text("office").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
  updatedAt: ts("updated_at").notNull().defaultNow(),
});

export const faculty = pgTable(
  "faculty",
  {
    id: serial("id").primaryKey(),
    departmentSlug: text("department_slug").notNull(),
    name: text("name").notNull(),
    designation: text("designation").notNull().default(""),
    email: text("email").notNull().default(""),
    phone: text("phone").notNull().default(""),
    researchInterests: text("research_interests").notNull().default(""),
    isPlaceholder: boolean("is_placeholder").notNull().default(false),
    sortOrder: integer("sort_order").notNull().default(0),
  },
  (t) => [index("faculty_department_idx").on(t.departmentSlug)],
);

/** Uploaded binary files (PDF attachments). */
export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  mime: text("mime").notNull(),
  size: integer("size").notNull(),
  data: bytea("data").notNull(),
  createdAt: ts("created_at").notNull().defaultNow(),
});

export const notices = pgTable(
  "notices",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    category: text("category").notNull(),
    summary: text("summary").notNull().default(""),
    body: text("body").notNull().default(""),
    publishedAt: ts("published_at").notNull().defaultNow(),
    fileId: integer("file_id"),
    fileName: text("file_name").notNull().default(""),
    pinned: boolean("pinned").notNull().default(false),
    isSample: boolean("is_sample").notNull().default(false),
  },
  (t) => [index("notices_published_idx").on(t.publishedAt), index("notices_category_idx").on(t.category)],
);

export const news = pgTable("news", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull().default(""),
  body: text("body").notNull().default(""),
  image: text("image").notNull().default(""),
  publishedAt: ts("published_at").notNull().defaultNow(),
  isSample: boolean("is_sample").notNull().default(false),
});

export const events = pgTable(
  "events",
  {
    id: serial("id").primaryKey(),
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    location: text("location").notNull().default(""),
    category: text("category").notNull().default("university"),
    startsAt: ts("starts_at").notNull(),
    endsAt: ts("ends_at"),
    isSample: boolean("is_sample").notNull().default(false),
  },
  (t) => [index("events_starts_idx").on(t.startsAt)],
);

/** Editable content blocks used across the public site. */
export const siteContent = pgTable("site_content", {
  key: text("key").primaryKey(),
  label: text("label").notNull(),
  section: text("section").notNull().default("General"),
  help: text("help").notNull().default(""),
  value: text("value").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
  updatedAt: ts("updated_at").notNull().defaultNow(),
});

/** "University at a glance" figures. A null value renders as an "awaiting verification" placeholder. */
export const stats = pgTable("stats", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  label: text("label").notNull(),
  labelBn: text("label_bn").notNull().default(""),
  value: integer("value"),
  suffix: text("suffix").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const admissionItems = pgTable("admission_items", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull(), // circular | requirement | guideline | date | result | faq
  level: text("level").notNull().default("general"), // undergraduate | postgraduate | general
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  dateText: text("date_text").notNull().default(""),
  fileId: integer("file_id"),
  fileName: text("file_name").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
  isSample: boolean("is_sample").notNull().default(false),
});

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  category: text("category").notNull().default("General"),
  description: text("description").notNull().default(""),
  fileId: integer("file_id"),
  fileName: text("file_name").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
  isSample: boolean("is_sample").notNull().default(false),
});

/** Messages submitted through the public contact form. */
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull().default(""),
  message: text("message").notNull(),
  createdAt: ts("created_at").notNull().defaultNow(),
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  role: text("role").notNull(), // admin | student
  identifier: text("identifier").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  departmentSlug: text("department_slug").notNull().default(""),
  isDemo: boolean("is_demo").notNull().default(false),
  createdAt: ts("created_at").notNull().defaultNow(),
});

export const sessions = pgTable(
  "sessions",
  {
    tokenHash: text("token_hash").primaryKey(),
    userId: integer("user_id").notNull(),
    expiresAt: ts("expires_at").notNull(),
    createdAt: ts("created_at").notNull().defaultNow(),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export type Department = typeof departments.$inferSelect;
export type FacultyMember = typeof faculty.$inferSelect;
export type Notice = typeof notices.$inferSelect;
export type NewsItem = typeof news.$inferSelect;
export type EventItem = typeof events.$inferSelect;
export type ContentBlock = typeof siteContent.$inferSelect;
export type Stat = typeof stats.$inferSelect;
export type AdmissionItem = typeof admissionItems.$inferSelect;
export type DocumentItem = typeof documents.$inferSelect;
export type User = typeof users.$inferSelect;
