"use client";

import Link from "next/link";
import { useEffect } from "react";
import { RefreshCw } from "lucide-react";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <main id="main" className="flex min-h-[70vh] items-center justify-center px-6 py-20">
      <div role="alert" className="max-w-lg text-center">
        <p className="text-[0.72rem] font-semibold uppercase tracking-[0.24em] text-accent">Something went wrong</p>
        <h1 className="mt-4 font-serif text-4xl leading-tight tracking-tight text-brand">This page didn&apos;t load properly.</h1>
        <p className="mt-4 leading-relaxed text-muted">The problem is on our side and is usually temporary. Try again, or return to the homepage.</p>
        {error.digest && <p className="mt-3 text-xs text-muted">Reference: {error.digest}</p>}
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button type="button" onClick={reset} className="inline-flex items-center gap-2 rounded-full bg-navy-900 px-6 py-3 text-sm font-semibold text-white transition hover:bg-navy-700 dark:bg-gold-500 dark:text-navy-950">
            <RefreshCw className="size-4" aria-hidden="true" /> Try again
          </button>
          <Link href="/" className="rounded-full border border-line bg-surface px-6 py-3 text-sm font-semibold text-brand transition hover:border-gold-500 hover:text-accent">
            Go to the homepage
          </Link>
        </div>
      </div>
    </main>
  );
}
