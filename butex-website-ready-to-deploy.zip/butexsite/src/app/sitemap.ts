import type { MetadataRoute } from "next";
import { DEPARTMENT_INDEX } from "@/lib/site";

const base = (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/$/, "");

export default function sitemap(): MetadataRoute.Sitemap {
  const pages = ["", "/about", "/academics", "/departments", "/admission", "/research", "/campus-life", "/notices", "/news", "/events", "/faculty", "/contact", "/credits"];
  return [
    ...pages.map((path) => ({ url: `${base}${path || "/"}`, changeFrequency: path === "/notices" || path === "/news" || path === "" ? ("daily" as const) : ("monthly" as const), priority: path === "" ? 1 : 0.7 })),
    ...DEPARTMENT_INDEX.map((d) => ({ url: `${base}/departments/${d.slug}`, changeFrequency: "monthly" as const, priority: 0.6 })),
  ];
}
