import Link from "next/link";
import { Emblem } from "@/components/logo";

export default function NotFound() {
  return (
    <main id="main" className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-navy-900 px-6 py-20 text-center text-white">
      <div className="weave absolute inset-0" aria-hidden="true" />
      <div className="relative max-w-xl">
        <Link href="/" aria-label="BUTEX home" className="inline-block">
          <Emblem className="mx-auto size-14" />
        </Link>
        <p className="mt-8 text-[0.72rem] font-semibold uppercase tracking-[0.24em] text-gold-300">Error 404</p>
        <h1 className="mt-4 font-serif text-5xl leading-[1.08] tracking-tight sm:text-6xl">This page could not be found.</h1>
        <p className="mt-5 text-lg leading-relaxed text-white/70">The address may be mistyped, or the page may have moved. Try one of these instead.</p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <Link href="/" className="rounded-full bg-gold-500 px-6 py-3 text-sm font-semibold text-navy-950 transition hover:bg-gold-400">
            Go to the homepage
          </Link>
          <Link href="/search" className="rounded-full border border-white/40 px-6 py-3 text-sm font-semibold transition hover:bg-white hover:text-navy-900">
            Search the site
          </Link>
          <Link href="/notices" className="rounded-full border border-white/40 px-6 py-3 text-sm font-semibold transition hover:bg-white hover:text-navy-900">
            Notice board
          </Link>
        </div>
      </div>
    </main>
  );
}
