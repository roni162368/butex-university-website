import type { Metadata } from "next";
import { FacultyDirectory } from "@/components/faculty-directory";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Container } from "@/components/ui";
import { getDepartments, getFaculty } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Faculty Directory",
  description: "Search the faculty of Bangladesh University of Textiles by name, department or designation.",
  alternates: { canonical: "/faculty" },
};

type Props = { searchParams: Promise<{ department?: string | string[]; q?: string | string[] }> };
const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";

export default async function FacultyPage({ searchParams }: Props) {
  const params = await searchParams;
  const department = first(params.department);
  const q = first(params.q).slice(0, 80);
  const [members, departments] = await Promise.all([getFaculty(), getDepartments()]);

  return (
    <>
      <PageHero
        title={{ en: "Faculty Directory", bn: "শিক্ষক নির্দেশিকা" }}
        eyebrow={<T en="Our academics" bn="আমাদের শিক্ষকবৃন্দ" />}
        lead="Find academic staff by name, department, designation or research interest."
        crumbs={[{ label: { en: "Academics", bn: "একাডেমিক্স" }, href: "/academics" }, { label: { en: "Faculty Directory", bn: "শিক্ষক নির্দেশিকা" } }]}
      />
      <Container className="py-12 lg:py-16">
        <FacultyDirectory
          key={`${department}|${q}`}
          members={members}
          departments={departments.map((d) => ({ slug: d.slug, code: d.code, name: d.name, nameBn: d.nameBn }))}
          initialDepartment={department}
          initialQuery={q}
        />
      </Container>
    </>
  );
}
