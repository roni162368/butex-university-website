import type { Metadata } from "next";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { Reveal } from "@/components/reveal";
import { T } from "@/components/t";
import { ButtonLink, Container, Eyebrow, Photo, PlaceholderNote, SectionNav } from "@/components/ui";
import { getContent } from "@/lib/data";
import { IMAGES } from "@/lib/images";
import { RESEARCH_THEMES } from "@/lib/research";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Research & Innovation",
  description:
    "Research and innovation at BUTEX: faculty and student research, publications, textile automation, artificial intelligence, sustainable technology, smart textiles and industrial collaboration.",
  alternates: { canonical: "/research" },
};

export default async function ResearchPage() {
  const content = await getContent();
  return (
    <>
      <PageHero
        title={{ en: "Research & Innovation", bn: "গবেষণা ও উদ্ভাবন" }}
        eyebrow={<T en="Discovery with purpose" bn="উদ্দেশ্যমূলক অনুসন্ধান" />}
        lead={content.research_intro}
        crumbs={[{ label: { en: "Research", bn: "গবেষণা" } }]}
        image={IMAGES.labResearch}
      />

      <Container className="grid gap-10 py-14 lg:grid-cols-[15rem_1fr] lg:gap-16 lg:py-20">
        <SectionNav items={RESEARCH_THEMES.map((t) => ({ id: t.id, label: t.title }))} />

        <div className="min-w-0">
          <PlaceholderNote>
            The themes below describe the scope of research at BUTEX. Named projects, funding, patents and publication counts will be added once they have been supplied and verified by the university.
          </PlaceholderNote>

          <div className="mt-12 space-y-16 lg:space-y-20">
            {RESEARCH_THEMES.map((theme, i) => {
              const img = theme.image ? IMAGES[theme.image] : null;
              return (
                <section key={theme.id} id={theme.id} aria-labelledby={`${theme.id}-title`} className="scroll-mt-28">
                  <Reveal className={`grid items-center gap-8 xl:grid-cols-2 xl:gap-14 ${i % 2 === 1 ? "xl:[&>*:first-child]:order-2" : ""}`}>
                    {img && <Photo img={img} className="aspect-[16/11] rounded-2xl" sizes="(min-width: 1280px) 34vw, 100vw" />}
                    <div>
                      <Eyebrow>
                        <span className="tabular-nums">{String(i + 1).padStart(2, "0")}</span>
                      </Eyebrow>
                      <h2 id={`${theme.id}-title`} className="mt-3 flex items-center gap-3 font-serif text-3xl leading-tight tracking-tight text-brand sm:text-4xl">
                        <theme.icon className="size-8 shrink-0 text-accent" aria-hidden="true" />
                        <T en={theme.title.en} bn={theme.title.bn} />
                      </h2>
                      <div className="prose-body mt-5 text-muted">
                        {theme.body.map((p) => (
                          <p key={p.slice(0, 32)}>{p}</p>
                        ))}
                      </div>
                      <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
                        {theme.areas.map((area) => (
                          <li key={area} className="flex gap-2.5 text-sm text-ink">
                            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
                            {area}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </Reveal>
                </section>
              );
            })}
          </div>

          <div className="relative mt-20 overflow-hidden rounded-2xl bg-navy-900 p-8 text-white sm:p-12">
            <div className="weave absolute inset-0" aria-hidden="true" />
            <div className="relative flex flex-col items-start justify-between gap-6 lg:flex-row lg:items-center">
              <div>
                <h2 className="font-serif text-2xl sm:text-3xl">Work with BUTEX</h2>
                <p className="mt-2 max-w-xl text-white/70">For research partnerships, testing services or student projects, get in touch with the university.</p>
              </div>
              <div className="flex flex-wrap gap-3">
                <ButtonLink href="/contact" variant="gold">
                  Contact us <ArrowRight className="size-4" aria-hidden="true" />
                </ButtonLink>
                <ButtonLink href="/departments" variant="light">
                  Departments
                </ButtonLink>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </>
  );
}
