import type { ReactNode } from "react";
import { ImageWarmup } from "@/components/image-warmup";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { getContent } from "@/lib/data";

// Content is editable from the admin dashboard, so public pages are rendered per request.
export const dynamic = "force-dynamic";

export default async function SiteLayout({ children }: { children: ReactNode }) {
  const content = await getContent();
  return (
    <>
      <SiteHeader announcement={content.announcement} />
      <main id="main" tabIndex={-1} className="outline-none">
        {children}
      </main>
      <SiteFooter />
      <ImageWarmup />
    </>
  );
}
