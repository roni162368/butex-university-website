import { ArrowRight } from "lucide-react";
import { ButtonLink, Container, Eyebrow } from "@/components/ui";

export default function SiteNotFound() {
  return (
    <Container className="py-24 text-center lg:py-32">
      <div className="mx-auto max-w-xl">
        <div className="flex justify-center">
          <Eyebrow>Error 404</Eyebrow>
        </div>
        <h1 className="mt-5 font-serif text-4xl leading-tight tracking-tight text-brand sm:text-5xl">We couldn&apos;t find that page.</h1>
        <p className="mt-4 text-lg leading-relaxed text-muted">It may have been moved or removed. Use the search, or head back to one of the main sections.</p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <ButtonLink href="/">
            Homepage <ArrowRight className="size-4" aria-hidden="true" />
          </ButtonLink>
          <ButtonLink href="/search" variant="outline">
            Search the site
          </ButtonLink>
          <ButtonLink href="/departments" variant="outline">
            Departments
          </ButtonLink>
        </div>
      </div>
    </Container>
  );
}
