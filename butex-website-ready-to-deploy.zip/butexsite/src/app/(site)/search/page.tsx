import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, Search } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Container, EmptyState } from "@/components/ui";
import { searchSite, type SearchResult } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Search", robots: { index: false, follow: true } };

type Props = { searchParams: Promise<{ q?: string | string[] }> };

const SUGGESTIONS = ["admission", "yarn engineering", "examination", "faculty", "research", "campus map"];

export default async function SearchPage({ searchParams }: Props) {
  const raw = (await searchParams).q;
  const q = ((Array.isArray(raw) ? raw[0] : raw) ?? "").trim().slice(0, 80);
  const results = q.length >= 2 ? await searchSite(q, 20) : [];
  const groups = results.reduce<Record<string, SearchResult[]>>((acc, r) => {
    (acc[r.type] ??= []).push(r);
    return acc;
  }, {});

  return (
    <>
      <PageHero title={{ en: "Search", bn: "অনুসন্ধান" }} crumbs={[{ label: { en: "Search", bn: "অনুসন্ধান" } }]}>
        <form action="/search" method="get" role="search" className="flex max-w-2xl items-center gap-2 rounded-full bg-white p-1.5 pl-5">
          <Search className="size-5 shrink-0 text-gold-600" aria-hidden="true" />
          <input
            type="search"
            name="q"
            defaultValue={q}
            placeholder="Search departments, notices, faculty, documents…"
            aria-label="Search the BUTEX website"
            className="h-11 w-full bg-transparent text-base text-navy-950 outline-none placeholder:text-slate-500"
          />
          <button type="submit" className="shrink-0 rounded-full bg-navy-900 px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-navy-700">
            <T en="Search" bn="খুঁজুন" />
          </button>
        </form>
      </PageHero>

      <Container className="max-w-4xl py-12 lg:py-16">
        {q.length < 2 ? (
          <div>
            <p className="text-lg text-muted">Enter at least two characters to search across pages, departments, notices, news, events, faculty and documents.</p>
            <p className="mt-8 text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-accent">Try searching for</p>
            <ul className="mt-3 flex flex-wrap gap-2">
              {SUGGESTIONS.map((s) => (
                <li key={s}>
                  <Link href={`/search?q=${encodeURIComponent(s)}`} className="inline-block rounded-full border border-line bg-surface px-4 py-2 text-sm text-brand transition hover:border-gold-500 hover:text-accent">
                    {s}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ) : results.length === 0 ? (
          <EmptyState title={`No results for “${q}”.`}>Check the spelling or try a broader term, such as a department name or a notice category.</EmptyState>
        ) : (
          <>
            <p className="text-sm text-muted" role="status">
              {results.length} result{results.length === 1 ? "" : "s"} for <strong className="text-ink">“{q}”</strong>
            </p>
            <div className="mt-8 space-y-10">
              {Object.entries(groups).map(([type, items]) => (
                <section key={type} aria-label={`${type} results`}>
                  <h2 className="text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-accent">
                    {type} <span className="text-muted">({items.length})</span>
                  </h2>
                  <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
                    {items.map((r) => (
                      <li key={`${r.href}-${r.title}`}>
                        <Link href={r.href} className="group flex items-center gap-4 px-5 py-4 transition hover:bg-surface-2 sm:px-6">
                          <span className="min-w-0 flex-1">
                            <span className="block font-semibold text-ink group-hover:text-accent">{r.title}</span>
                            {r.snippet && <span className="mt-0.5 block truncate text-sm text-muted">{r.snippet}</span>}
                          </span>
                          <ArrowRight className="size-4 shrink-0 text-muted transition group-hover:translate-x-1 group-hover:text-accent" aria-hidden="true" />
                        </Link>
                      </li>
                    ))}
                  </ul>
                </section>
              ))}
            </div>
          </>
        )}
      </Container>
    </>
  );
}
