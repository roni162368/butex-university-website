import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, BedDouble, Building2, CalendarHeart, HeartHandshake, Trophy, Users, UsersRound } from "lucide-react";
import { EventRow } from "@/components/cards";
import { CampusMap } from "@/components/campus-map";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Container, PageSection, Photo, PlaceholderNote, SectionNav } from "@/components/ui";
import { getContent, getUpcomingEvents } from "@/lib/data";
import { IMAGES } from "@/lib/images";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Campus Life",
  description: "Student organizations, clubs and societies, sports and culture, events, campus and residential facilities, student welfare and an interactive campus map.",
  alternates: { canonical: "/campus-life" },
};

const SECTIONS = [
  { id: "organizations", label: { en: "Student Organizations", bn: "ছাত্র সংগঠন" } },
  { id: "clubs", label: { en: "Clubs & Societies", bn: "ক্লাব ও সোসাইটি" } },
  { id: "sports", label: { en: "Sports & Cultural Activities", bn: "ক্রীড়া ও সংস্কৃতি" } },
  { id: "events", label: { en: "Events & Festivals", bn: "অনুষ্ঠান ও উৎসব" } },
  { id: "facilities", label: { en: "Campus Facilities", bn: "ক্যাম্পাস সুবিধা" } },
  { id: "residential", label: { en: "Residential Facilities", bn: "আবাসিক সুবিধা" } },
  { id: "welfare", label: { en: "Student Welfare", bn: "শিক্ষার্থী কল্যাণ" } },
  { id: "map", label: { en: "Campus Map", bn: "ক্যাম্পাস মানচিত্র" } },
];

const CLUB_AREAS = [
  { title: "Technical & career", text: "Subject-focused groups, competitions, industry talks and career preparation." },
  { title: "Debate & language", text: "Debating, public speaking and language practice." },
  { title: "Culture & arts", text: "Music, drama, photography, film and literary activity." },
  { title: "Sports", text: "Teams and tournaments across indoor and outdoor games." },
  { title: "Service & community", text: "Volunteering, blood donation and social initiatives." },
  { title: "Innovation & enterprise", text: "Projects, hackathons and start-up ideas." },
];

const LABS = [IMAGES.labYarn, IMAGES.labFabric, IMAGES.labWet, IMAGES.labApparel];

export default async function CampusLifePage() {
  const [content, events] = await Promise.all([getContent(), getUpcomingEvents(4)]);

  return (
    <>
      <PageHero
        title={{ en: "Campus Life", bn: "ক্যাম্পাস জীবন" }}
        eyebrow={<T en="Life at BUTEX" bn="বুটেক্সে জীবন" />}
        lead={content.campus_intro}
        crumbs={[{ label: { en: "Campus Life", bn: "ক্যাম্পাস জীবন" } }]}
        image={IMAGES.shaheedMinar}
      />

      <Container className="grid gap-10 py-14 lg:grid-cols-[15rem_1fr] lg:gap-16 lg:py-20">
        <SectionNav items={SECTIONS} />

        <div className="min-w-0 space-y-16">
          <PageSection id="organizations" title={{ en: "Student Organizations", bn: "ছাত্র সংগঠন" }}>
            <div className="grid items-center gap-8 xl:grid-cols-[1.2fr_1fr]">
              <div className="space-y-4 text-lg leading-relaxed text-muted">
                <p>
                  Much of what students remember about university happens outside the timetable. Student-run organizations at BUTEX give members room to lead, organize and build networks that last well beyond graduation.
                </p>
                <p>Organizations operate with the approval of the university administration, and many work alongside a faculty advisor.</p>
              </div>
              <Photo img={IMAGES.graduates} className="aspect-[4/3] rounded-2xl" sizes="(min-width: 1280px) 30vw, 100vw" />
            </div>
            <PlaceholderNote className="mt-6">The register of recognized student organizations will be published here by the university.</PlaceholderNote>
          </PageSection>

          <PageSection id="clubs" title={{ en: "Clubs & Societies", bn: "ক্লাব ও সোসাইটি" }}>
            <p className="max-w-2xl leading-relaxed text-muted">Clubs and societies span a wide range of interests. The areas below show the kinds of activity students take part in.</p>
            <ul className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {CLUB_AREAS.map((c) => (
                <li key={c.title} className="rounded-2xl border border-line bg-surface p-6">
                  <UsersRound className="size-6 text-accent" aria-hidden="true" />
                  <h3 className="mt-4 font-serif text-xl text-brand">{c.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{c.text}</p>
                </li>
              ))}
            </ul>
            <PlaceholderNote className="mt-6">A directory of individual clubs, with contacts and how to join, will be added once supplied by the clubs.</PlaceholderNote>
          </PageSection>

          <PageSection id="sports" title={{ en: "Sports & Cultural Activities", bn: "ক্রীড়া ও সাংস্কৃতিক কার্যক্রম" }}>
            <div className="grid items-center gap-8 xl:grid-cols-[1fr_1.2fr]">
              <Photo img={IMAGES.sportsField} className="aspect-[4/3] rounded-2xl" sizes="(min-width: 1280px) 30vw, 100vw" />
              <div>
                <div className="space-y-4 text-lg leading-relaxed text-muted">
                  <p>The campus has a central playground used by students and staff, with further playing space attached to the residential halls.</p>
                  <p>Inter-department tournaments and cultural programs bring the whole university together through the year.</p>
                </div>
                <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                  {[
                    { icon: Trophy, text: "Inter-department tournaments" },
                    { icon: Users, text: "Indoor and outdoor games" },
                    { icon: CalendarHeart, text: "Cultural evenings and festivals" },
                    { icon: HeartHandshake, text: "Alumni and community events" },
                  ].map((x) => (
                    <li key={x.text} className="flex items-center gap-3 rounded-xl border border-line bg-surface px-4 py-3 text-sm font-medium text-ink">
                      <x.icon className="size-5 shrink-0 text-accent" aria-hidden="true" />
                      {x.text}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </PageSection>

          <PageSection id="events" title={{ en: "Events & Festivals", bn: "অনুষ্ঠান ও উৎসব" }}>
            <div className="grid gap-8 xl:grid-cols-[1fr_1.1fr]">
              <div>
                <p className="text-lg leading-relaxed text-muted">
                  The university calendar is shaped by national observances such as International Mother Language Day, Independence Day, Pohela Boishakh and Victory Day, alongside seminars, orientation programs and student-led festivals.
                </p>
                <Photo img={IMAGES.shaheedMinar} className="mt-6 aspect-[16/10] rounded-2xl" sizes="(min-width: 1280px) 30vw, 100vw" />
              </div>
              <div>
                <h3 className="text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-accent">Coming up</h3>
                <ul className="mt-3 space-y-3">
                  {events.map((e) => (
                    <EventRow key={e.id} event={e} />
                  ))}
                </ul>
                <p className="mt-5">
                  <Link href="/events" className="group inline-flex items-center gap-2 text-sm font-semibold text-brand hover:text-accent">
                    Open the events calendar <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                  </Link>
                </p>
              </div>
            </div>
          </PageSection>

          <PageSection id="facilities" title={{ en: "Campus Facilities", bn: "ক্যাম্পাস সুবিধা" }}>
            <p className="max-w-3xl text-lg leading-relaxed text-muted">
              Teaching at BUTEX relies on working machinery. The laboratories below, photographed on campus, give students hands-on experience of the processes they study.
            </p>
            <ul className="mt-6 grid gap-4 sm:grid-cols-2">
              {LABS.map((img) => (
                <li key={img.src}>
                  <Photo img={img} className="aspect-[4/3] rounded-2xl" sizes="(min-width: 640px) 40vw, 100vw" />
                  <p className="mt-2 text-sm text-muted">{img.alt}</p>
                </li>
              ))}
            </ul>
            <div className="mt-6 flex gap-4 rounded-2xl border border-line bg-surface p-6">
              <Building2 className="mt-0.5 size-6 shrink-0 text-accent" aria-hidden="true" />
              <div>
                <p className="leading-relaxed text-ink">Alongside laboratories and workshops, the campus provides classrooms, library and study space, and common facilities for students and staff.</p>
                <PlaceholderNote className="mt-4">A complete facilities list, with opening hours and locations, will be published after verification.</PlaceholderNote>
              </div>
            </div>
          </PageSection>

          <PageSection id="residential" title={{ en: "Residential Facilities", bn: "আবাসিক সুবিধা" }}>
            <div className="flex gap-4 rounded-2xl border border-line bg-surface p-6 sm:p-7">
              <BedDouble className="mt-0.5 size-7 shrink-0 text-accent" aria-hidden="true" />
              <div>
                <p className="text-lg leading-relaxed text-ink">BUTEX provides halls of residence for its students. Each hall is overseen by a provost drawn from the faculty, supported by hall staff.</p>
                <PlaceholderNote className="mt-5">Hall names, capacity, allocation rules and fees will be listed here once confirmed by the hall administration.</PlaceholderNote>
              </div>
            </div>
          </PageSection>

          <PageSection id="welfare" title={{ en: "Student Welfare Activities", bn: "শিক্ষার্থী কল্যাণ কার্যক্রম" }}>
            <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {["Scholarships and stipends", "Academic advising", "Health and medical support", "Counseling and guidance"].map((item) => (
                <li key={item} className="rounded-2xl border border-line bg-surface p-5">
                  <HeartHandshake className="size-5 text-accent" aria-hidden="true" />
                  <p className="mt-3 font-semibold text-ink">{item}</p>
                </li>
              ))}
            </ul>
            <PlaceholderNote className="mt-6">Details of each welfare service, including eligibility and how to apply, will be published by the office responsible for student welfare.</PlaceholderNote>
          </PageSection>

          <PageSection id="map" title={{ en: "Interactive Campus Map", bn: "ইন্টারেক্টিভ ক্যাম্পাস মানচিত্র" }}>
            <CampusMap />
          </PageSection>
        </div>
      </Container>
    </>
  );
}
