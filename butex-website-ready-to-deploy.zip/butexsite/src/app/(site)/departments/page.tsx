import type { Metadata } from "next";
import { ArrowRight } from "lucide-react";
import { DepartmentCard } from "@/components/cards";
import { PageHero } from "@/components/page-hero";
import { Reveal } from "@/components/reveal";
import { T } from "@/components/t";
import { ButtonLink, Container } from "@/components/ui";
import { getDepartments } from "@/lib/data";
import { IMAGES } from "@/lib/images";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Departments",
  description:
    "The nine academic departments of BUTEX: Yarn, Fabric, Wet Processing, Apparel, Textile Engineering Management, Fashion and Design, Dyes and Chemical, Environmental Science, and Textile Machinery Design and Maintenance.",
  alternates: { canonical: "/departments" },
};

export default async function DepartmentsPage() {
  const departments = await getDepartments();
  return (
    <>
      <PageHero
        title={{ en: "Academic Departments", bn: "একাডেমিক বিভাগসমূহ" }}
        eyebrow={<T en="Nine departments" bn="নয়টি বিভাগ" />}
        lead="Each department covers a distinct stage of the textile value chain and has its own programs, laboratories and research interests."
        crumbs={[{ label: { en: "Departments", bn: "বিভাগসমূহ" } }]}
        image={IMAGES.deptFE}
      />
      <Container className="py-14 lg:py-20">
        <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {departments.map((d, i) => (
            <li key={d.slug}>
              <Reveal className="h-full" delay={(i % 3) * 90}>
                <DepartmentCard department={d} />
              </Reveal>
            </li>
          ))}
        </ul>

        <div className="mt-16 flex flex-col items-start justify-between gap-6 rounded-2xl border border-line bg-surface p-8 sm:flex-row sm:items-center sm:p-10">
          <div>
            <h2 className="font-serif text-2xl text-brand sm:text-3xl">
              <T en="Looking for a member of faculty?" bn="কোনো শিক্ষককে খুঁজছেন?" />
            </h2>
            <p className="mt-2 text-muted">Search the directory by name, department or designation.</p>
          </div>
          <ButtonLink href="/faculty">
            <T en="Faculty directory" bn="শিক্ষক নির্দেশিকা" />
            <ArrowRight className="size-4" aria-hidden="true" />
          </ButtonLink>
        </div>
      </Container>
    </>
  );
}
