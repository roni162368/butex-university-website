import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, BookOpenText, Building2, CheckCircle2, FlaskConical, Mail, Phone, UserRound } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Badge, Container, EmptyState, PageSection, Photo, PlaceholderNote, SectionNav } from "@/components/ui";
import { getDepartment, getDepartments, getFaculty } from "@/lib/data";
import { lines, pairs } from "@/lib/format";
import { IMAGES, imageBySrc, type Img } from "@/lib/images";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const d = await getDepartment(slug);
  if (!d) return { title: "Department not found" };
  return {
    title: `Department of ${d.name} (${d.code})`,
    description: d.overview.slice(0, 160),
    alternates: { canonical: `/departments/${d.slug}` },
    openGraph: { title: `Department of ${d.name} — BUTEX`, description: d.tagline, images: d.image ? [d.image] : undefined },
  };
}

const SECTIONS = [
  { id: "overview", label: { en: "Overview", bn: "সারসংক্ষেপ" } },
  { id: "faculty", label: { en: "Faculty Members", bn: "শিক্ষকবৃন্দ" } },
  { id: "programs", label: { en: "Academic Programs", bn: "একাডেমিক প্রোগ্রাম" } },
  { id: "curriculum", label: { en: "Curriculum", bn: "পাঠ্যক্রম" } },
  { id: "labs", label: { en: "Laboratories & Facilities", bn: "ল্যাবরেটরি ও সুবিধা" } },
  { id: "research", label: { en: "Research Activities", bn: "গবেষণা কার্যক্রম" } },
  { id: "publications", label: { en: "Publications", bn: "প্রকাশনা" } },
  { id: "contact", label: { en: "Contact", bn: "যোগাযোগ" } },
];

/** Photographs of BUTEX laboratories that are available under a free license. */
const LAB_PHOTOS: Record<string, Img> = {
  YE: IMAGES.labYarn,
  FE: IMAGES.labFabric,
  WPE: IMAGES.labWet,
  AE: IMAGES.labApparel,
};

export default async function DepartmentPage({ params }: Props) {
  const { slug } = await params;
  const d = await getDepartment(slug);
  if (!d) notFound();

  const [members, all] = await Promise.all([getFaculty(d.slug), getDepartments()]);
  const index = all.findIndex((x) => x.slug === d.slug);
  const prev = index > 0 ? all[index - 1] : null;
  const next = index >= 0 && index < all.length - 1 ? all[index + 1] : null;

  const programs = pairs(d.programs);
  const curriculum = lines(d.curriculum);
  const labs = lines(d.labs);
  const research = lines(d.research);
  const publications = lines(d.publications);
  const labPhoto = LAB_PHOTOS[d.code];
  const hasContact = Boolean(d.email || d.phone || d.office);

  return (
    <>
      <PageHero
        title={{ en: d.name, bn: d.nameBn }}
        eyebrow={
          <>
            <T en="Department" bn="বিভাগ" /> · {d.code}
          </>
        }
        lead={d.tagline}
        crumbs={[{ label: { en: "Departments", bn: "বিভাগসমূহ" }, href: "/departments" }, { label: { en: d.name, bn: d.nameBn } }]}
        image={imageBySrc(d.image)}
      />

      <Container className="grid gap-10 py-14 lg:grid-cols-[15rem_1fr] lg:gap-16 lg:py-20">
        <SectionNav items={SECTIONS} />

        <div className="min-w-0 space-y-16">
          <PageSection id="overview" title={{ en: "Department Overview", bn: "বিভাগ পরিচিতি" }}>
            <p className="max-w-3xl whitespace-pre-line text-lg leading-relaxed text-ink">{d.overview}</p>
          </PageSection>

          <PageSection id="faculty" title={{ en: "Faculty Members", bn: "শিক্ষকবৃন্দ" }}>
            {members.length === 0 ? (
              <EmptyState title="No faculty profiles have been published yet.">Profiles will appear here once they are added by the department.</EmptyState>
            ) : (
              <>
                {members.some((m) => m.isPlaceholder) && (
                  <PlaceholderNote className="mb-6">Profile slots marked as placeholders will be replaced with official faculty profiles supplied by the department.</PlaceholderNote>
                )}
                <ul className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
                  {members.map((m) => (
                    <li key={m.id} className="flex gap-4 rounded-2xl border border-line bg-surface p-5">
                      <span className="flex size-12 shrink-0 items-center justify-center rounded-full bg-surface-2 text-muted">
                        <UserRound className="size-5" aria-hidden="true" />
                      </span>
                      <span className="min-w-0">
                        <span className="block font-semibold leading-snug text-ink">{m.name}</span>
                        <span className="mt-0.5 block text-sm text-muted">{m.designation}</span>
                        {m.email && (
                          <a href={`mailto:${m.email}`} className="mt-1 block truncate text-sm text-accent hover:underline">
                            {m.email}
                          </a>
                        )}
                        {m.isPlaceholder && (
                          <span className="mt-2 block">
                            <Badge tone="sample">Placeholder</Badge>
                          </span>
                        )}
                      </span>
                    </li>
                  ))}
                </ul>
                <p className="mt-6">
                  <Link href={`/faculty?department=${d.slug}`} className="group inline-flex items-center gap-2 text-sm font-semibold text-brand hover:text-accent">
                    View in the faculty directory
                    <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                  </Link>
                </p>
              </>
            )}
          </PageSection>

          <PageSection id="programs" title={{ en: "Academic Programs", bn: "একাডেমিক প্রোগ্রাম" }}>
            {programs.length > 0 ? (
              <dl className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
                {programs.map((p) => (
                  <div key={p.left} className="grid gap-1 px-6 py-5 sm:grid-cols-[12rem_1fr] sm:gap-6">
                    <dt className="font-serif text-lg text-brand">{p.left}</dt>
                    <dd className="leading-relaxed text-muted">{p.right}</dd>
                  </div>
                ))}
              </dl>
            ) : (
              <PlaceholderNote>Program details will be published by the department.</PlaceholderNote>
            )}
          </PageSection>

          <PageSection id="curriculum" title={{ en: "Curriculum", bn: "পাঠ্যক্রম" }}>
            <p className="max-w-2xl leading-relaxed text-muted">Subject areas typically covered in this discipline. The official syllabus, with course codes and credits, is published under Academic Documents.</p>
            {curriculum.length > 0 && (
              <ul className="mt-6 grid gap-x-8 gap-y-3 sm:grid-cols-2">
                {curriculum.map((item) => (
                  <li key={item} className="flex gap-3">
                    <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
                    <span className="leading-relaxed text-ink">{item}</span>
                  </li>
                ))}
              </ul>
            )}
            <PlaceholderNote className="mt-6">Indicative subject areas. To be replaced with the department&apos;s approved curriculum.</PlaceholderNote>
          </PageSection>

          <PageSection id="labs" title={{ en: "Laboratories & Facilities", bn: "ল্যাবরেটরি ও সুবিধা" }}>
            <div className={`grid gap-8 ${labPhoto ? "xl:grid-cols-[1fr_1.1fr]" : ""}`}>
              <div>
                <p className="leading-relaxed text-muted">Practical work is central to the department. Laboratory teaching covers the following areas.</p>
                <ul className="mt-5 space-y-3">
                  {labs.map((item) => (
                    <li key={item} className="flex gap-3 rounded-xl border border-line bg-surface px-4 py-3">
                      <FlaskConical className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
                      <span className="text-ink">{item}</span>
                    </li>
                  ))}
                </ul>
                <PlaceholderNote className="mt-6">The official inventory of laboratories and equipment will be added by the department.</PlaceholderNote>
              </div>
              {labPhoto && <Photo img={labPhoto} className="aspect-[4/3] rounded-2xl" sizes="(min-width: 1280px) 34vw, 100vw" />}
            </div>
          </PageSection>

          <PageSection id="research" title={{ en: "Research Activities", bn: "গবেষণা কার্যক্রম" }}>
            <p className="max-w-2xl leading-relaxed text-muted">Research interests associated with this discipline. Current projects, funding and collaborations will be listed as they are confirmed.</p>
            {research.length > 0 && (
              <ul className="mt-6 grid gap-4 sm:grid-cols-2">
                {research.map((item, i) => (
                  <li key={item} className="rounded-2xl border border-line bg-surface p-5">
                    <span className="font-serif text-2xl text-gold-500">{String(i + 1).padStart(2, "0")}</span>
                    <p className="mt-2 font-medium leading-snug text-ink">{item}</p>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-6">
              <Link href="/research" className="group inline-flex items-center gap-2 text-sm font-semibold text-brand hover:text-accent">
                Research & innovation at BUTEX
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
              </Link>
            </p>
          </PageSection>

          <PageSection id="publications" title={{ en: "Publications", bn: "প্রকাশনা" }}>
            {publications.length > 0 ? (
              <ol className="space-y-3">
                {publications.map((item, i) => (
                  <li key={`${i}-${item.slice(0, 20)}`} className="flex gap-4 rounded-xl border border-line bg-surface px-5 py-4">
                    <BookOpenText className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
                    <span className="leading-relaxed text-ink">{item}</span>
                  </li>
                ))}
              </ol>
            ) : (
              <EmptyState title="No publications listed yet.">The department&apos;s publication list will appear here once it has been supplied.</EmptyState>
            )}
          </PageSection>

          <PageSection id="contact" title={{ en: "Contact Information", bn: "যোগাযোগের তথ্য" }}>
            {hasContact ? (
              <ul className="grid gap-4 sm:grid-cols-3">
                {d.office && (
                  <li className="rounded-2xl border border-line bg-surface p-5">
                    <Building2 className="size-5 text-accent" aria-hidden="true" />
                    <p className="mt-3 text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-muted">Office</p>
                    <p className="mt-1 text-ink">{d.office}</p>
                  </li>
                )}
                {d.email && (
                  <li className="rounded-2xl border border-line bg-surface p-5">
                    <Mail className="size-5 text-accent" aria-hidden="true" />
                    <p className="mt-3 text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-muted">Email</p>
                    <a href={`mailto:${d.email}`} className="mt-1 block break-all text-ink hover:text-accent">
                      {d.email}
                    </a>
                  </li>
                )}
                {d.phone && (
                  <li className="rounded-2xl border border-line bg-surface p-5">
                    <Phone className="size-5 text-accent" aria-hidden="true" />
                    <p className="mt-3 text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-muted">Phone</p>
                    <a href={`tel:${d.phone.replace(/[^\d+]/g, "")}`} className="mt-1 block text-ink hover:text-accent">
                      {d.phone}
                    </a>
                  </li>
                )}
              </ul>
            ) : (
              <div className="rounded-2xl border border-line bg-surface p-6">
                <p className="leading-relaxed text-ink">
                  Department office details have not been published yet. In the meantime, inquiries can be sent through the university&apos;s{" "}
                  <Link href="/contact" className="font-semibold text-accent underline-offset-4 hover:underline">
                    contact page
                  </Link>
                  .
                </p>
              </div>
            )}
          </PageSection>

          <nav aria-label="Other departments" className="grid gap-4 border-t border-line pt-10 sm:grid-cols-2">
            {prev ? (
              <Link href={`/departments/${prev.slug}`} className="group rounded-2xl border border-line bg-surface p-5 transition hover:border-gold-500/60">
                <span className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-muted">
                  <ArrowLeft className="size-3.5 transition-transform group-hover:-translate-x-1" aria-hidden="true" /> Previous
                </span>
                <span className="mt-2 block font-serif text-lg text-brand">{prev.name}</span>
              </Link>
            ) : (
              <span />
            )}
            {next && (
              <Link href={`/departments/${next.slug}`} className="group rounded-2xl border border-line bg-surface p-5 text-right transition hover:border-gold-500/60">
                <span className="flex items-center justify-end gap-2 text-xs font-semibold uppercase tracking-[0.16em] text-muted">
                  Next <ArrowRight className="size-3.5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                </span>
                <span className="mt-2 block font-serif text-lg text-brand">{next.name}</span>
              </Link>
            )}
          </nav>
        </div>
      </Container>
    </>
  );
}
