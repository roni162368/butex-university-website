import type { Metadata } from "next";
import Image from "next/image";
import { ExternalLink } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { Badge, Container } from "@/components/ui";
import { IMAGES } from "@/lib/images";

export const metadata: Metadata = {
  title: "Image Credits",
  description: "Sources, photographers and licenses for photography used on this website.",
  alternates: { canonical: "/credits" },
};

export default function CreditsPage() {
  const images = Object.values(IMAGES);
  const groups = [
    {
      title: "Photographs of BUTEX",
      note: "Photographs of the BUTEX campus and laboratories from Wikimedia Commons, used under Creative Commons Attribution-ShareAlike licenses. Images have been resized and cropped.",
      items: images.filter((i) => i.butex),
    },
    {
      title: "Illustrative photography",
      note: "Stock photographs from Pexels, used to illustrate subject areas. They do not show BUTEX and are labeled “Illustrative image” wherever they appear. They should be replaced with official university photography.",
      items: images.filter((i) => !i.butex),
    },
  ];

  return (
    <>
      <PageHero title={{ en: "Image Credits", bn: "ছবির কৃতজ্ঞতা" }} lead="Every photograph on this site, with its photographer, source and license." crumbs={[{ label: { en: "Image Credits", bn: "ছবির কৃতজ্ঞতা" } }]} />
      <Container className="space-y-16 py-12 lg:py-16">
        {groups.map((group) => (
          <section key={group.title}>
            <h2 className="font-serif text-3xl text-brand">{group.title}</h2>
            <p className="mt-3 max-w-3xl leading-relaxed text-muted">{group.note}</p>
            <ul className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {group.items.map((img) => (
                <li key={img.src} className="overflow-hidden rounded-2xl border border-line bg-surface">
                  <div className="relative aspect-[16/10] bg-navy-900">
                    <Image src={img.src} alt={img.alt} fill sizes="(min-width: 1280px) 25vw, (min-width: 640px) 50vw, 100vw" className="object-cover" />
                  </div>
                  <div className="p-4">
                    <p className="text-sm leading-snug text-ink">{img.alt}</p>
                    <p className="mt-2 text-sm text-muted">Photo: {img.credit}</p>
                    <div className="mt-3 flex items-center justify-between gap-3">
                      <Badge tone={img.butex ? "gold" : "neutral"}>{img.license}</Badge>
                      <a href={img.source} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand hover:text-accent">
                        Source <ExternalLink className="size-3" aria-hidden="true" />
                      </a>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </Container>
    </>
  );
}
