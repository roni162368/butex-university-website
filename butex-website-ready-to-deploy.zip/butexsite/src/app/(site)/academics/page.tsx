import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, BookMarked, CalendarDays, FileText, GraduationCap, Network, Users } from "lucide-react";
import { EventRow } from "@/components/cards";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { ButtonLink, Container, EmptyState, FileLink, PageSection, PlaceholderNote, SampleBadge, SectionNav } from "@/components/ui";
import { getDepartments, getDocuments, getUpcomingEvents } from "@/lib/data";
import { IMAGES } from "@/lib/images";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Academics",
  description: "Academic programs, the academic calendar and downloadable academic documents at Bangladesh University of Textiles.",
  alternates: { canonical: "/academics" },
};

const SECTIONS = [
  { id: "programs", label: { en: "Academic Programs", bn: "একাডেমিক প্রোগ্রাম" } },
  { id: "calendar", label: { en: "Academic Calendar", bn: "একাডেমিক ক্যালেন্ডার" } },
  { id: "documents", label: { en: "Academic Documents", bn: "একাডেমিক নথিপত্র" } },
  { id: "people", label: { en: "Faculty & Students", bn: "শিক্ষক ও শিক্ষার্থী" } },
  { id: "affiliated", label: { en: "Affiliated Colleges", bn: "অধিভুক্ত কলেজ" } },
];

const LEVELS = [
  { icon: GraduationCap, title: "Undergraduate", text: "Four-year Bachelor of Science programs delivered through the university's nine departments." },
  { icon: BookMarked, title: "Postgraduate", text: "Master's-level study for graduates who wish to specialize or move into research." },
  { icon: FileText, title: "Doctoral", text: "Research degrees supervised by the university's faculty." },
  { icon: Users, title: "Professional development", text: "Short courses and executive programs for people working in industry." },
];

export default async function AcademicsPage() {
  const [departments, documents, events] = await Promise.all([getDepartments(), getDocuments(), getUpcomingEvents(6)]);
  const categories = [...new Set(documents.map((d) => d.category || "General"))];

  return (
    <>
      <PageHero
        title={{ en: "Academics", bn: "একাডেমিক্স" }}
        eyebrow={<T en="Study at BUTEX" bn="বুটেক্সে অধ্যয়ন" />}
        lead="Programs that follow the textile value chain from fiber to finished product, taught in laboratories and workshops as much as in lecture rooms."
        crumbs={[{ label: { en: "Academics", bn: "একাডেমিক্স" } }]}
        image={IMAGES.library}
      />

      <Container className="grid gap-10 py-14 lg:grid-cols-[15rem_1fr] lg:gap-16 lg:py-20">
        <SectionNav items={SECTIONS} />

        <div className="min-w-0 space-y-16">
          <PageSection id="programs" title={{ en: "Academic Programs", bn: "একাডেমিক প্রোগ্রাম" }}>
            <ul className="grid gap-4 sm:grid-cols-2">
              {LEVELS.map((level) => (
                <li key={level.title} className="rounded-2xl border border-line bg-surface p-6">
                  <level.icon className="size-6 text-accent" aria-hidden="true" />
                  <h3 className="mt-4 font-serif text-xl text-brand">{level.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted">{level.text}</p>
                </li>
              ))}
            </ul>
            <PlaceholderNote className="mt-6">
              Official program titles, credit requirements, intake and fees will be published here after confirmation by the Office of the Registrar.
            </PlaceholderNote>

            <h3 className="mt-12 font-serif text-2xl text-brand">Undergraduate study by department</h3>
            <ul className="mt-5 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
              {departments.map((d) => (
                <li key={d.slug}>
                  <Link href={`/departments/${d.slug}#programs`} className="group flex items-center gap-4 px-5 py-4 transition hover:bg-surface-2 sm:px-6">
                    <span className="w-14 shrink-0 text-xs font-bold tracking-[0.16em] text-accent">{d.code}</span>
                    <span className="min-w-0 flex-1">
                      <span className="block font-semibold text-ink">
                        <T en={d.name} bn={d.nameBn} />
                      </span>
                      <span className="block truncate text-sm text-muted">{d.tagline}</span>
                    </span>
                    <ArrowRight className="size-4 shrink-0 text-muted transition group-hover:translate-x-1 group-hover:text-accent" aria-hidden="true" />
                  </Link>
                </li>
              ))}
            </ul>
          </PageSection>

          <PageSection id="calendar" title={{ en: "Academic Calendar", bn: "একাডেমিক ক্যালেন্ডার" }}>
            <p className="max-w-2xl leading-relaxed text-muted">
              Upcoming dates from the university calendar are listed below. The complete calendar for each academic session is published as a PDF under Academic Documents.
            </p>
            {events.length > 0 ? (
              <ul className="mt-6 grid gap-3 xl:grid-cols-2">
                {events.map((e) => (
                  <EventRow key={e.id} event={e} />
                ))}
              </ul>
            ) : (
              <div className="mt-6">
                <EmptyState title="No upcoming dates.">Dates will appear here when the calendar is updated.</EmptyState>
              </div>
            )}
            <div className="mt-6 flex flex-wrap gap-3">
              <ButtonLink href="/events" variant="outline">
                <CalendarDays className="size-4" aria-hidden="true" />
                Open the events calendar
              </ButtonLink>
            </div>
          </PageSection>

          <PageSection id="documents" title={{ en: "Academic Documents", bn: "একাডেমিক নথিপত্র" }}>
            <p className="max-w-2xl leading-relaxed text-muted">Regulations, syllabi, forms and calendars available for download.</p>
            {documents.length === 0 ? (
              <div className="mt-6">
                <EmptyState title="No documents have been published yet.">Documents uploaded by the university will be listed here.</EmptyState>
              </div>
            ) : (
              <div className="mt-8 space-y-8">
                {categories.map((category) => (
                  <div key={category}>
                    <h3 className="text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-accent">{category}</h3>
                    <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
                      {documents
                        .filter((d) => (d.category || "General") === category)
                        .map((d) => (
                          <li key={d.id} className="flex flex-col gap-3 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                            <div className="min-w-0">
                              <p className="flex flex-wrap items-center gap-2 font-semibold text-ink">
                                {d.title}
                                {d.isSample && <SampleBadge />}
                              </p>
                              {d.description && <p className="mt-0.5 text-sm text-muted">{d.description}</p>}
                            </div>
                            {d.fileId ? <FileLink fileId={d.fileId} fileName={d.fileName} compact /> : <span className="text-xs text-muted">File pending</span>}
                          </li>
                        ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </PageSection>

          <PageSection id="people" title={{ en: "Faculty & Students", bn: "শিক্ষক ও শিক্ষার্থী" }}>
            <div className="grid gap-6 md:grid-cols-2">
              <article className="rounded-2xl border border-line bg-surface p-7">
                <Users className="size-7 text-accent" aria-hidden="true" />
                <h3 className="mt-4 font-serif text-2xl text-brand">Faculty directory</h3>
                <p className="mt-2 leading-relaxed text-muted">Search academic staff by name, department or designation.</p>
                <div className="mt-6">
                  <ButtonLink href="/faculty">
                    Browse the directory <ArrowRight className="size-4" aria-hidden="true" />
                  </ButtonLink>
                </div>
              </article>
              <article className="rounded-2xl border border-line bg-surface p-7">
                <GraduationCap className="size-7 text-accent" aria-hidden="true" />
                <h3 className="mt-4 font-serif text-2xl text-brand">Student portal</h3>
                <p className="mt-2 leading-relaxed text-muted">Class routine, examination schedule, results and course materials in one place.</p>
                <div className="mt-6">
                  <ButtonLink href="/portal" variant="outline">
                    Open the portal <ArrowRight className="size-4" aria-hidden="true" />
                  </ButtonLink>
                </div>
              </article>
            </div>
          </PageSection>

          <PageSection id="affiliated" title={{ en: "Affiliated Colleges", bn: "অধিভুক্ত কলেজ" }}>
            <div className="flex gap-5 rounded-2xl border border-line bg-surface p-7">
              <Network className="mt-1 size-7 shrink-0 text-accent" aria-hidden="true" />
              <div>
                <p className="leading-relaxed text-ink">
                  In addition to teaching on its own campus, BUTEX provides academic affiliation to government textile engineering colleges across Bangladesh, which follow the university&apos;s curriculum and examinations.
                </p>
                <PlaceholderNote className="mt-5">The current list of affiliated colleges will be published here after verification.</PlaceholderNote>
              </div>
            </div>
          </PageSection>
        </div>
      </Container>
    </>
  );
}
