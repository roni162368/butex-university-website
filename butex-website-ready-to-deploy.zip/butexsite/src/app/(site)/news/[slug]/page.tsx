import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { Breadcrumbs } from "@/components/page-hero";
import { T } from "@/components/t";
import { Container, Photo, PlaceholderNote, SampleBadge } from "@/components/ui";
import { getNewsItem } from "@/lib/data";
import { fmtDate } from "@/lib/format";
import { imageBySrc } from "@/lib/images";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const item = await getNewsItem((await params).slug);
  if (!item) return { title: "Story not found" };
  return {
    title: item.title,
    description: item.excerpt,
    robots: item.isSample ? { index: false } : undefined,
    openGraph: { type: "article", title: item.title, description: item.excerpt, publishedTime: item.publishedAt.toISOString(), images: item.image ? [item.image] : undefined },
  };
}

export default async function NewsItemPage({ params }: Props) {
  const item = await getNewsItem((await params).slug);
  if (!item) notFound();
  const paragraphs = item.body.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);

  return (
    <article>
      <header className="relative bg-navy-900 text-white">
        <div className="weave absolute inset-0" aria-hidden="true" />
        <Container className="relative max-w-4xl py-12 sm:py-16">
          <Breadcrumbs crumbs={[{ label: { en: "News", bn: "সংবাদ" }, href: "/news" }, { label: { en: "Story" } }]} />
          <div className="mt-8 flex flex-wrap items-center gap-3 text-sm text-white/70">
            <time dateTime={item.publishedAt.toISOString()}>{fmtDate(item.publishedAt)}</time>
            {item.isSample && <SampleBadge onDark />}
          </div>
          <h1 className="mt-4 font-serif text-4xl leading-[1.1] tracking-tight sm:text-5xl">{item.title}</h1>
          {item.excerpt && <p className="mt-5 text-xl leading-relaxed text-white/75">{item.excerpt}</p>}
        </Container>
        <div className="thread" aria-hidden="true" />
      </header>

      <Container className="max-w-4xl py-12 lg:py-16">
        {item.image && <Photo img={imageBySrc(item.image)} className="aspect-[16/9] rounded-2xl" sizes="(min-width: 1024px) 56rem, 100vw" priority />}
        {item.isSample && <PlaceholderNote className="mt-8">This is a sample article with an illustrative photograph. It does not describe a real event.</PlaceholderNote>}
        <div className="prose-body mt-8 text-lg text-ink">
          {paragraphs.map((p, i) => (
            <p key={i} className="whitespace-pre-line">
              {p}
            </p>
          ))}
        </div>
        <p className="mt-12 border-t border-line pt-8">
          <Link href="/news" className="group inline-flex items-center gap-2 text-sm font-semibold text-brand hover:text-accent">
            <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" aria-hidden="true" />
            <T en="All news" bn="সকল সংবাদ" />
          </Link>
        </p>
      </Container>
    </article>
  );
}
