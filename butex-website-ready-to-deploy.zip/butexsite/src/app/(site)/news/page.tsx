import type { Metadata } from "next";
import { NewsCard } from "@/components/cards";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Container, EmptyState, PlaceholderNote } from "@/components/ui";
import { getNews } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "News & Announcements",
  description: "The latest news and announcements from Bangladesh University of Textiles.",
  alternates: { canonical: "/news" },
};

export default async function NewsPage() {
  const news = await getNews();
  return (
    <>
      <PageHero
        title={{ en: "News & Announcements", bn: "সংবাদ ও ঘোষণা" }}
        eyebrow={<T en="Latest from BUTEX" bn="বুটেক্সের সর্বশেষ" />}
        lead="Stories from across the university: research, teaching, events and student achievement."
        crumbs={[{ label: { en: "News", bn: "সংবাদ" } }]}
      />
      <Container className="py-12 lg:py-16">
        {news.length === 0 ? (
          <EmptyState title="No news has been published yet.">Stories will appear here as soon as the news desk publishes them.</EmptyState>
        ) : (
          <ul className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {news.map((item, i) => (
              <li key={item.id}>
                <NewsCard item={item} priority={i < 3} />
              </li>
            ))}
          </ul>
        )}
        {news.some((n) => n.isSample) && (
          <PlaceholderNote className="mt-10">Stories marked “Sample” are placeholder articles with illustrative photographs. They do not describe real events.</PlaceholderNote>
        )}
      </Container>
    </>
  );
}
