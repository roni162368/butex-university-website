import type { Metadata } from "next";
import { Award, Eye, Quote, ShieldCheck, Target, UserRound } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Container, PageSection, Photo, PlaceholderNote, SectionNav } from "@/components/ui";
import { getContent } from "@/lib/data";
import { lines, pairs } from "@/lib/format";
import { IMAGES } from "@/lib/images";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "About BUTEX",
  description: "The history, mission and vision, leadership and recognition of Bangladesh University of Textiles (BUTEX).",
  alternates: { canonical: "/about" },
};

const SECTIONS = [
  { id: "history", label: { en: "History", bn: "ইতিহাস" } },
  { id: "mission", label: { en: "Mission & Vision", bn: "মিশন ও ভিশন" } },
  { id: "leadership", label: { en: "Leadership", bn: "নেতৃত্ব" } },
  { id: "vc-message", label: { en: "Vice Chancellor's Message", bn: "উপাচার্যের বাণী" } },
  { id: "achievements", label: { en: "Achievements", bn: "অর্জন" } },
  { id: "accreditation", label: { en: "Accreditation & Recognition", bn: "স্বীকৃতি" } },
];

export default async function AboutPage() {
  const content = await getContent();
  const timeline = pairs(content.history_timeline);
  const leadership = pairs(content.leadership);
  const achievements = lines(content.achievements);
  const accreditations = pairs(content.accreditation_list);
  const vcMessage = content.vc_message.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);

  return (
    <>
      <PageHero
        title={{ en: "About BUTEX", bn: "বুটেক্স সম্পর্কে" }}
        eyebrow={<T en="Our university" bn="আমাদের বিশ্ববিদ্যালয়" />}
        lead="A public university for textile engineering, with roots in a weaving school founded in Dhaka in 1921."
        crumbs={[{ label: { en: "About BUTEX", bn: "বুটেক্স সম্পর্কে" } }]}
        image={IMAGES.campusAcademic}
      />

      <Container className="grid gap-10 py-14 lg:grid-cols-[15rem_1fr] lg:gap-16 lg:py-20">
        <SectionNav items={SECTIONS} />

        <div className="min-w-0 space-y-16">
          <PageSection id="history" title={{ en: "History", bn: "ইতিহাস" }} eyebrow={<T en="Since 1921" bn="১৯২১ সাল থেকে" />}>
            <div className="grid gap-10 xl:grid-cols-[1.2fr_1fr]">
              <p className="text-lg leading-relaxed text-muted">{content.about_summary}</p>
              <Photo img={IMAGES.campusOld} className="aspect-[4/3] rounded-2xl" sizes="(min-width: 1280px) 30vw, 100vw" />
            </div>
            <ol className="mt-12 border-l border-line">
              {timeline.map((item) => (
                <li key={`${item.left}-${item.right.slice(0, 12)}`} className="relative grid gap-1 pb-9 pl-8 last:pb-0 sm:grid-cols-[6rem_1fr] sm:gap-6">
                  <span className="absolute -left-[5px] top-3 size-[9px] rounded-full bg-gold-500 ring-4 ring-bg" aria-hidden="true" />
                  <span className="font-serif text-3xl leading-none text-accent">{item.left}</span>
                  <p className="leading-relaxed text-ink">{item.right}</p>
                </li>
              ))}
            </ol>
            <PlaceholderNote className="mt-10">
              Timeline compiled from publicly available sources, including the university&apos;s published short history. It is pending review by the university before launch.
            </PlaceholderNote>
          </PageSection>

          <PageSection id="mission" title={{ en: "Mission & Vision", bn: "মিশন ও ভিশন" }}>
            <div className="grid gap-6 md:grid-cols-2">
              {[
                { icon: Target, en: "Mission", bn: "মিশন", text: content.mission },
                { icon: Eye, en: "Vision", bn: "ভিশন", text: content.vision },
              ].map((block) => (
                <article key={block.en} className="rounded-2xl border border-line bg-surface p-7 sm:p-8">
                  <block.icon className="size-7 text-accent" aria-hidden="true" />
                  <h3 className="mt-4 font-serif text-2xl text-brand">
                    <T en={block.en} bn={block.bn} />
                  </h3>
                  {block.text ? (
                    <p className="mt-3 whitespace-pre-line leading-relaxed text-muted">{block.text}</p>
                  ) : (
                    <PlaceholderNote className="mt-4">The official {block.en.toLowerCase()} statement will be published here once supplied by the university.</PlaceholderNote>
                  )}
                </article>
              ))}
            </div>
          </PageSection>

          <PageSection id="leadership" title={{ en: "Leadership", bn: "নেতৃত্ব" }}>
            <p className="max-w-2xl leading-relaxed text-muted">The university is led by its principal officers. Names are published only after confirmation by the Office of the Registrar.</p>
            <ul className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {leadership.map((person) => (
                <li key={person.left} className="flex items-center gap-4 rounded-2xl border border-line bg-surface p-5">
                  <span className="flex size-14 shrink-0 items-center justify-center rounded-full bg-surface-2 text-muted">
                    <UserRound className="size-6" aria-hidden="true" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-accent">{person.left}</span>
                    {person.right ? (
                      <span className="mt-1 block font-serif text-lg leading-snug text-brand">{person.right}</span>
                    ) : (
                      <span className="mt-1 block text-sm italic text-muted">Name to be confirmed</span>
                    )}
                  </span>
                </li>
              ))}
            </ul>
          </PageSection>

          <PageSection id="vc-message" title={{ en: "Vice Chancellor's Message", bn: "উপাচার্যের বাণী" }}>
            <figure className="relative overflow-hidden rounded-2xl bg-navy-900 p-8 text-white sm:p-12">
              <div className="weave absolute inset-0" aria-hidden="true" />
              <div className="relative grid gap-8 md:grid-cols-[auto_1fr] md:gap-12">
                <div className="flex items-center gap-4 md:block">
                  <span className="flex size-24 items-center justify-center rounded-full border border-gold-500/40 bg-navy-800 text-gold-300 md:size-32">
                    <UserRound className="size-10 md:size-14" aria-hidden="true" />
                  </span>
                  <figcaption className="md:mt-5">
                    <span className="block font-serif text-xl">{content.vc_name || "Name to be confirmed"}</span>
                    <span className="mt-1 block text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-gold-300">
                      <T en="Vice Chancellor" bn="উপাচার্য" />
                    </span>
                  </figcaption>
                </div>
                <blockquote>
                  <Quote className="size-9 text-gold-400" aria-hidden="true" />
                  {vcMessage.length > 0 ? (
                    <div className="prose-body mt-5 text-lg text-white/85">
                      {vcMessage.map((p) => (
                        <p key={p.slice(0, 24)}>{p}</p>
                      ))}
                    </div>
                  ) : (
                    <p className="mt-5 text-lg leading-relaxed text-white/70">
                      The Vice Chancellor&apos;s message will be published here once the official text and portrait have been supplied by the Office of the Vice Chancellor.
                    </p>
                  )}
                </blockquote>
              </div>
            </figure>
          </PageSection>

          <PageSection id="achievements" title={{ en: "University Achievements", bn: "বিশ্ববিদ্যালয়ের অর্জন" }}>
            {achievements.length > 0 ? (
              <ul className="grid gap-4 sm:grid-cols-2">
                {achievements.map((a) => (
                  <li key={a} className="flex gap-4 rounded-2xl border border-line bg-surface p-6">
                    <Award className="mt-0.5 size-6 shrink-0 text-accent" aria-hidden="true" />
                    <p className="leading-relaxed text-ink">{a}</p>
                  </li>
                ))}
              </ul>
            ) : (
              <PlaceholderNote>
                Verified achievements, such as rankings, awards and institutional milestones, will be listed here once confirmed by the university. Nothing is shown until it can be attributed to an official source.
              </PlaceholderNote>
            )}
          </PageSection>

          <PageSection id="accreditation" title={{ en: "Accreditation & Institutional Recognition", bn: "স্বীকৃতি ও প্রাতিষ্ঠানিক অনুমোদন" }}>
            <div className="flex gap-5 rounded-2xl border border-line bg-surface p-7 sm:p-8">
              <ShieldCheck className="mt-1 size-7 shrink-0 text-accent" aria-hidden="true" />
              <p className="whitespace-pre-line text-lg leading-relaxed text-ink">{content.accreditation}</p>
            </div>
            {accreditations.length > 0 ? (
              <dl className="mt-6 divide-y divide-line rounded-2xl border border-line bg-surface">
                {accreditations.map((a) => (
                  <div key={a.left} className="grid gap-1 px-6 py-4 sm:grid-cols-[14rem_1fr] sm:gap-6">
                    <dt className="font-semibold text-brand">{a.left}</dt>
                    <dd className="text-muted">{a.right}</dd>
                  </div>
                ))}
              </dl>
            ) : (
              <PlaceholderNote className="mt-6">Program-level accreditation and professional-body memberships will be listed here after verification.</PlaceholderNote>
            )}
          </PageSection>
        </div>
      </Container>
    </>
  );
}
