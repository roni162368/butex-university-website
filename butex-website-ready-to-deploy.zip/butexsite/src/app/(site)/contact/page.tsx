import type { Metadata } from "next";
import { Clock, ExternalLink, Mail, MapPin, Phone, Printer } from "lucide-react";
import { ContactForm } from "@/components/contact-form";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Container, Eyebrow, PlaceholderNote } from "@/components/ui";
import { getContent } from "@/lib/data";
import { lines } from "@/lib/format";
import { IMAGES } from "@/lib/images";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Contact",
  description: "Address, phone, email and location of Bangladesh University of Textiles, Tejgaon Industrial Area, Dhaka-1208.",
  alternates: { canonical: "/contact" },
};

export default async function ContactPage() {
  const content = await getContent();
  const address = lines(content.contact_address);

  return (
    <>
      <PageHero
        title={{ en: "Contact", bn: "যোগাযোগ" }}
        eyebrow={<T en="Get in touch" bn="যোগাযোগ করুন" />}
        lead="Reach the university by phone, email or post, or send a message using the form below."
        crumbs={[{ label: { en: "Contact", bn: "যোগাযোগ" } }]}
        image={IMAGES.campusAcademic}
      />

      <Container className="grid gap-12 py-14 lg:grid-cols-[1fr_1.25fr] lg:gap-16 lg:py-20">
        <div>
          <Eyebrow>
            <T en="University contact information" bn="বিশ্ববিদ্যালয়ের যোগাযোগের তথ্য" />
          </Eyebrow>
          <h2 className="mt-4 font-serif text-3xl leading-tight text-brand sm:text-4xl">
            <T en={SITE.name} bn={SITE.nameBn} />
          </h2>
          <ul className="mt-8 space-y-4">
            <li className="flex gap-4 rounded-2xl border border-line bg-surface p-5">
              <MapPin className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
              <div>
                <p className="text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-muted">Address</p>
                <address className="mt-1 not-italic leading-relaxed text-ink">
                  {address.map((l) => (
                    <span key={l} className="block">
                      {l}
                    </span>
                  ))}
                </address>
              </div>
            </li>
            {content.contact_phone && (
              <li className="flex gap-4 rounded-2xl border border-line bg-surface p-5">
                <Phone className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
                <div>
                  <p className="text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-muted">Phone</p>
                  <a href={`tel:${content.contact_phone.replace(/[^\d+]/g, "")}`} className="mt-1 block text-ink hover:text-accent">
                    {content.contact_phone}
                  </a>
                </div>
              </li>
            )}
            {content.contact_email && (
              <li className="flex gap-4 rounded-2xl border border-line bg-surface p-5">
                <Mail className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
                <div>
                  <p className="text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-muted">Email</p>
                  <a href={`mailto:${content.contact_email}`} className="mt-1 block break-all text-ink hover:text-accent">
                    {content.contact_email}
                  </a>
                </div>
              </li>
            )}
            {content.contact_fax && (
              <li className="flex gap-4 rounded-2xl border border-line bg-surface p-5">
                <Printer className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
                <div>
                  <p className="text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-muted">Fax</p>
                  <p className="mt-1 text-ink">{content.contact_fax}</p>
                </div>
              </li>
            )}
            <li className="flex gap-4 rounded-2xl border border-line bg-surface p-5">
              <Clock className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
              <div className="min-w-0 flex-1">
                <p className="text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-muted">Office hours</p>
                {content.office_hours ? <p className="mt-1 whitespace-pre-line text-ink">{content.office_hours}</p> : <p className="mt-1 text-sm italic text-muted">To be confirmed by the university.</p>}
              </div>
            </li>
          </ul>
          <PlaceholderNote className="mt-6">Direct contacts for individual offices (Registrar, Controller of Examinations, departments and halls) will be added once supplied.</PlaceholderNote>
        </div>

        <div>
          <Eyebrow>
            <T en="Send a message" bn="বার্তা পাঠান" />
          </Eyebrow>
          <h2 className="mt-4 font-serif text-3xl leading-tight text-brand sm:text-4xl">
            <T en="How can we help?" bn="আমরা কীভাবে সাহায্য করতে পারি?" />
          </h2>
          <p className="mt-3 leading-relaxed text-muted">Messages are stored securely and are visible to authorized staff in the admin dashboard.</p>
          <div className="mt-8">
            <ContactForm />
          </div>
        </div>
      </Container>

      <section aria-labelledby="map-title" className="border-t border-line bg-surface">
        <Container className="py-14">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <h2 id="map-title" className="font-serif text-3xl text-brand">
              <T en="Find us" bn="অবস্থান" />
            </h2>
            <a href={SITE.mapsLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm font-semibold text-brand transition hover:text-accent">
              Open in Google Maps <ExternalLink className="size-3.5" aria-hidden="true" />
            </a>
          </div>
          <div className="mt-6 overflow-hidden rounded-2xl border border-line">
            <iframe src={SITE.mapsEmbed} title="Google Map showing Bangladesh University of Textiles" loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="block h-[26rem] w-full border-0" />
          </div>
        </Container>
      </section>
    </>
  );
}
