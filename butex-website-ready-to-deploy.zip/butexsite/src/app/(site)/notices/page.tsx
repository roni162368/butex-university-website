import type { Metadata } from "next";
import { NoticeBoard } from "@/components/notice-board";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Container } from "@/components/ui";
import { getNotices } from "@/lib/data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Notice Board",
  description: "Academic, examination, admission and administrative notices and announcements from Bangladesh University of Textiles, with downloadable PDF attachments.",
  alternates: { canonical: "/notices" },
};

type Props = { searchParams: Promise<{ category?: string | string[]; q?: string | string[] }> };
const first = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";

export default async function NoticesPage({ searchParams }: Props) {
  const params = await searchParams;
  const category = first(params.category);
  const q = first(params.q).slice(0, 80);
  const notices = await getNotices();

  return (
    <>
      <PageHero
        title={{ en: "Notice Board", bn: "নোটিশ বোর্ড" }}
        eyebrow={<T en="Official notices" bn="অফিসিয়াল নোটিশ" />}
        lead="Search and filter notices by category. Attachments open as PDF."
        crumbs={[{ label: { en: "Notice Board", bn: "নোটিশ বোর্ড" } }]}
      />
      <Container className="max-w-5xl py-12 lg:py-16">
        <NoticeBoard key={`${category}|${q}`} notices={notices} initialCategory={category} initialQuery={q} />
      </Container>
    </>
  );
}
