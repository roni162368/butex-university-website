import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CalendarDays, Download, FileText } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Badge, Container, PlaceholderNote, SampleBadge } from "@/components/ui";
import { getNotice } from "@/lib/data";
import { fmtDate } from "@/lib/format";
import { noticeCategory } from "@/lib/site";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

async function load(raw: string) {
  const id = Number(raw);
  if (!Number.isInteger(id) || id < 1 || id > 2147483647) return null;
  return getNotice(id);
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const notice = await load((await params).id);
  if (!notice) return { title: "Notice not found" };
  return { title: notice.title, description: notice.summary || `Notice published on ${fmtDate(notice.publishedAt)}.`, robots: notice.isSample ? { index: false } : undefined };
}

export default async function NoticePage({ params }: Props) {
  const notice = await load((await params).id);
  if (!notice) notFound();
  const category = noticeCategory(notice.category);
  const paragraphs = notice.body.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);

  return (
    <>
      <PageHero
        title={{ en: notice.title }}
        crumbs={[{ label: { en: "Notice Board", bn: "নোটিশ বোর্ড" }, href: "/notices" }, { label: { en: category.en, bn: category.bn }, href: `/notices?category=${notice.category}` }, { label: { en: "Notice" } }]}
      >
        <div className="flex flex-wrap items-center gap-3 text-sm text-white/75">
          <Badge tone="goldOnDark">
            <T en={category.en} bn={category.bn} />
          </Badge>
          {notice.isSample && <SampleBadge onDark />}
          <span className="inline-flex items-center gap-2">
            <CalendarDays className="size-4 text-gold-300" aria-hidden="true" />
            <time dateTime={notice.publishedAt.toISOString()}>{fmtDate(notice.publishedAt)}</time>
          </span>
        </div>
      </PageHero>

      <Container className="max-w-4xl py-12 lg:py-16">
        {notice.isSample && <PlaceholderNote className="mb-8">This is a sample notice used to demonstrate the notice board. It is not an official announcement.</PlaceholderNote>}

        {notice.summary && <p className="text-xl leading-relaxed text-ink">{notice.summary}</p>}
        {paragraphs.length > 0 && (
          <div className="prose-body mt-6 text-muted">
            {paragraphs.map((p, i) => (
              <p key={i} className="whitespace-pre-line">
                {p}
              </p>
            ))}
          </div>
        )}

        {notice.fileId && (
          <div className="mt-10 flex flex-col gap-4 rounded-2xl border border-line bg-surface p-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex min-w-0 items-center gap-4">
              <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-gold-500/15 text-accent">
                <FileText className="size-6" aria-hidden="true" />
              </span>
              <div className="min-w-0">
                <p className="text-[0.7rem] font-semibold uppercase tracking-[0.16em] text-muted">Attachment · PDF</p>
                <p className="truncate font-semibold text-ink">{notice.fileName || "Notice attachment"}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <a href={`/api/files/${notice.fileId}`} target="_blank" rel="noopener" className="inline-flex items-center justify-center gap-2 rounded-full border border-line px-5 py-2.5 text-sm font-semibold text-brand transition hover:border-gold-500 hover:text-accent">
                View
              </a>
              <a href={`/api/files/${notice.fileId}?download=1`} className="inline-flex items-center justify-center gap-2 rounded-full bg-navy-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-navy-700 dark:bg-gold-500 dark:text-navy-950">
                <Download className="size-4" aria-hidden="true" /> Download PDF
              </a>
            </div>
          </div>
        )}

        <p className="mt-12 border-t border-line pt-8">
          <Link href="/notices" className="group inline-flex items-center gap-2 text-sm font-semibold text-brand hover:text-accent">
            <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" aria-hidden="true" />
            <T en="Back to the notice board" bn="নোটিশ বোর্ডে ফিরে যান" />
          </Link>
        </p>
      </Container>
    </>
  );
}
