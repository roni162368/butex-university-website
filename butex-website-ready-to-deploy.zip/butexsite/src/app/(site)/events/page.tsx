import type { Metadata } from "next";
import { EventsCalendar, type CalendarEvent } from "@/components/events-calendar";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Container, PlaceholderNote } from "@/components/ui";
import { getEvents } from "@/lib/data";
import { dateKey } from "@/lib/format";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Events Calendar",
  description: "University events, academic dates and national observances at Bangladesh University of Textiles.",
  alternates: { canonical: "/events" },
};

export default async function EventsPage() {
  const rows = await getEvents();
  const events: CalendarEvent[] = rows.map((e) => ({
    id: e.id,
    title: e.title,
    description: e.description,
    location: e.location,
    category: e.category,
    startsAt: e.startsAt.toISOString(),
    endsAt: e.endsAt ? e.endsAt.toISOString() : null,
    isSample: e.isSample,
  }));

  return (
    <>
      <PageHero
        title={{ en: "Events Calendar", bn: "ইভেন্ট ক্যালেন্ডার" }}
        eyebrow={<T en="What's on" bn="কী হচ্ছে" />}
        lead="Seminars, ceremonies, student activities and national observances through the year."
        crumbs={[{ label: { en: "Events", bn: "ইভেন্ট" } }]}
      />
      <Container className="py-12 lg:py-16">
        <EventsCalendar events={events} today={dateKey(new Date())} />
        {events.some((e) => e.isSample) && (
          <PlaceholderNote className="mt-10">Entries marked “Sample” are placeholder events that demonstrate the calendar. National observances are shown on their actual dates.</PlaceholderNote>
        )}
      </Container>
    </>
  );
}
