import Image from "next/image";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, BellRing, BookOpen, GraduationCap, Landmark, MessageSquareQuote, Target, UserRound, Users } from "lucide-react";
import { DepartmentCard, EventRow, NewsCard, NoticeRow } from "@/components/cards";
import { HeroSlider, type Slide } from "@/components/hero-slider";
import { Reveal } from "@/components/reveal";
import { StatCounter } from "@/components/stat-counter";
import { T } from "@/components/t";
import { ButtonLink, Container, EmptyState, Eyebrow, Photo, SectionHeading, TextLink } from "@/components/ui";
import { getContent, getDepartments, getNews, getNotices, getStats, getUpcomingEvents } from "@/lib/data";
import { IMAGES, creditLine, type Img } from "@/lib/images";
import { RESEARCH_THEMES } from "@/lib/research";
import { SITE } from "@/lib/site";

export const dynamic = "force-dynamic";

const slide = (img: Img, label: string): Slide => ({ src: img.src, alt: img.alt, label, credit: creditLine(img) });

const SLIDES: Slide[] = [
  slide(IMAGES.campusOld, "Old academic building, BUTEX campus"),
  slide(IMAGES.spinningFloor, "Spinning technology"),
  slide(IMAGES.campusAcademic, "Academic building, BUTEX campus"),
  slide(IMAGES.labResearch, "Laboratory research"),
  slide(IMAGES.shaheedMinar, "Shaheed Minar, BUTEX campus"),
];

const QUICK_LINKS = [
  { href: "/admission", icon: GraduationCap, en: "Admission", bn: "ভর্তি", desc: "Circulars, eligibility, dates and results." },
  { href: "/academics", icon: BookOpen, en: "Academic Programs", bn: "একাডেমিক প্রোগ্রাম", desc: "Programs, calendar and documents." },
  { href: "/notices", icon: BellRing, en: "Notice Board", bn: "নোটিশ বোর্ড", desc: "Academic, exam and administrative notices." },
  { href: "/portal", icon: UserRound, en: "Student Portal", bn: "স্টুডেন্ট পোর্টাল", desc: "Routine, results and course materials." },
];

const ABOUT_LINKS = [
  { href: "/about#history", icon: Landmark, en: "History", bn: "ইতিহাস", desc: "From weaving school to university." },
  { href: "/about#mission", icon: Target, en: "Mission & Vision", bn: "মিশন ও ভিশন", desc: "What guides the university." },
  { href: "/about#leadership", icon: Users, en: "Leadership", bn: "নেতৃত্ব", desc: "The university's principal officers." },
  { href: "/about#vc-message", icon: MessageSquareQuote, en: "Vice Chancellor's Message", bn: "উপাচার্যের বাণী", desc: "A word from the Vice Chancellor." },
];

const CAMPUS_TILES = [
  { img: IMAGES.shaheedMinar, href: "/campus-life#events", en: "Heritage & observances", bn: "ঐতিহ্য ও দিবস", className: "col-span-2 aspect-[4/3] lg:row-span-2 lg:aspect-auto" },
  { img: IMAGES.campusAcademic, href: "/campus-life#facilities", en: "Campus facilities", bn: "ক্যাম্পাস সুবিধা", className: "aspect-square lg:aspect-auto" },
  { img: IMAGES.sportsField, href: "/campus-life#sports", en: "Sports & culture", bn: "ক্রীড়া ও সংস্কৃতি", className: "aspect-square lg:aspect-auto" },
  { img: IMAGES.graduates, href: "/campus-life#organizations", en: "Student community", bn: "শিক্ষার্থী সমাজ", className: "col-span-2 aspect-[2/1] lg:aspect-auto" },
];

export default async function HomePage() {
  const [content, stats, departments, notices, events, news] = await Promise.all([
    getContent(),
    getStats(),
    getDepartments(),
    getNotices(5),
    getUpcomingEvents(4),
    getNews(3),
  ]);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "CollegeOrUniversity",
    name: SITE.name,
    alternateName: ["BUTEX", SITE.nameBn],
    url: SITE.officialUrl,
    description: SITE.description,
    email: content.contact_email,
    telephone: content.contact_phone,
    address: {
      "@type": "PostalAddress",
      streetAddress: "92 Shaheed Tajuddin Ahmed Avenue, Tejgaon Industrial Area",
      addressLocality: "Dhaka",
      postalCode: "1208",
      addressCountry: "BD",
    },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />

      {/* Hero */}
      <HeroSlider slides={SLIDES}>
        <div className="max-w-3xl animate-fade-up">
          <Eyebrow light>
            <T en={SITE.name} bn={SITE.nameBn} />
          </Eyebrow>
          <h1 className="mt-6 font-serif text-[2.7rem] leading-[1.03] tracking-tight sm:text-6xl lg:text-7xl xl:text-[5.25rem]">
            <T
              en={
                <>
                  Engineering the <em className="font-normal italic text-gold-300">Future</em> of Textiles.
                </>
              }
              bn="প্রকৌশলে গড়ি টেক্সটাইলের ভবিষ্যৎ।"
            />
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/80">
            <T en={content.hero_intro} bn={content.hero_intro_bn} />
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <ButtonLink href="/about" variant="gold">
              <T en="Explore BUTEX" bn="বুটেক্স ঘুরে দেখুন" />
              <ArrowRight className="size-4" aria-hidden="true" />
            </ButtonLink>
            <ButtonLink href="/academics" variant="light">
              <T en="Academic Programs" bn="একাডেমিক প্রোগ্রাম" />
            </ButtonLink>
          </div>
        </div>
      </HeroSlider>

      {/* Quick access */}
      <Container className="relative z-10 -mt-10">
        <ul className="grid grid-cols-2 overflow-hidden rounded-2xl border border-line bg-surface shadow-lift lg:grid-cols-4">
          {QUICK_LINKS.map((q) => (
            <li key={q.href} className="border-b border-r border-line even:border-r-0 lg:border-b-0 lg:even:border-r lg:last:border-r-0 [&:nth-last-child(-n+2)]:border-b-0">
              <Link href={q.href} className="group flex h-full flex-col gap-2 p-5 transition hover:bg-surface-2 sm:p-7">
                <span className="flex items-center justify-between">
                  <q.icon className="size-6 text-accent" aria-hidden="true" />
                  <ArrowUpRight className="size-4 text-muted transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-accent" aria-hidden="true" />
                </span>
                <span className="mt-2 font-serif text-lg leading-tight text-brand sm:text-xl">
                  <T en={q.en} bn={q.bn} />
                </span>
                <span className="hidden text-sm leading-relaxed text-muted sm:block">{q.desc}</span>
              </Link>
            </li>
          ))}
        </ul>
      </Container>

      {/* University at a glance */}
      <section aria-labelledby="glance-title" className="py-20 lg:py-28">
        <Container className="grid gap-12 lg:grid-cols-[0.85fr_2fr] lg:gap-16">
          <Reveal>
            <Eyebrow>
              <T en="University at a glance" bn="এক নজরে বিশ্ববিদ্যালয়" />
            </Eyebrow>
            <h2 id="glance-title" className="mt-4 font-serif text-3xl leading-[1.12] tracking-tight text-brand sm:text-4xl">
              <T en="BUTEX in numbers." bn="সংখ্যায় বুটেক্স।" />
            </h2>
            <p className="mt-4 leading-relaxed text-muted">
              <T
                en="Figures appear here only once they have been verified by the university. Until then, each tile shows a clearly marked placeholder rather than an estimate."
                bn="বিশ্ববিদ্যালয় কর্তৃক যাচাইয়ের পরেই এখানে পরিসংখ্যান প্রকাশিত হয়। ততদিন প্রতিটি ঘরে অনুমানের পরিবর্তে স্পষ্টভাবে চিহ্নিত স্থানধারক দেখানো হচ্ছে।"
              />
            </p>
          </Reveal>
          <Reveal>
            <ul className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-3">
              {stats.map((s) => (
                <li key={s.key} className="flex min-h-40 flex-col justify-between bg-surface p-6 sm:p-8">
                  <p className="font-serif text-5xl leading-none tracking-tight text-brand lg:text-6xl">
                    {s.value !== null ? <StatCounter value={s.value} suffix={s.suffix} /> : <span className="text-gold-500/70" aria-hidden="true">—</span>}
                  </p>
                  <div className="mt-5">
                    <p className="text-sm font-medium leading-snug text-ink">
                      <T en={s.label} bn={s.labelBn} />
                    </p>
                    {s.value === null && (
                      <p className="mt-1.5 text-[0.7rem] font-semibold uppercase tracking-[0.14em] text-accent">
                        <T en="Awaiting verified figure" bn="যাচাইকৃত তথ্যের অপেক্ষায়" />
                      </p>
                    )}
                  </div>
                </li>
              ))}
              <li className="bg-navy-900">
                <Link href="/research" className="weave group flex h-full min-h-40 flex-col justify-between p-6 text-white transition hover:bg-navy-800 sm:p-8">
                  <ArrowUpRight className="size-6 text-gold-400 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
                  <span>
                    <span className="block font-serif text-xl leading-snug">
                      <T en="Research & innovation highlights" bn="গবেষণা ও উদ্ভাবনের দিকসমূহ" />
                    </span>
                    <span className="mt-1.5 block text-sm text-white/65">
                      <T en="Eight themes, from automation to smart textiles." bn="অটোমেশন থেকে স্মার্ট টেক্সটাইল — আটটি ক্ষেত্র।" />
                    </span>
                  </span>
                </Link>
              </li>
            </ul>
          </Reveal>
        </Container>
      </section>

      {/* About */}
      <section aria-labelledby="about-title" className="border-y border-line bg-surface py-20 lg:py-28">
        <Container className="grid items-center gap-16 lg:grid-cols-2 lg:gap-20">
          <Reveal className="relative pb-10 sm:pr-6">
            <Photo img={IMAGES.campusAerial} className="aspect-[4/3] rounded-2xl" sizes="(min-width: 1024px) 45vw, 100vw" creditLeft />
            <div className="absolute bottom-0 right-0 hidden w-52 sm:block lg:w-60">
              <Photo img={IMAGES.campusOld} className="aspect-[4/3] rounded-xl border-4 border-surface shadow-lift" sizes="240px" credit={false} />
            </div>
            <div className="absolute -left-2 -top-5 rounded-xl bg-navy-900 px-5 py-4 text-white shadow-lift sm:-left-5">
              <p className="text-[0.62rem] font-semibold uppercase tracking-[0.2em] text-gold-300">
                <T en="Roots since" bn="সূচনা" />
              </p>
              <p className="font-serif text-4xl leading-tight">1921</p>
            </div>
          </Reveal>
          <Reveal>
            <Eyebrow>
              <T en="About BUTEX" bn="বুটেক্স সম্পর্কে" />
            </Eyebrow>
            <h2 id="about-title" className="mt-4 font-serif text-3xl leading-[1.12] tracking-tight text-brand sm:text-4xl lg:text-[2.75rem]">
              <T en="A century of textile education. A university since 2010." bn="টেক্সটাইল শিক্ষার এক শতাব্দী। ২০১০ সাল থেকে বিশ্ববিদ্যালয়।" />
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-muted">{content.about_summary}</p>
            <ul className="mt-8 grid gap-x-8 gap-y-6 sm:grid-cols-2">
              {ABOUT_LINKS.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="group flex gap-4">
                    <span className="flex size-11 shrink-0 items-center justify-center rounded-full border border-line bg-bg text-accent transition group-hover:border-gold-500 group-hover:bg-gold-500/10">
                      <l.icon className="size-5" aria-hidden="true" />
                    </span>
                    <span>
                      <span className="block font-semibold text-ink transition group-hover:text-accent">
                        <T en={l.en} bn={l.bn} />
                      </span>
                      <span className="mt-0.5 block text-sm text-muted">{l.desc}</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
            <div className="mt-10">
              <ButtonLink href="/about">
                <T en="Discover our story" bn="আমাদের গল্প জানুন" />
                <ArrowRight className="size-4" aria-hidden="true" />
              </ButtonLink>
            </div>
          </Reveal>
        </Container>
      </section>

      {/* Departments */}
      <section aria-label="Academic departments" className="py-20 lg:py-28">
        <Container>
          <SectionHeading
            eyebrow={<T en="Academic departments" bn="একাডেমিক বিভাগসমূহ" />}
            title={<T en="Nine departments, one discipline from end to end." bn="নয়টি বিভাগ, একটি পূর্ণাঙ্গ শিক্ষাক্ষেত্র।" />}
            lead={
              <T
                en="From fiber and yarn to fashion, chemistry, environment and machinery, each department covers a distinct stage of the textile value chain."
                bn="তন্তু ও সুতা থেকে ফ্যাশন, রসায়ন, পরিবেশ ও যন্ত্রপাতি — প্রতিটি বিভাগ টেক্সটাইল ভ্যালু চেইনের একটি স্বতন্ত্র ধাপ নিয়ে কাজ করে।"
              />
            }
            action={
              <TextLink href="/departments">
                <T en="All departments" bn="সকল বিভাগ" />
              </TextLink>
            }
          />
          <ul className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {departments.map((d, i) => (
              <li key={d.slug}>
                <Reveal className="h-full" delay={(i % 3) * 90}>
                  <DepartmentCard department={d} />
                </Reveal>
              </li>
            ))}
          </ul>
        </Container>
      </section>

      {/* Research */}
      <section aria-labelledby="research-title" className="relative overflow-hidden bg-navy-900 text-white">
        <div className="weave absolute inset-0" aria-hidden="true" />
        <Container className="relative grid gap-14 py-20 lg:grid-cols-[1fr_1.3fr] lg:gap-20 lg:py-28">
          <Reveal>
            <Eyebrow light>
              <T en="Research & innovation" bn="গবেষণা ও উদ্ভাবন" />
            </Eyebrow>
            <h2 id="research-title" className="mt-4 font-serif text-3xl leading-[1.1] tracking-tight sm:text-4xl lg:text-5xl">
              <T en="Research for the mills, materials and markets of tomorrow." bn="আগামীর কারখানা, উপকরণ ও বাজারের জন্য গবেষণা।" />
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-white/70">{content.research_intro}</p>
            <div className="mt-8">
              <ButtonLink href="/research" variant="gold">
                <T en="Explore research" bn="গবেষণা দেখুন" />
                <ArrowRight className="size-4" aria-hidden="true" />
              </ButtonLink>
            </div>
            <Photo img={IMAGES.labResearch} className="mt-12 hidden aspect-[16/10] rounded-2xl lg:block" sizes="40vw" />
          </Reveal>
          <Reveal>
            <ul className="grid gap-px self-start overflow-hidden rounded-2xl border border-white/10 bg-white/10 sm:grid-cols-2">
              {RESEARCH_THEMES.map((theme) => (
                <li key={theme.id} className="bg-navy-900">
                  <Link href={`/research#${theme.id}`} className="group flex h-full flex-col p-6 transition hover:bg-navy-800 sm:p-7">
                    <theme.icon className="size-6 text-gold-400" aria-hidden="true" />
                    <span className="mt-4 flex items-center justify-between gap-3 font-serif text-xl leading-snug">
                      <T en={theme.title.en} bn={theme.title.bn} />
                      <ArrowUpRight className="size-4 shrink-0 text-white/40 transition group-hover:text-gold-300" aria-hidden="true" />
                    </span>
                    <span className="mt-2 text-sm leading-relaxed text-white/65">{theme.short}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </Reveal>
        </Container>
      </section>

      {/* Notices and events */}
      <section aria-label="Notices and events" className="py-20 lg:py-28">
        <Container className="grid gap-16 lg:grid-cols-[1.5fr_1fr]">
          <Reveal>
            <SectionHeading
              eyebrow={<T en="Notice board" bn="নোটিশ বোর্ড" />}
              title={<T en="Latest notices" bn="সর্বশেষ নোটিশ" />}
              action={
                <TextLink href="/notices">
                  <T en="All notices" bn="সকল নোটিশ" />
                </TextLink>
              }
            />
            {notices.length > 0 ? (
              <ul className="mt-8 divide-y divide-line border-y border-line">
                {notices.map((n) => (
                  <NoticeRow key={n.id} notice={n} />
                ))}
              </ul>
            ) : (
              <div className="mt-8">
                <EmptyState title="No notices have been published yet.">New notices will appear here as soon as they are issued.</EmptyState>
              </div>
            )}
          </Reveal>
          <Reveal>
            <SectionHeading
              eyebrow={<T en="Events" bn="ইভেন্ট" />}
              title={<T en="Coming up" bn="আসন্ন" />}
              action={
                <TextLink href="/events">
                  <T en="Full calendar" bn="পূর্ণ ক্যালেন্ডার" />
                </TextLink>
              }
            />
            {events.length > 0 ? (
              <ul className="mt-8 space-y-3">
                {events.map((e) => (
                  <EventRow key={e.id} event={e} />
                ))}
              </ul>
            ) : (
              <div className="mt-8">
                <EmptyState title="No upcoming events.">Check the full calendar for past and future dates.</EmptyState>
              </div>
            )}
          </Reveal>
        </Container>
      </section>

      {/* News */}
      {news.length > 0 && (
        <section aria-label="Latest news" className="border-y border-line bg-surface py-20 lg:py-28">
          <Container>
            <SectionHeading
              eyebrow={<T en="News & announcements" bn="সংবাদ ও ঘোষণা" />}
              title={<T en="Latest from BUTEX" bn="বুটেক্সের সর্বশেষ" />}
              action={
                <TextLink href="/news">
                  <T en="All news" bn="সকল সংবাদ" />
                </TextLink>
              }
            />
            <ul className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {news.map((item, i) => (
                <li key={item.id}>
                  <Reveal className="h-full" delay={i * 90}>
                    <NewsCard item={item} />
                  </Reveal>
                </li>
              ))}
            </ul>
          </Container>
        </section>
      )}

      {/* Campus life */}
      <section aria-label="Campus life" className="py-20 lg:py-28">
        <Container>
          <SectionHeading
            eyebrow={<T en="Campus life" bn="ক্যাম্পাস জীবন" />}
            title={<T en="A campus at the center of the industry." bn="শিল্পের কেন্দ্রে একটি ক্যাম্পাস।" />}
            lead={content.campus_intro}
            action={
              <TextLink href="/campus-life">
                <T en="Explore campus life" bn="ক্যাম্পাস জীবন দেখুন" />
              </TextLink>
            }
          />
          <Reveal>
            <ul className="mt-12 grid grid-cols-2 gap-4 lg:h-[34rem] lg:grid-cols-4 lg:grid-rows-2">
              {CAMPUS_TILES.map((tile) => (
                <li key={tile.href} className={tile.className}>
                  <Link href={tile.href} className="group relative block h-full overflow-hidden rounded-2xl bg-navy-900">
                    <Image src={tile.img.src} alt={tile.img.alt} fill sizes="(min-width: 1024px) 50vw, 100vw" className="object-cover transition duration-700 ease-out group-hover:scale-105" />
                    <span className="absolute inset-0 bg-gradient-to-t from-navy-950/85 via-navy-950/15 to-transparent" aria-hidden="true" />
                    <span className="absolute inset-x-0 bottom-0 p-4 sm:p-6">
                      <span className="flex items-center gap-2 font-serif text-lg leading-tight text-white sm:text-2xl">
                        <T en={tile.en} bn={tile.bn} />
                        <ArrowUpRight className="size-4 shrink-0 text-gold-300 opacity-0 transition group-hover:opacity-100" aria-hidden="true" />
                      </span>
                      <span className="mt-1 block truncate text-[0.625rem] text-white/60">{creditLine(tile.img)}</span>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </Reveal>
        </Container>
      </section>

      {/* Admission call to action */}
      <section aria-labelledby="admission-cta" className="relative isolate overflow-hidden bg-navy-900 text-white">
        <Image src={IMAGES.threads.src} alt="" fill sizes="100vw" className="-z-10 object-cover opacity-20" />
        <div className="absolute inset-0 -z-10 bg-gradient-to-r from-navy-950 via-navy-900/95 to-navy-900/70" aria-hidden="true" />
        <Container className="grid items-center gap-10 py-20 lg:grid-cols-[1.5fr_1fr] lg:py-24">
          <div>
            <Eyebrow light>
              <T en="Admission" bn="ভর্তি" />
            </Eyebrow>
            <h2 id="admission-cta" className="mt-4 font-serif text-3xl leading-[1.1] tracking-tight sm:text-4xl lg:text-5xl">
              <T en="Begin your journey in textile engineering." bn="টেক্সটাইল প্রকৌশলে আপনার যাত্রা শুরু করুন।" />
            </h2>
            <p className="mt-4 max-w-xl text-lg leading-relaxed text-white/70">{content.admission_intro}</p>
          </div>
          <div className="flex flex-wrap gap-3 lg:justify-end">
            <ButtonLink href="/admission" variant="gold">
              <T en="Admission information" bn="ভর্তি তথ্য" />
              <ArrowRight className="size-4" aria-hidden="true" />
            </ButtonLink>
            <ButtonLink href="/admission#circulars" variant="light">
              <T en="View circulars" bn="বিজ্ঞপ্তি দেখুন" />
            </ButtonLink>
          </div>
        </Container>
      </section>
    </>
  );
}
