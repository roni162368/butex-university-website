import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, BellRing, ChevronDown, ClipboardCheck, GraduationCap, ScrollText } from "lucide-react";
import { PageHero } from "@/components/page-hero";
import { T } from "@/components/t";
import { Badge, ButtonLink, Container, EmptyState, FileLink, PageSection, PlaceholderNote, SampleBadge, SectionNav } from "@/components/ui";
import type { AdmissionItem } from "@/db/schema";
import { getAdmissionItems, getContent, getNotices } from "@/lib/data";
import { fmtDate } from "@/lib/format";
import { IMAGES } from "@/lib/images";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Admission",
  description: "Undergraduate and postgraduate admission at BUTEX: circulars, eligibility requirements, application guidelines, results, important dates and FAQ.",
  alternates: { canonical: "/admission" },
};

const SECTIONS = [
  { id: "undergraduate", label: { en: "Undergraduate Admission", bn: "স্নাতক ভর্তি" } },
  { id: "postgraduate", label: { en: "Postgraduate Admission", bn: "স্নাতকোত্তর ভর্তি" } },
  { id: "circulars", label: { en: "Admission Circulars", bn: "ভর্তি বিজ্ঞপ্তি" } },
  { id: "eligibility", label: { en: "Eligibility Requirements", bn: "যোগ্যতা" } },
  { id: "guidelines", label: { en: "Application Guidelines", bn: "আবেদন নির্দেশিকা" } },
  { id: "results", label: { en: "Admission Results", bn: "ভর্তি ফলাফল" } },
  { id: "dates", label: { en: "Important Dates", bn: "গুরুত্বপূর্ণ তারিখ" } },
  { id: "faq", label: { en: "FAQ", bn: "সচরাচর জিজ্ঞাসা" } },
];

const LEVEL_LABEL: Record<string, string> = { undergraduate: "Undergraduate", postgraduate: "Postgraduate", general: "All applicants" };

function ItemList({ items, empty }: { items: AdmissionItem[]; empty: string }) {
  if (items.length === 0) return <EmptyState title={empty}>Entries are added from the admin dashboard as soon as they are released.</EmptyState>;
  return (
    <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
      {items.map((item) => (
        <li key={item.id} className="flex flex-col gap-3 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="gold">{LEVEL_LABEL[item.level] ?? item.level}</Badge>
              {item.isSample && <SampleBadge />}
              {item.dateText && <span className="text-xs text-muted">{item.dateText}</span>}
            </div>
            <p className="mt-2 font-semibold leading-snug text-ink">{item.title}</p>
            {item.body && <p className="mt-1 text-sm leading-relaxed text-muted">{item.body}</p>}
          </div>
          {item.fileId && <FileLink fileId={item.fileId} fileName={item.fileName} compact />}
        </li>
      ))}
    </ul>
  );
}

export default async function AdmissionPage() {
  const [items, content, notices] = await Promise.all([getAdmissionItems(), getContent(), getNotices(4, ["admission"])]);
  const of = (kind: string, level?: string) => items.filter((i) => i.kind === kind && (!level || i.level === level));
  const dates = of("date");
  const guidelines = of("guideline");
  const faqs = of("faq");

  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({ "@type": "Question", name: f.title, acceptedAnswer: { "@type": "Answer", text: f.body } })),
  };

  return (
    <>
      <PageHero
        title={{ en: "Admission", bn: "ভর্তি" }}
        eyebrow={<T en="Join BUTEX" bn="বুটেক্সে যোগ দিন" />}
        lead={content.admission_intro}
        crumbs={[{ label: { en: "Admission", bn: "ভর্তি" } }]}
        image={IMAGES.graduates}
      >
        <div className="flex flex-wrap gap-3">
          <ButtonLink href="#circulars" variant="gold">
            <ScrollText className="size-4" aria-hidden="true" />
            <T en="Admission circulars" bn="ভর্তি বিজ্ঞপ্তি" />
          </ButtonLink>
          <ButtonLink href="#dates" variant="light">
            <T en="Important dates" bn="গুরুত্বপূর্ণ তারিখ" />
          </ButtonLink>
        </div>
      </PageHero>

      <Container className="grid gap-10 py-14 lg:grid-cols-[15rem_1fr] lg:gap-16 lg:py-20">
        <SectionNav items={SECTIONS} />

        <div className="min-w-0 space-y-16">
          <PageSection id="undergraduate" title={{ en: "Undergraduate Admission", bn: "স্নাতক ভর্তি" }}>
            <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
              <div className="space-y-4 text-lg leading-relaxed text-muted">
                <p>
                  BUTEX admits students to its four-year Bachelor of Science programs through a competitive admission test held for each intake. Successful candidates are placed in one of the university&apos;s nine departments according to merit and preference.
                </p>
                <p>The admission circular for each intake sets out who may apply, how to apply, the test format and the schedule.</p>
              </div>
              <ul className="space-y-3 rounded-2xl border border-line bg-surface p-6 text-sm">
                {[
                  ["Degree", "B.Sc. (four years)"],
                  ["Departments", "Nine"],
                  ["Selection", "Admission test and merit list"],
                  ["Seats and fees", "As stated in the circular"],
                ].map(([k, v]) => (
                  <li key={k} className="flex justify-between gap-6 border-b border-line pb-3 last:border-0 last:pb-0">
                    <span className="text-muted">{k}</span>
                    <span className="text-right font-semibold text-ink">{v}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="mt-6 flex flex-wrap gap-3">
              <ButtonLink href="/departments" variant="outline">
                <GraduationCap className="size-4" aria-hidden="true" /> Explore the departments
              </ButtonLink>
            </div>
          </PageSection>

          <PageSection id="postgraduate" title={{ en: "Postgraduate Admission", bn: "স্নাতকোত্তর ভর্তি" }}>
            <p className="max-w-3xl text-lg leading-relaxed text-muted">
              Graduates in textile engineering and related fields can apply for postgraduate study at BUTEX. Admission is announced through a separate postgraduate circular, which lists the programs on offer, eligibility and the selection process.
            </p>
            <PlaceholderNote className="mt-6">The list of postgraduate programs, their duration and fees will be published here after confirmation by the university.</PlaceholderNote>
          </PageSection>

          <PageSection id="circulars" title={{ en: "Admission Circulars", bn: "ভর্তি বিজ্ঞপ্তি" }}>
            <ItemList items={of("circular")} empty="No circular is currently published." />
            {notices.length > 0 && (
              <div className="mt-8">
                <h3 className="flex items-center gap-2 text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-accent">
                  <BellRing className="size-4" aria-hidden="true" /> Latest admission notices
                </h3>
                <ul className="mt-3 divide-y divide-line border-y border-line">
                  {notices.map((n) => (
                    <li key={n.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
                      <Link href={`/notices/${n.id}`} className="font-medium text-ink hover:text-accent">
                        {n.title}
                      </Link>
                      <span className="flex items-center gap-2 text-xs text-muted">
                        {n.isSample && <SampleBadge />}
                        {fmtDate(n.publishedAt, "short")}
                      </span>
                    </li>
                  ))}
                </ul>
                <p className="mt-4">
                  <Link href="/notices?category=admission" className="group inline-flex items-center gap-2 text-sm font-semibold text-brand hover:text-accent">
                    All admission notices <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                  </Link>
                </p>
              </div>
            )}
          </PageSection>

          <PageSection id="eligibility" title={{ en: "Eligibility Requirements", bn: "যোগ্যতা" }}>
            <div className="grid gap-6 md:grid-cols-2">
              {(["undergraduate", "postgraduate"] as const).map((level) => {
                const reqs = of("requirement", level);
                return (
                  <article key={level} className="rounded-2xl border border-line bg-surface p-6 sm:p-7">
                    <h3 className="font-serif text-2xl text-brand">{LEVEL_LABEL[level]}</h3>
                    {reqs.length > 0 ? (
                      <ul className="mt-5 space-y-5">
                        {reqs.map((r) => (
                          <li key={r.id} className="flex gap-3">
                            <ClipboardCheck className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
                            <span>
                              <span className="block font-semibold text-ink">{r.title}</span>
                              <span className="mt-1 block text-sm leading-relaxed text-muted">{r.body}</span>
                            </span>
                          </li>
                        ))}
                      </ul>
                    ) : (
                      <PlaceholderNote className="mt-5">Requirements will be published with the circular.</PlaceholderNote>
                    )}
                  </article>
                );
              })}
            </div>
            <PlaceholderNote className="mt-6">
              Minimum grades and subject requirements change between intakes and are deliberately not quoted here. Always rely on the circular for the intake you are applying to.
            </PlaceholderNote>
          </PageSection>

          <PageSection id="guidelines" title={{ en: "Application Guidelines", bn: "আবেদন নির্দেশিকা" }}>
            {guidelines.length > 0 ? (
              <ol className="grid gap-4 sm:grid-cols-2">
                {guidelines.map((g, i) => (
                  <li key={g.id} className="flex gap-5 rounded-2xl border border-line bg-surface p-6">
                    <span className="font-serif text-4xl leading-none text-gold-500">{String(i + 1).padStart(2, "0")}</span>
                    <span>
                      <span className="block font-semibold text-ink">{g.title}</span>
                      <span className="mt-1 block text-sm leading-relaxed text-muted">{g.body}</span>
                    </span>
                  </li>
                ))}
              </ol>
            ) : (
              <PlaceholderNote>Application steps will be published with the circular.</PlaceholderNote>
            )}
          </PageSection>

          <PageSection id="results" title={{ en: "Admission Results", bn: "ভর্তি ফলাফল" }}>
            <ItemList items={of("result")} empty="No admission results are published at present." />
          </PageSection>

          <PageSection id="dates" title={{ en: "Important Dates", bn: "গুরুত্বপূর্ণ তারিখ" }}>
            {dates.length > 0 ? (
              <div className="overflow-x-auto rounded-2xl border border-line bg-surface">
                <table className="w-full min-w-[32rem] text-left text-sm">
                  <caption className="sr-only">Important admission dates</caption>
                  <thead className="border-b border-line bg-surface-2 text-[0.7rem] uppercase tracking-[0.14em] text-muted">
                    <tr>
                      <th scope="col" className="px-6 py-3 font-semibold">Milestone</th>
                      <th scope="col" className="px-6 py-3 font-semibold">Level</th>
                      <th scope="col" className="px-6 py-3 font-semibold">Date</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {dates.map((d) => (
                      <tr key={d.id}>
                        <th scope="row" className="px-6 py-4 font-medium text-ink">{d.title}</th>
                        <td className="px-6 py-4 text-muted">{LEVEL_LABEL[d.level] ?? d.level}</td>
                        <td className="px-6 py-4">
                          {d.dateText && !/announced/i.test(d.dateText) ? <span className="font-semibold text-ink">{d.dateText}</span> : <Badge>{d.dateText || "To be announced"}</Badge>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <EmptyState title="No dates have been announced yet.">Dates will be listed here when the circular is published.</EmptyState>
            )}
          </PageSection>

          <PageSection id="faq" title={{ en: "Frequently Asked Questions", bn: "সচরাচর জিজ্ঞাসা" }}>
            {faqs.length > 0 ? (
              <div className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
                {faqs.map((f) => (
                  <details key={f.id} className="group">
                    <summary className="flex list-none items-center justify-between gap-6 px-6 py-5 font-semibold text-ink transition hover:text-accent">
                      {f.title}
                      <ChevronDown className="size-5 shrink-0 text-accent transition-transform duration-200 group-open:rotate-180" aria-hidden="true" />
                    </summary>
                    <p className="px-6 pb-6 leading-relaxed text-muted">{f.body}</p>
                  </details>
                ))}
              </div>
            ) : (
              <EmptyState title="No questions have been added yet." />
            )}
            <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd).replace(/</g, "\\u003c") }} />
            <p className="mt-6 text-muted">
              Still have a question?{" "}
              <Link href="/contact" className="font-semibold text-accent underline-offset-4 hover:underline">
                Contact the university
              </Link>
              .
            </p>
          </PageSection>
        </div>
      </Container>
    </>
  );
}
