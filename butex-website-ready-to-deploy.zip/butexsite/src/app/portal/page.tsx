import type { Metadata } from "next";
import { PortalApp } from "@/components/portal/portal-app";
import { ACCOUNTS } from "@/lib/auth";

export const metadata: Metadata = {
  title: "Student Portal",
  description: "Sign in to the BUTEX student portal for your class routine, examination schedule, results and course materials.",
  robots: { index: false, follow: false },
};

export default function PortalPage() {
  return <PortalApp demo={{ identifier: ACCOUNTS.student.display, password: ACCOUNTS.student.password }} />;
}
