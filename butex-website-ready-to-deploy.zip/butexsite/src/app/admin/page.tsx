import type { Metadata } from "next";
import { AdminApp } from "@/components/admin/admin-app";
import { ACCOUNTS, DEMO_MODE } from "@/lib/auth";

// Whether demo credentials are shown depends on runtime environment variables.
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Admin Dashboard",
  description: "Content administration for the BUTEX website.",
  robots: { index: false, follow: false },
};

export default function AdminPage() {
  return <AdminApp demo={DEMO_MODE ? { identifier: ACCOUNTS.admin.identifier, password: ACCOUNTS.admin.password } : null} />;
}
