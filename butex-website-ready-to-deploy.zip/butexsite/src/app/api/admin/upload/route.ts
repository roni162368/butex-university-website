import { sql } from "drizzle-orm";
import { db } from "@/db";
import { files } from "@/db/schema";
import { requireRole } from "@/lib/auth";

export const dynamic = "force-dynamic";

const MAX_BYTES = 8 * 1024 * 1024;

/** Accepts a single PDF (multipart field "file") and stores it in the database. */
export async function POST(req: Request) {
  const auth = await requireRole(req, "admin");
  if (auth instanceof Response) return auth;

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return Response.json({ error: "The upload could not be read. Please try again." }, { status: 400 });
  }
  const file = form.get("file");
  if (!(file instanceof File) || file.size === 0) return Response.json({ error: "Choose a PDF file to upload." }, { status: 400 });
  if (file.size > MAX_BYTES) return Response.json({ error: "The file is larger than 8 MB. Compress the PDF and try again." }, { status: 413 });

  const data = Buffer.from(await file.arrayBuffer());
  if (data.subarray(0, 5).toString("latin1") !== "%PDF-") {
    return Response.json({ error: "Only PDF files can be uploaded. Export the document as a PDF and try again." }, { status: 415 });
  }

  const base = file.name.replace(/\.pdf$/i, "").replace(/[^\w\- ]+/g, "_").trim().slice(0, 120) || "document";
  try {
    // Housekeeping: drop uploads that were abandoned (never attached to a record) more than a day ago.
    await db.execute(sql`
      delete from files f
      where f.created_at < now() - interval '1 day'
        and not exists (select 1 from notices n where n.file_id = f.id)
        and not exists (select 1 from admission_items a where a.file_id = f.id)
        and not exists (select 1 from documents d where d.file_id = f.id)
    `);
    const [row] = await db
      .insert(files)
      .values({ name: `${base}.pdf`, mime: "application/pdf", size: data.length, data })
      .returning({ id: files.id, name: files.name, size: files.size });
    return Response.json({ file: row }, { status: 201 });
  } catch (err) {
    console.error("[admin:upload]", err instanceof Error ? err.message : err);
    return Response.json({ error: "The file could not be stored. Please try again." }, { status: 503 });
  }
}
