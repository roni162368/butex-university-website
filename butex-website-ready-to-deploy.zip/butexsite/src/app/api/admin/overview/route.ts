import { desc, sql } from "drizzle-orm";
import type { PgTable } from "drizzle-orm/pg-core";
import { db } from "@/db";
import { admissionItems, departments, documents, events, faculty, messages, news, notices } from "@/db/schema";
import { DEMO_MODE, requireRole } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

const count = async (table: PgTable) => (await db.select({ n: sql<number>`count(*)::int` }).from(table))[0].n;

export async function GET(req: Request) {
  const auth = await requireRole(req, "admin");
  if (auth instanceof Response) return auth;

  try {
    await ensureSeeded();
    const [n, nw, ev, dp, fc, ad, dc, ms, recent] = await Promise.all([
      count(notices),
      count(news),
      count(events),
      count(departments),
      count(faculty),
      count(admissionItems),
      count(documents),
      count(messages),
      db.select().from(messages).orderBy(desc(messages.createdAt)).limit(5),
    ]);
    return Response.json({
      counts: { notices: n, news: nw, events: ev, departments: dp, faculty: fc, admission: ad, documents: dc, messages: ms },
      recentMessages: recent,
      demoMode: DEMO_MODE,
    });
  } catch (err) {
    console.error("[admin:overview]", err instanceof Error ? err.message : err);
    return Response.json({ error: "The overview could not be loaded. Please try again." }, { status: 503 });
  }
}
