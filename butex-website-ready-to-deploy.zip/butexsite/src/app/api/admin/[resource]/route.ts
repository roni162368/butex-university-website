import { eq } from "drizzle-orm";
import { db } from "@/db";
import { news } from "@/db/schema";
import { RESOURCES, validate } from "@/lib/admin-resources";
import { requireRole } from "@/lib/auth";
import { slugify } from "@/lib/format";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ resource: string }> };

export async function GET(req: Request, { params }: Ctx) {
  const auth = await requireRole(req, "admin");
  if (auth instanceof Response) return auth;
  const resource = RESOURCES[(await params).resource];
  if (!resource) return Response.json({ error: "Unknown resource." }, { status: 404 });

  try {
    await ensureSeeded();
    const rows = await db.select().from(resource.table).orderBy(...resource.order).limit(1000);
    return Response.json({ rows });
  } catch (err) {
    console.error("[admin:list]", err instanceof Error ? err.message : err);
    return Response.json({ error: "The records could not be loaded. Please try again." }, { status: 503 });
  }
}

export async function POST(req: Request, { params }: Ctx) {
  const auth = await requireRole(req, "admin");
  if (auth instanceof Response) return auth;
  const key = (await params).resource;
  const resource = RESOURCES[key];
  if (!resource) return Response.json({ error: "Unknown resource." }, { status: 404 });
  if (!resource.create) return Response.json({ error: "New records cannot be created here." }, { status: 405 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "The request could not be read." }, { status: 400 });
  }
  const { values, errors } = validate(resource, body, "create");
  if (Object.keys(errors).length > 0) return Response.json({ error: "Please correct the highlighted fields.", fields: errors }, { status: 400 });

  try {
    if (key === "news") {
      const base = slugify(String(values.title));
      const clash = await db.select({ id: news.id }).from(news).where(eq(news.slug, base)).limit(1);
      values.slug = clash.length ? `${base}-${Date.now().toString(36)}` : base;
    }
    const [row] = await db
      .insert(resource.table)
      .values(values as never)
      .returning();
    return Response.json({ row }, { status: 201 });
  } catch (err) {
    console.error("[admin:create]", err instanceof Error ? err.message : err);
    return Response.json({ error: "The record could not be saved. Please try again." }, { status: 503 });
  }
}
