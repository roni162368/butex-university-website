import { eq } from "drizzle-orm";
import { db } from "@/db";
import { files } from "@/db/schema";
import { RESOURCES, validate, type Resource } from "@/lib/admin-resources";
import { requireRole } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ resource: string; id: string }> };

function parseId(resource: Resource, raw: string): string | number | null {
  if (resource.idType === "string") return /^[a-z0-9_]{1,64}$/.test(raw) ? raw : null;
  const n = Number(raw);
  return Number.isInteger(n) && n > 0 && n <= 2147483647 ? n : null;
}

const fileIdOf = (row: unknown): number | null => {
  const value = (row as { fileId?: unknown } | undefined)?.fileId;
  return typeof value === "number" ? value : null;
};

export async function PATCH(req: Request, { params }: Ctx) {
  const auth = await requireRole(req, "admin");
  if (auth instanceof Response) return auth;
  const p = await params;
  const resource = RESOURCES[p.resource];
  if (!resource) return Response.json({ error: "Unknown resource." }, { status: 404 });
  const id = parseId(resource, p.id);
  if (id === null) return Response.json({ error: "Record not found." }, { status: 404 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "The request could not be read." }, { status: 400 });
  }
  const { values, errors } = validate(resource, body, "update");
  if (Object.keys(errors).length > 0) return Response.json({ error: "Please correct the highlighted fields.", fields: errors }, { status: 400 });
  if (Object.keys(values).length === 0) return Response.json({ error: "There is nothing to update." }, { status: 400 });
  if (resource.touch) values.updatedAt = new Date();

  try {
    const [before] = await db.select().from(resource.table).where(eq(resource.id, id)).limit(1);
    if (!before) return Response.json({ error: "This record no longer exists. It may have been deleted." }, { status: 404 });

    const [row] = await db
      .update(resource.table)
      .set(values as never)
      .where(eq(resource.id, id))
      .returning();

    // Remove a replaced attachment so orphaned PDFs do not accumulate.
    const oldFile = fileIdOf(before);
    if (oldFile !== null && "fileId" in values && values.fileId !== oldFile) {
      await db.delete(files).where(eq(files.id, oldFile));
    }
    return Response.json({ row });
  } catch (err) {
    console.error("[admin:update]", err instanceof Error ? err.message : err);
    return Response.json({ error: "The changes could not be saved. Please try again." }, { status: 503 });
  }
}

export async function DELETE(req: Request, { params }: Ctx) {
  const auth = await requireRole(req, "admin");
  if (auth instanceof Response) return auth;
  const p = await params;
  const resource = RESOURCES[p.resource];
  if (!resource) return Response.json({ error: "Unknown resource." }, { status: 404 });
  if (!resource.remove) return Response.json({ error: "These records cannot be deleted." }, { status: 405 });
  const id = parseId(resource, p.id);
  if (id === null) return Response.json({ error: "Record not found." }, { status: 404 });

  try {
    const [row] = await db.delete(resource.table).where(eq(resource.id, id)).returning();
    if (!row) return Response.json({ error: "This record no longer exists." }, { status: 404 });
    const fileId = fileIdOf(row);
    if (fileId !== null) await db.delete(files).where(eq(files.id, fileId));
    return Response.json({ ok: true });
  } catch (err) {
    console.error("[admin:delete]", err instanceof Error ? err.message : err);
    return Response.json({ error: "The record could not be deleted. Please try again." }, { status: 503 });
  }
}
