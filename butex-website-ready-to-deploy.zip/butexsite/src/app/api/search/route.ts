import { searchSite } from "@/lib/data";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const q = (new URL(req.url).searchParams.get("q") ?? "").trim().slice(0, 80);
  if (q.length < 2) return Response.json({ results: [] });
  try {
    return Response.json({ results: await searchSite(q, 5) });
  } catch {
    return Response.json({ error: "Search is temporarily unavailable." }, { status: 503 });
  }
}
