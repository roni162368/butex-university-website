import { eq } from "drizzle-orm";
import { db } from "@/db";
import { files } from "@/db/schema";

export const dynamic = "force-dynamic";

/** Serves an uploaded PDF. Append ?download=1 to force a download instead of inline viewing. */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const id = Number((await params).id);
  if (!Number.isInteger(id) || id < 1 || id > 2147483647) return new Response("File not found.", { status: 404 });

  try {
    const [file] = await db.select().from(files).where(eq(files.id, id)).limit(1);
    if (!file) return new Response("File not found.", { status: 404 });

    const download = new URL(req.url).searchParams.get("download") === "1";
    const safeName = file.name.replace(/[^\w.\- ]+/g, "_") || "document.pdf";
    return new Response(new Uint8Array(file.data), {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Length": String(file.data.length),
        "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${safeName}"`,
        "Cache-Control": "public, max-age=3600",
        "X-Content-Type-Options": "nosniff",
      },
    });
  } catch (err) {
    console.error("[files]", err instanceof Error ? err.message : err);
    return new Response("The file is temporarily unavailable.", { status: 503 });
  }
}
