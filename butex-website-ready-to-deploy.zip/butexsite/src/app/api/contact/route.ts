import { db } from "@/db";
import { messages } from "@/db/schema";
import { clientKey, rateLimit } from "@/lib/auth";

export const dynamic = "force-dynamic";

const text = (v: unknown, max: number) => (typeof v === "string" ? v.replace(/\r\n/g, "\n").trim().slice(0, max) : "");

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "The request could not be read. Please try again." }, { status: 400 });
  }

  // Honeypot field: real visitors never fill it in.
  if (text(body?.website, 200)) return Response.json({ ok: true });

  const name = text(body?.name, 150);
  const email = text(body?.email, 200);
  const subject = text(body?.subject, 200);
  const message = text(body?.message, 4000);

  const fields: Record<string, string> = {};
  if (name.length < 2) fields.name = "Enter your full name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) fields.email = "Enter a valid email address, for example name@example.com.";
  if (message.length < 10) fields.message = "Write a message of at least 10 characters.";
  if (Object.keys(fields).length > 0) return Response.json({ error: "Please correct the highlighted fields.", fields }, { status: 400 });

  if (!rateLimit(`contact:${clientKey(req)}`, 5, 10 * 60_000)) {
    return Response.json({ error: "You have sent several messages in a short time. Please wait a few minutes before sending another." }, { status: 429 });
  }

  try {
    await db.insert(messages).values({ name, email, subject, message });
    return Response.json({ ok: true }, { status: 201 });
  } catch (err) {
    console.error("[contact]", err instanceof Error ? err.message : err);
    return Response.json({ error: "Your message could not be saved. Please try again shortly." }, { status: 503 });
  }
}
