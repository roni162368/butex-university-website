import { publicUser, requireRole } from "@/lib/auth";
import { getDocuments, getNotices, getUpcomingEvents } from "@/lib/data";
import { PORTAL_DEMO } from "@/lib/portal-demo";
import { relativeDate } from "@/lib/seed-data";
import { DEPARTMENT_INDEX } from "@/lib/site";

export const dynamic = "force-dynamic";

/** Everything the student portal needs in one authenticated request. */
export async function GET(req: Request) {
  const auth = await requireRole(req, "student");
  if (auth instanceof Response) return auth;

  const [notices, events, documents] = await Promise.all([getNotices(8, ["academic", "examination"]), getUpcomingEvents(10), getDocuments()]);
  const department = DEPARTMENT_INDEX.find((d) => d.slug === auth.departmentSlug) ?? null;

  return Response.json({
    student: { ...publicUser(auth), department },
    demo: PORTAL_DEMO,
    exams: PORTAL_DEMO.exams.map((e) => ({ ...e, date: relativeDate(e.inDays).toISOString() })),
    notices: notices.map((n) => ({ id: n.id, title: n.title, category: n.category, publishedAt: n.publishedAt.toISOString(), fileId: n.fileId, isSample: n.isSample })),
    calendar: events.map((e) => ({ id: e.id, title: e.title, category: e.category, startsAt: e.startsAt.toISOString(), endsAt: e.endsAt?.toISOString() ?? null, location: e.location, isSample: e.isSample })),
    documents: documents.map((d) => ({ id: d.id, title: d.title, category: d.category, fileId: d.fileId, isSample: d.isSample })),
  });
}
