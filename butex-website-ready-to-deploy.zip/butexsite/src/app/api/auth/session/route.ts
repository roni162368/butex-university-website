import { destroySession, getSessionUser, publicUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Returns the signed-in user for the supplied bearer token. */
export async function GET(req: Request) {
  try {
    const user = await getSessionUser(req);
    if (!user) return Response.json({ error: "Not signed in." }, { status: 401 });
    return Response.json({ user: publicUser(user) });
  } catch {
    return Response.json({ error: "The service is temporarily unavailable." }, { status: 503 });
  }
}

/** Signs out by revoking the session. */
export async function DELETE(req: Request) {
  try {
    await destroySession(req);
  } catch {
    /* the token is discarded client-side regardless */
  }
  return Response.json({ ok: true });
}
