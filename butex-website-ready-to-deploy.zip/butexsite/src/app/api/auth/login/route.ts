import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { clientKey, createSession, hashPassword, publicUser, rateLimit, verifyPassword } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";

export const dynamic = "force-dynamic";

// Verified against when the account does not exist, so response time does not reveal which IDs are registered.
const DUMMY_HASH = hashPassword("not-a-real-password");

export async function POST(req: Request) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "The request could not be read. Please try again." }, { status: 400 });
  }
  const { identifier, password, role } = (body ?? {}) as Record<string, unknown>;
  if (role !== "admin" && role !== "student") return Response.json({ error: "Unknown sign-in type." }, { status: 400 });

  const fields: Record<string, string> = {};
  if (typeof identifier !== "string" || !identifier.trim()) fields.identifier = role === "admin" ? "Enter your email address." : "Enter your student ID.";
  if (typeof password !== "string" || !password) fields.password = "Enter your password.";
  if (Object.keys(fields).length > 0) return Response.json({ error: "Please complete both fields.", fields }, { status: 400 });

  const id = (identifier as string).trim().toLowerCase().slice(0, 200);
  if (!rateLimit(`login:${clientKey(req)}:${id}`)) {
    return Response.json({ error: "Too many sign-in attempts. Please wait a few minutes and try again." }, { status: 429 });
  }

  try {
    await ensureSeeded();
    const [user] = await db.select().from(users).where(and(eq(users.identifier, id), eq(users.role, role))).limit(1);
    const ok = verifyPassword((password as string).slice(0, 200), user?.passwordHash ?? DUMMY_HASH);
    if (!user || !ok) {
      return Response.json({ error: role === "admin" ? "The email or password is incorrect." : "The student ID or password is incorrect." }, { status: 401 });
    }
    const token = await createSession(user.id);
    return Response.json({ token, user: publicUser(user) });
  } catch (err) {
    console.error("[auth/login]", err instanceof Error ? err.message : err);
    return Response.json({ error: "Sign-in is temporarily unavailable. Please try again shortly." }, { status: 503 });
  }
}
