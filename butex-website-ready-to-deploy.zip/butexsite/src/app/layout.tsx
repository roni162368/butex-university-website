import type { Metadata, Viewport } from "next";
import { Fraunces, Hanken_Grotesk, Hind_Siliguri, Noto_Serif_Bengali } from "next/font/google";
import type { ReactNode } from "react";
import { SITE } from "@/lib/site";
import "./globals.css";

const serif = Fraunces({ subsets: ["latin"], style: ["normal", "italic"], axes: ["opsz"], variable: "--font-serif-latin", display: "swap" });
const sans = Hanken_Grotesk({ subsets: ["latin"], variable: "--font-sans-latin", display: "swap" });
const bnSans = Hind_Siliguri({ subsets: ["bengali"], weight: ["400", "500", "600", "700"], variable: "--font-sans-bn", display: "swap", preload: false });
const bnSerif = Noto_Serif_Bengali({ subsets: ["bengali"], variable: "--font-serif-bn", display: "swap", preload: false });

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: `${SITE.name} (BUTEX) — ${SITE.tagline}`,
    template: `%s | ${SITE.name} (BUTEX)`,
  },
  description: SITE.description,
  applicationName: "BUTEX",
  keywords: ["BUTEX", "Bangladesh University of Textiles", "textile engineering", "Dhaka", "Tejgaon", "textile university Bangladesh", "বুটেক্স", "বাংলাদেশ টেক্সটাইল বিশ্ববিদ্যালয়"],
  openGraph: {
    type: "website",
    siteName: SITE.name,
    title: `${SITE.name} (BUTEX)`,
    description: SITE.description,
    locale: "en_BD",
    alternateLocale: ["bn_BD"],
    images: [{ url: "/images/og.jpg", width: 1200, height: 630, alt: "The BUTEX campus in Tejgaon, Dhaka" }],
  },
  twitter: { card: "summary_large_image", title: `${SITE.name} (BUTEX)`, description: SITE.description, images: ["/images/og.jpg"] },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#0a1b36" },
    { media: "(prefers-color-scheme: dark)", color: "#050e1d" },
  ],
};

/** Applies saved theme, language and text-size preferences before first paint. */
const PREFS_SCRIPT = `(function(){try{var d=document.documentElement,g=function(k){try{return localStorage.getItem(k)}catch(e){return null}};var t=g('butex-theme');if(t==='dark'||(!t&&window.matchMedia('(prefers-color-scheme: dark)').matches)){d.classList.add('dark')}if(g('butex-lang')==='bn'){d.dataset.lang='bn';d.lang='bn'}if(g('butex-fs')==='lg'){d.dataset.fs='lg'}}catch(e){}})();`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" data-lang="en" suppressHydrationWarning className={`${serif.variable} ${sans.variable} ${bnSans.variable} ${bnSerif.variable}`}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: PREFS_SCRIPT }} />
        <noscript>
          <style>{`.reveal{opacity:1!important;transform:none!important}`}</style>
        </noscript>
      </head>
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
