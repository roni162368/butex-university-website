import { cache } from "react";
import { and, asc, desc, eq, gte, ilike, inArray, or, type SQL } from "drizzle-orm";
import type { AnyPgColumn } from "drizzle-orm/pg-core";
import { db } from "@/db";
import {
  admissionItems,
  departments,
  documents,
  events,
  faculty,
  news,
  notices,
  siteContent,
  stats,
  type AdmissionItem,
  type Department,
  type DocumentItem,
  type EventItem,
  type FacultyMember,
  type NewsItem,
  type Notice,
  type Stat,
} from "@/db/schema";
import { ensureSeeded } from "./seed";
import { CONTENT_SEED, DEPARTMENT_SEED, STATS_SEED } from "./seed-data";
import { STATIC_SEARCH_INDEX, noticeCategory } from "./site";
import { fmtDate } from "./format";

/** Runs a query; if the database is unavailable the page still renders with the fallback. */
async function safe<T>(label: string, query: () => Promise<T>, fallback: T): Promise<T> {
  try {
    await ensureSeeded();
    return await query();
  } catch (err) {
    console.error(`[data:${label}]`, err instanceof Error ? err.message : err);
    return fallback;
  }
}

const CONTENT_DEFAULTS: Record<string, string> = Object.fromEntries(CONTENT_SEED.map((c) => [c.key, c.value]));
const DEPARTMENT_FALLBACK: Department[] = DEPARTMENT_SEED.map((d, i) => ({ id: i + 1, updatedAt: new Date(0), ...d }));
const STATS_FALLBACK: Stat[] = STATS_SEED.map((s, i) => ({ id: i + 1, ...s }));

export const getContent = cache(async (): Promise<Record<string, string>> =>
  safe(
    "content",
    async () => {
      const rows = await db.select({ key: siteContent.key, value: siteContent.value }).from(siteContent);
      return { ...CONTENT_DEFAULTS, ...Object.fromEntries(rows.map((r) => [r.key, r.value])) };
    },
    CONTENT_DEFAULTS,
  ),
);

export const getStats = cache(async (): Promise<Stat[]> =>
  safe("stats", () => db.select().from(stats).orderBy(asc(stats.sortOrder), asc(stats.id)), STATS_FALLBACK),
);

export const getDepartments = cache(async (): Promise<Department[]> =>
  safe("departments", () => db.select().from(departments).orderBy(asc(departments.sortOrder), asc(departments.id)), DEPARTMENT_FALLBACK),
);

export const getDepartment = cache(async (slug: string): Promise<Department | null> =>
  safe(
    "department",
    async () => (await db.select().from(departments).where(eq(departments.slug, slug)).limit(1))[0] ?? null,
    DEPARTMENT_FALLBACK.find((d) => d.slug === slug) ?? null,
  ),
);

export const getFaculty = cache(async (departmentSlug?: string): Promise<FacultyMember[]> =>
  safe(
    "faculty",
    () =>
      db
        .select()
        .from(faculty)
        .where(departmentSlug ? eq(faculty.departmentSlug, departmentSlug) : undefined)
        .orderBy(asc(faculty.departmentSlug), asc(faculty.sortOrder), asc(faculty.name))
        .limit(1000),
    [],
  ),
);

export const getNotices = cache(async (limit = 300, categories?: string[]): Promise<Notice[]> =>
  safe(
    "notices",
    () =>
      db
        .select()
        .from(notices)
        .where(categories?.length ? inArray(notices.category, categories) : undefined)
        .orderBy(desc(notices.pinned), desc(notices.publishedAt), desc(notices.id))
        .limit(limit),
    [],
  ),
);

export const getNotice = cache(async (id: number): Promise<Notice | null> =>
  safe("notice", async () => (await db.select().from(notices).where(eq(notices.id, id)).limit(1))[0] ?? null, null),
);

export const getNews = cache(async (limit = 60): Promise<NewsItem[]> =>
  safe("news", () => db.select().from(news).orderBy(desc(news.publishedAt), desc(news.id)).limit(limit), []),
);

export const getNewsItem = cache(async (slug: string): Promise<NewsItem | null> =>
  safe("news-item", async () => (await db.select().from(news).where(eq(news.slug, slug)).limit(1))[0] ?? null, null),
);

export const getEvents = cache(async (): Promise<EventItem[]> =>
  safe("events", () => db.select().from(events).orderBy(asc(events.startsAt), asc(events.id)).limit(500), []),
);

export const getUpcomingEvents = cache(async (limit = 5): Promise<EventItem[]> =>
  safe(
    "upcoming-events",
    () =>
      db
        .select()
        .from(events)
        .where(gte(events.startsAt, new Date(Date.now() - 12 * 3600_000)))
        .orderBy(asc(events.startsAt), asc(events.id))
        .limit(limit),
    [],
  ),
);

export const getAdmissionItems = cache(async (): Promise<AdmissionItem[]> =>
  safe("admission", () => db.select().from(admissionItems).orderBy(asc(admissionItems.sortOrder), asc(admissionItems.id)).limit(500), []),
);

export const getDocuments = cache(async (): Promise<DocumentItem[]> =>
  safe("documents", () => db.select().from(documents).orderBy(asc(documents.sortOrder), asc(documents.id)).limit(500), []),
);

export type SearchResult = { type: string; title: string; href: string; snippet: string };

/** Global search across static pages and database content. */
export async function searchSite(query: string, perGroup = 6): Promise<SearchResult[]> {
  const words = query
    .trim()
    .slice(0, 80)
    .toLowerCase()
    .split(/\s+/)
    .filter((w) => w.length > 0)
    .slice(0, 5);
  if (words.join("").length < 2) return [];

  const like = (w: string) => `%${w.replace(/[\\%_]/g, "\\$&")}%`;
  const match = (...cols: AnyPgColumn[]): SQL | undefined =>
    and(...words.map((w) => or(...cols.map((col) => ilike(col, like(w))))));

  const pages: SearchResult[] = STATIC_SEARCH_INDEX.filter((p) => {
    const hay = `${p.title} ${p.description} ${p.keywords}`.toLowerCase();
    return words.every((w) => hay.includes(w));
  })
    .slice(0, perGroup)
    .map((p) => ({ type: "Page", title: p.title, href: p.href, snippet: p.description }));

  const [deptRows, noticeRows, newsRows, eventRows, facultyRows, docRows] = await Promise.all([
    safe("search-dept", () => db.select().from(departments).where(match(departments.name, departments.code, departments.overview, departments.curriculum, departments.research)).limit(perGroup), []),
    safe("search-notice", () => db.select().from(notices).where(match(notices.title, notices.summary, notices.body)).orderBy(desc(notices.publishedAt)).limit(perGroup), []),
    safe("search-news", () => db.select().from(news).where(match(news.title, news.excerpt, news.body)).orderBy(desc(news.publishedAt)).limit(perGroup), []),
    safe("search-event", () => db.select().from(events).where(match(events.title, events.description, events.location)).orderBy(desc(events.startsAt)).limit(perGroup), []),
    safe("search-faculty", () => db.select().from(faculty).where(match(faculty.name, faculty.designation, faculty.researchInterests)).limit(perGroup), []),
    safe("search-doc", () => db.select().from(documents).where(match(documents.title, documents.description, documents.category)).limit(perGroup), []),
  ]);

  return [
    ...pages,
    ...deptRows.map((d) => ({ type: "Department", title: `${d.name} (${d.code})`, href: `/departments/${d.slug}`, snippet: d.tagline })),
    ...noticeRows.map((n) => ({ type: "Notice", title: n.title, href: `/notices/${n.id}`, snippet: `${noticeCategory(n.category).en} · ${fmtDate(n.publishedAt, "short")}` })),
    ...newsRows.map((n) => ({ type: "News", title: n.title, href: `/news/${n.slug}`, snippet: n.excerpt })),
    ...eventRows.map((e) => ({ type: "Event", title: e.title, href: "/events", snippet: fmtDate(e.startsAt) })),
    ...facultyRows.map((f) => ({ type: "Faculty", title: f.name, href: `/faculty?q=${encodeURIComponent(f.name)}`, snippet: f.designation })),
    ...docRows.map((d) => ({ type: "Document", title: d.title, href: d.fileId ? `/api/files/${d.fileId}` : "/academics#documents", snippet: d.category })),
  ];
}
