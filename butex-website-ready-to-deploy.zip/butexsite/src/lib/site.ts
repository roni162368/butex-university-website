/**
 * Site-wide constants. Contact details below were taken from the university's
 * public contact page and can be overridden from Admin → Site Content.
 */
export const SITE = {
  name: "Bangladesh University of Textiles",
  nameBn: "বাংলাদেশ টেক্সটাইল বিশ্ববিদ্যালয়",
  short: "BUTEX",
  shortBn: "বুটেক্স",
  tagline: "Engineering the Future of Textiles.",
  description:
    "Bangladesh University of Textiles (BUTEX) is a public university in Tejgaon, Dhaka dedicated to textile engineering education, research and innovation.",
  address: "92 Shaheed Tajuddin Ahmed Avenue, Tejgaon Industrial Area, Dhaka-1208, Bangladesh",
  phone: "01500121121",
  fax: "+880248112698",
  email: "info@butex.edu.bd",
  officialUrl: "https://www.butex.edu.bd",
  mapsEmbed:
    "https://www.google.com/maps?q=Bangladesh%20University%20of%20Textiles%2C%20Tejgaon%2C%20Dhaka&z=16&output=embed",
  mapsLink: "https://www.google.com/maps/search/?api=1&query=Bangladesh+University+of+Textiles+Tejgaon+Dhaka",
} as const;

export type L = { en: string; bn?: string };

export type DeptRef = { slug: string; code: string; name: string; nameBn: string };

/** The nine departments, in the order used throughout the site. */
export const DEPARTMENT_INDEX: DeptRef[] = [
  { slug: "yarn-engineering", code: "YE", name: "Yarn Engineering", nameBn: "ইয়ার্ন ইঞ্জিনিয়ারিং" },
  { slug: "fabric-engineering", code: "FE", name: "Fabric Engineering", nameBn: "ফ্যাব্রিক ইঞ্জিনিয়ারিং" },
  { slug: "wet-processing-engineering", code: "WPE", name: "Wet Processing Engineering", nameBn: "ওয়েট প্রসেসিং ইঞ্জিনিয়ারিং" },
  { slug: "apparel-engineering", code: "AE", name: "Apparel Engineering", nameBn: "অ্যাপারেল ইঞ্জিনিয়ারিং" },
  { slug: "textile-engineering-management", code: "TEM", name: "Textile Engineering Management", nameBn: "টেক্সটাইল ইঞ্জিনিয়ারিং ম্যানেজমেন্ট" },
  { slug: "textile-fashion-and-design", code: "TFD", name: "Textile Fashion and Design", nameBn: "টেক্সটাইল ফ্যাশন অ্যান্ড ডিজাইন" },
  { slug: "dyes-and-chemical-engineering", code: "DCE", name: "Dyes and Chemical Engineering", nameBn: "ডাইস অ্যান্ড কেমিক্যাল ইঞ্জিনিয়ারিং" },
  { slug: "environmental-science-and-engineering", code: "ESE", name: "Environmental Science and Engineering", nameBn: "এনভায়রনমেন্টাল সায়েন্স অ্যান্ড ইঞ্জিনিয়ারিং" },
  { slug: "textile-machinery-design-and-maintenance", code: "TMDM", name: "Textile Machinery Design and Maintenance", nameBn: "টেক্সটাইল মেশিনারি ডিজাইন অ্যান্ড মেইনটেন্যান্স" },
];

export const NOTICE_CATEGORIES = [
  { key: "academic", en: "Academic", bn: "একাডেমিক" },
  { key: "examination", en: "Examination", bn: "পরীক্ষা" },
  { key: "admission", en: "Admission", bn: "ভর্তি" },
  { key: "administrative", en: "Administrative", bn: "প্রশাসনিক" },
  { key: "events", en: "Events & Announcements", bn: "অনুষ্ঠান ও ঘোষণা" },
] as const;

export type NoticeCategoryKey = (typeof NOTICE_CATEGORIES)[number]["key"];

export function noticeCategory(key: string) {
  return NOTICE_CATEGORIES.find((c) => c.key === key) ?? { key, en: key, bn: key };
}

export type NavChild = { label: L; href: string };
export type NavItem = { label: L; href: string; children?: NavChild[]; wide?: boolean };

export const NAV: NavItem[] = [
  { label: { en: "Home", bn: "হোম" }, href: "/" },
  {
    label: { en: "About BUTEX", bn: "বুটেক্স সম্পর্কে" },
    href: "/about",
    children: [
      { label: { en: "History", bn: "ইতিহাস" }, href: "/about#history" },
      { label: { en: "Mission & Vision", bn: "মিশন ও ভিশন" }, href: "/about#mission" },
      { label: { en: "Leadership", bn: "নেতৃত্ব" }, href: "/about#leadership" },
      { label: { en: "Vice Chancellor's Message", bn: "উপাচার্যের বাণী" }, href: "/about#vc-message" },
      { label: { en: "Achievements", bn: "অর্জন" }, href: "/about#achievements" },
      { label: { en: "Accreditation & Recognition", bn: "স্বীকৃতি" }, href: "/about#accreditation" },
    ],
  },
  {
    label: { en: "Academics", bn: "একাডেমিক্স" },
    href: "/academics",
    children: [
      { label: { en: "Academic Programs", bn: "একাডেমিক প্রোগ্রাম" }, href: "/academics#programs" },
      { label: { en: "Academic Calendar", bn: "একাডেমিক ক্যালেন্ডার" }, href: "/academics#calendar" },
      { label: { en: "Academic Documents", bn: "একাডেমিক নথিপত্র" }, href: "/academics#documents" },
      { label: { en: "Faculty Directory", bn: "শিক্ষক নির্দেশিকা" }, href: "/faculty" },
      { label: { en: "Student Portal", bn: "স্টুডেন্ট পোর্টাল" }, href: "/portal" },
    ],
  },
  {
    label: { en: "Departments", bn: "বিভাগসমূহ" },
    href: "/departments",
    wide: true,
    children: DEPARTMENT_INDEX.map((d) => ({
      label: { en: `${d.name} (${d.code})`, bn: `${d.nameBn} (${d.code})` },
      href: `/departments/${d.slug}`,
    })),
  },
  {
    label: { en: "Admission", bn: "ভর্তি" },
    href: "/admission",
    children: [
      { label: { en: "Undergraduate Admission", bn: "স্নাতক ভর্তি" }, href: "/admission#undergraduate" },
      { label: { en: "Postgraduate Admission", bn: "স্নাতকোত্তর ভর্তি" }, href: "/admission#postgraduate" },
      { label: { en: "Admission Circulars", bn: "ভর্তি বিজ্ঞপ্তি" }, href: "/admission#circulars" },
      { label: { en: "Eligibility Requirements", bn: "যোগ্যতা" }, href: "/admission#eligibility" },
      { label: { en: "Application Guidelines", bn: "আবেদন নির্দেশিকা" }, href: "/admission#guidelines" },
      { label: { en: "Admission Results", bn: "ভর্তি ফলাফল" }, href: "/admission#results" },
      { label: { en: "Important Dates", bn: "গুরুত্বপূর্ণ তারিখ" }, href: "/admission#dates" },
      { label: { en: "FAQ", bn: "সচরাচর জিজ্ঞাসা" }, href: "/admission#faq" },
    ],
  },
  {
    label: { en: "Research", bn: "গবেষণা" },
    href: "/research",
    children: [
      { label: { en: "Faculty Research", bn: "শিক্ষক গবেষণা" }, href: "/research#faculty-research" },
      { label: { en: "Student Research", bn: "শিক্ষার্থী গবেষণা" }, href: "/research#student-research" },
      { label: { en: "Publications & Journals", bn: "প্রকাশনা ও জার্নাল" }, href: "/research#publications" },
      { label: { en: "Textile Automation", bn: "টেক্সটাইল অটোমেশন" }, href: "/research#automation" },
      { label: { en: "AI in Textiles", bn: "টেক্সটাইলে কৃত্রিম বুদ্ধিমত্তা" }, href: "/research#ai" },
      { label: { en: "Sustainable Textile Technology", bn: "টেকসই টেক্সটাইল প্রযুক্তি" }, href: "/research#sustainability" },
      { label: { en: "Smart Textiles", bn: "স্মার্ট টেক্সটাইল" }, href: "/research#smart-textiles" },
      { label: { en: "Industrial Collaboration", bn: "শিল্প সহযোগিতা" }, href: "/research#industry" },
    ],
  },
  {
    label: { en: "Campus Life", bn: "ক্যাম্পাস জীবন" },
    href: "/campus-life",
    children: [
      { label: { en: "Student Organizations", bn: "ছাত্র সংগঠন" }, href: "/campus-life#organizations" },
      { label: { en: "Clubs & Societies", bn: "ক্লাব ও সোসাইটি" }, href: "/campus-life#clubs" },
      { label: { en: "Sports & Culture", bn: "ক্রীড়া ও সংস্কৃতি" }, href: "/campus-life#sports" },
      { label: { en: "Events & Festivals", bn: "অনুষ্ঠান ও উৎসব" }, href: "/campus-life#events" },
      { label: { en: "Campus Facilities", bn: "ক্যাম্পাস সুবিধা" }, href: "/campus-life#facilities" },
      { label: { en: "Residential Facilities", bn: "আবাসিক সুবিধা" }, href: "/campus-life#residential" },
      { label: { en: "Student Welfare", bn: "শিক্ষার্থী কল্যাণ" }, href: "/campus-life#welfare" },
      { label: { en: "Campus Map", bn: "ক্যাম্পাস মানচিত্র" }, href: "/campus-life#map" },
    ],
  },
  {
    label: { en: "Notice Board", bn: "নোটিশ বোর্ড" },
    href: "/notices",
    children: [
      { label: { en: "All Notices", bn: "সকল নোটিশ" }, href: "/notices" },
      ...NOTICE_CATEGORIES.map((c) => ({ label: { en: `${c.en} Notices`, bn: `${c.bn} নোটিশ` }, href: `/notices?category=${c.key}` })),
      { label: { en: "News", bn: "সংবাদ" }, href: "/news" },
      { label: { en: "Events Calendar", bn: "ইভেন্ট ক্যালেন্ডার" }, href: "/events" },
    ],
  },
  { label: { en: "Contact", bn: "যোগাযোগ" }, href: "/contact" },
];

/** Static pages and sections that the global search can match in addition to database content. */
export const STATIC_SEARCH_INDEX: { title: string; href: string; description: string; keywords: string }[] = [
  { title: "About BUTEX", href: "/about", description: "History, mission and vision, leadership and recognition.", keywords: "about history mission vision leadership vice chancellor vc message achievements accreditation ugc" },
  { title: "History of BUTEX", href: "/about#history", description: "From a weaving school in 1921 to a university in 2010.", keywords: "history 1921 weaving school narinda tejgaon college of textile engineering and technology 2010 timeline" },
  { title: "Vice Chancellor's Message", href: "/about#vc-message", description: "Message from the Vice Chancellor.", keywords: "vice chancellor vc message leadership" },
  { title: "Academics", href: "/academics", description: "Academic programs, calendar and downloadable documents.", keywords: "academics programs programs bsc msc phd calendar syllabus documents download" },
  { title: "Academic Documents", href: "/academics#documents", description: "Downloadable academic documents and forms.", keywords: "documents download forms syllabus calendar pdf" },
  { title: "Departments", href: "/departments", description: "The nine academic departments of BUTEX.", keywords: "departments ye fe wpe ae tem tfd dce ese tmdm" },
  { title: "Admission", href: "/admission", description: "Undergraduate and postgraduate admission, circulars, eligibility and FAQ.", keywords: "admission apply undergraduate postgraduate circular eligibility requirements guidelines results dates faq test" },
  { title: "Research & Innovation", href: "/research", description: "Faculty and student research, automation, AI, sustainability and smart textiles.", keywords: "research innovation publications journals automation artificial intelligence ai sustainable smart textiles industry collaboration" },
  { title: "Campus Life", href: "/campus-life", description: "Student organizations, clubs, sports, culture, facilities and residence.", keywords: "campus life clubs societies sports cultural events festivals facilities halls residential welfare map" },
  { title: "Interactive Campus Map", href: "/campus-life#map", description: "Explore campus zones on an interactive schematic.", keywords: "campus map location buildings library hall playground" },
  { title: "Notice Board", href: "/notices", description: "Academic, examination, admission and administrative notices.", keywords: "notice notices board circular announcement pdf exam academic administrative" },
  { title: "News", href: "/news", description: "Latest news and announcements.", keywords: "news stories announcements latest" },
  { title: "Events Calendar", href: "/events", description: "University events and national observances.", keywords: "events calendar seminar festival observance" },
  { title: "Faculty Directory", href: "/faculty", description: "Search faculty members by name, department or designation.", keywords: "faculty directory teachers professor lecturer staff" },
  { title: "Student Portal", href: "/portal", description: "Routine, results, course materials and academic dashboard.", keywords: "student portal login routine results exam course materials lab schedule dashboard" },
  { title: "Contact", href: "/contact", description: "Address, phone, email and location map.", keywords: "contact address phone email map location tejgaon dhaka" },
  { title: "Image Credits", href: "/credits", description: "Photography sources and licenses.", keywords: "credits photos images license attribution" },
];
