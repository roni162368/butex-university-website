import { asc, desc, type SQL } from "drizzle-orm";
import type { AnyPgColumn, PgTable } from "drizzle-orm/pg-core";
import { admissionItems, departments, documents, events, faculty, messages, news, notices, siteContent, stats } from "@/db/schema";
import { IMAGES } from "./images";
import { DEPARTMENT_INDEX, NOTICE_CATEGORIES } from "./site";

type Rule =
  | { type: "string"; max: number; required?: boolean }
  | { type: "bool" }
  | { type: "int"; nullable?: boolean; min?: number; max?: number }
  | { type: "date"; nullable?: boolean }
  | { type: "enum"; options: readonly string[] };

export type Resource = {
  table: PgTable;
  id: AnyPgColumn;
  idType: "int" | "string";
  fields: Record<string, Rule>;
  /** Fields that must be present when creating a record. */
  required: string[];
  create: boolean;
  remove: boolean;
  touch: boolean;
  order: SQL[];
};

const str = (max: number, required = false): Rule => ({ type: "string", max, required });
const bool: Rule = { type: "bool" };
const fileRef: Rule = { type: "int", nullable: true, min: 1 };
const order: Rule = { type: "int", min: 0, max: 100000 };

export const IMAGE_OPTIONS = ["", ...Object.values(IMAGES).map((i) => i.src)];
export const EVENT_CATEGORIES = ["university", "academic", "national", "cultural", "sports"] as const;
export const ADMISSION_KINDS = ["circular", "requirement", "guideline", "date", "result", "faq"] as const;
export const ADMISSION_LEVELS = ["general", "undergraduate", "postgraduate"] as const;

/** Whitelisted, validated resources that the admin dashboard may manage. */
export const RESOURCES: Record<string, Resource> = {
  notices: {
    table: notices,
    id: notices.id,
    idType: "int",
    fields: {
      title: str(200, true),
      category: { type: "enum", options: NOTICE_CATEGORIES.map((c) => c.key) },
      summary: str(500),
      body: str(20000),
      publishedAt: { type: "date" },
      fileId: fileRef,
      fileName: str(200),
      pinned: bool,
      isSample: bool,
    },
    required: ["title", "category"],
    create: true,
    remove: true,
    touch: false,
    order: [desc(notices.publishedAt), desc(notices.id)],
  },
  news: {
    table: news,
    id: news.id,
    idType: "int",
    fields: { title: str(200, true), excerpt: str(500), body: str(30000), image: { type: "enum", options: IMAGE_OPTIONS }, publishedAt: { type: "date" }, isSample: bool },
    required: ["title"],
    create: true,
    remove: true,
    touch: false,
    order: [desc(news.publishedAt), desc(news.id)],
  },
  events: {
    table: events,
    id: events.id,
    idType: "int",
    fields: {
      title: str(200, true),
      description: str(2000),
      location: str(200),
      category: { type: "enum", options: EVENT_CATEGORIES },
      startsAt: { type: "date" },
      endsAt: { type: "date", nullable: true },
      isSample: bool,
    },
    required: ["title", "startsAt"],
    create: true,
    remove: true,
    touch: false,
    order: [desc(events.startsAt), desc(events.id)],
  },
  faculty: {
    table: faculty,
    id: faculty.id,
    idType: "int",
    fields: {
      departmentSlug: { type: "enum", options: DEPARTMENT_INDEX.map((d) => d.slug) },
      name: str(150, true),
      designation: str(150),
      email: str(200),
      phone: str(50),
      researchInterests: str(1000),
      isPlaceholder: bool,
      sortOrder: order,
    },
    required: ["name", "departmentSlug"],
    create: true,
    remove: true,
    touch: false,
    order: [asc(faculty.departmentSlug), asc(faculty.sortOrder), asc(faculty.id)],
  },
  admission: {
    table: admissionItems,
    id: admissionItems.id,
    idType: "int",
    fields: {
      kind: { type: "enum", options: ADMISSION_KINDS },
      level: { type: "enum", options: ADMISSION_LEVELS },
      title: str(300, true),
      body: str(5000),
      dateText: str(100),
      fileId: fileRef,
      fileName: str(200),
      sortOrder: order,
      isSample: bool,
    },
    required: ["title", "kind"],
    create: true,
    remove: true,
    touch: false,
    order: [asc(admissionItems.kind), asc(admissionItems.sortOrder), asc(admissionItems.id)],
  },
  documents: {
    table: documents,
    id: documents.id,
    idType: "int",
    fields: { title: str(200, true), category: str(100), description: str(500), fileId: fileRef, fileName: str(200), sortOrder: order, isSample: bool },
    required: ["title"],
    create: true,
    remove: true,
    touch: false,
    order: [asc(documents.sortOrder), asc(documents.id)],
  },
  departments: {
    table: departments,
    id: departments.id,
    idType: "int",
    fields: {
      name: str(150, true),
      nameBn: str(150),
      tagline: str(300),
      overview: str(5000),
      image: { type: "enum", options: IMAGE_OPTIONS },
      programs: str(5000),
      curriculum: str(5000),
      labs: str(5000),
      research: str(5000),
      publications: str(20000),
      email: str(200),
      phone: str(50),
      office: str(300),
    },
    required: [],
    create: false,
    remove: false,
    touch: true,
    order: [asc(departments.sortOrder), asc(departments.id)],
  },
  content: {
    table: siteContent,
    id: siteContent.key,
    idType: "string",
    fields: { value: str(30000) },
    required: [],
    create: false,
    remove: false,
    touch: true,
    order: [asc(siteContent.sortOrder), asc(siteContent.key)],
  },
  stats: {
    table: stats,
    id: stats.id,
    idType: "int",
    fields: { label: str(100, true), labelBn: str(100), value: { type: "int", nullable: true, min: 0, max: 100000000 }, suffix: str(10) },
    required: [],
    create: false,
    remove: false,
    touch: false,
    order: [asc(stats.sortOrder), asc(stats.id)],
  },
  messages: {
    table: messages,
    id: messages.id,
    idType: "int",
    fields: {},
    required: [],
    create: false,
    remove: true,
    touch: false,
    order: [desc(messages.createdAt), desc(messages.id)],
  },
};

export type Validation = { values: Record<string, unknown>; errors: Record<string, string> };

/** Validates a request body against a resource's field rules. Unknown keys are ignored. */
export function validate(resource: Resource, input: unknown, mode: "create" | "update"): Validation {
  const values: Record<string, unknown> = {};
  const errors: Record<string, string> = {};
  if (typeof input !== "object" || input === null || Array.isArray(input)) {
    return { values, errors: { _form: "The request could not be read." } };
  }
  const body = input as Record<string, unknown>;

  for (const [name, rule] of Object.entries(resource.fields)) {
    const raw = body[name];
    if (raw === undefined) {
      if (mode === "create" && resource.required.includes(name)) errors[name] = "This field is required.";
      continue;
    }
    switch (rule.type) {
      case "string": {
        if (typeof raw !== "string") {
          errors[name] = "Enter text for this field.";
          break;
        }
        const v = raw.replace(/\r\n/g, "\n").trim();
        if (rule.required && !v) errors[name] = "This field is required.";
        else if (v.length > rule.max) errors[name] = `Use ${rule.max} characters or fewer (currently ${v.length}).`;
        else values[name] = v;
        break;
      }
      case "bool":
        if (typeof raw === "boolean") values[name] = raw;
        else errors[name] = "Choose yes or no.";
        break;
      case "int": {
        if (raw === null || raw === "") {
          if (rule.nullable) values[name] = null;
          else errors[name] = "Enter a number.";
          break;
        }
        const num = typeof raw === "number" ? raw : Number(raw);
        const min = rule.min ?? -2147483648;
        const max = rule.max ?? 2147483647;
        if (!Number.isInteger(num) || num < min || num > max) errors[name] = `Enter a whole number between ${min} and ${max}.`;
        else values[name] = num;
        break;
      }
      case "date": {
        if (raw === null || raw === "") {
          if (rule.nullable) values[name] = null;
          else if (resource.required.includes(name)) errors[name] = "Choose a date and time.";
          break;
        }
        const date = new Date(String(raw));
        if (Number.isNaN(date.getTime())) errors[name] = "Enter a valid date and time.";
        else values[name] = date;
        break;
      }
      case "enum":
        if (typeof raw === "string" && rule.options.includes(raw)) values[name] = raw;
        else errors[name] = "Choose one of the listed options.";
        break;
    }
  }
  return { values, errors };
}
