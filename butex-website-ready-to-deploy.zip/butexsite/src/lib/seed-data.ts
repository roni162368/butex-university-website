/**
 * Default content used to seed a fresh database and as a fallback when the
 * database is unreachable.
 *
 * Editorial policy for this file:
 *  - Institutional facts (history, address, legal basis) come from public sources
 *    and are flagged on the site as pending official review.
 *  - Nothing here invents statistics, names of office-holders, faculty members or
 *    official announcements. Unknown values are left empty so the site renders a
 *    clear "awaiting official information" placeholder.
 *  - Demonstration records (notices, news, events, documents, faculty slots) are
 *    marked with isSample / isPlaceholder and badged as such in the interface.
 */
import { DEPARTMENT_INDEX } from "./site";

export const PROGRAM_PLACEHOLDER = [
  "Undergraduate | B.Sc. program (four years). Official program title, credit requirement and intake to be confirmed by the department.",
  "Postgraduate | Postgraduate offerings to be confirmed by the department.",
].join("\n");

type DeptSeed = {
  tagline: string;
  overview: string;
  image: string;
  curriculum: string[];
  labs: string[];
  research: string[];
};

const DEPT_DETAILS: Record<string, DeptSeed> = {
  YE: {
    tagline: "From fiber to yarn: the science of spinning.",
    overview:
      "Yarn Engineering covers the conversion of natural and man-made fibers into yarn: fiber preparation, carding, drawing, combing, roving and spinning, together with the testing and quality assurance that determine how a yarn performs in fabric.",
    image: "/images/dept-ye.jpg",
    curriculum: ["Fiber science and raw-material selection", "Blow room, carding and drawing", "Combing and roving preparation", "Ring, rotor and air-jet spinning", "Yarn structure and properties", "Textile testing and quality control", "Spinning mill planning and maintenance"],
    labs: ["Short-staple spinning practice", "Fiber and yarn testing", "Process control and quality assessment"],
    research: ["Yarn quality prediction and process optimization", "Spinning of recycled and blended fibers", "Energy and waste reduction in spinning", "Specialty and technical yarns"],
  },
  FE: {
    tagline: "Weaving, knitting and the structure of fabric.",
    overview:
      "Fabric Engineering deals with how yarns become fabrics through weaving, knitting, nonwoven and braiding processes, and with the design, analysis and performance of fabric structures for apparel, home and technical uses.",
    image: "/images/dept-fe.jpg",
    curriculum: ["Weaving preparation: winding, warping and sizing", "Shuttle and shuttleless weaving", "Weft and warp knitting", "Fabric structure and design", "Nonwovens and technical textiles", "Fabric testing and analysis", "CAD for woven and knitted fabrics"],
    labs: ["Weaving practice", "Knitting practice", "Fabric analysis and testing"],
    research: ["Technical and functional fabric structures", "Performance modeling of woven and knitted fabrics", "Nonwovens and textile composites", "Productivity and defect reduction in fabric manufacturing"],
  },
  WPE: {
    tagline: "Color, chemistry and finish.",
    overview:
      "Wet Processing Engineering focuses on the chemical processing of textiles: pretreatment, dyeing, printing and finishing, along with color science, process control and the responsible use of water, energy and chemicals.",
    image: "/images/dept-wpe.jpg",
    curriculum: ["Pretreatment: scouring, bleaching and mercerizing", "Dyeing of natural and synthetic fibers", "Textile printing", "Chemical and mechanical finishing", "Color measurement and matching", "Denim and garment washing", "Effluent and resource management"],
    labs: ["Dyeing and printing practice", "Color measurement and fastness testing", "Finishing and washing"],
    research: ["Low-liquor and waterless coloration", "Natural dyes and bio-based auxiliaries", "Functional finishing", "Process automation and right-first-time dyeing"],
  },
  AE: {
    tagline: "Engineering the garment, from pattern to production line.",
    overview:
      "Apparel Engineering applies engineering principles to garment manufacturing: pattern making, cutting, sewing and finishing, as well as work study, line balancing and quality management across the apparel supply chain.",
    image: "/images/dept-ae.jpg",
    curriculum: ["Pattern making and grading", "Marker planning, spreading and cutting", "Sewing technology and seam engineering", "Garment finishing and washing", "Work study, line balancing and lean manufacturing", "Apparel quality management", "Apparel CAD/CAM"],
    labs: ["Pattern and CAD practice", "Sewing and garment construction", "Garment testing and inspection"],
    research: ["Lean and digital apparel production", "Automation in sewing and material handling", "Fit, sizing and 3D garment simulation", "Sustainable garment manufacturing"],
  },
  TEM: {
    tagline: "Where engineering meets operations, supply chains and leadership.",
    overview:
      "Textile Engineering Management combines textile technology with industrial management, including production planning, supply chain, merchandising, costing, quality systems and compliance, to prepare engineers for managerial roles in the industry.",
    image: "/images/dept-tem.jpg",
    curriculum: ["Production planning and control", "Supply chain and logistics", "Merchandising and costing", "Quality management systems", "Industrial engineering and operations research", "Project and financial management", "Social and environmental compliance"],
    labs: ["Industrial engineering and work-study practice", "Production planning and ERP exercises", "Data analysis for operations"],
    research: ["Supply chain resilience and traceability", "Productivity and operations analytics", "Compliance, ESG and responsible sourcing", "Industry 4.0 adoption in textile enterprises"],
  },
  TFD: {
    tagline: "Design thinking for textiles and fashion.",
    overview:
      "Textile Fashion and Design brings design practice and textile technology together: surface and print design, fashion illustration, pattern and garment design, color and trend research, and digital design tools.",
    image: "/images/dept-tfd.jpg",
    curriculum: ["Design fundamentals and color theory", "Fashion illustration", "Surface, print and weave design", "Pattern design and draping", "Fashion and trend forecasting", "Digital design and CAD", "Portfolio and collection development"],
    labs: ["Design studio practice", "Print and surface design", "Digital design and CAD"],
    research: ["Heritage textiles and craft-based design", "Digital fashion and 3D prototyping", "Sustainable and circular design", "Consumer and trend research"],
  },
  DCE: {
    tagline: "The chemistry behind color and performance.",
    overview:
      "Dyes and Chemical Engineering covers the chemistry and engineering of the dyes, pigments, auxiliaries and polymers used in textiles, together with unit operations, reaction engineering and process safety.",
    image: "/images/dept-dce.jpg",
    curriculum: ["Organic and physical chemistry", "Chemistry of dyes and pigments", "Textile auxiliaries and specialty chemicals", "Polymer science", "Chemical engineering unit operations", "Reaction engineering and process control", "Chemical safety and regulation"],
    labs: ["Chemistry and synthesis practice", "Instrumental analysis", "Unit operations"],
    research: ["Safer and bio-based dyes and auxiliaries", "Functional and smart coatings", "Chemical management and restricted substances", "Polymer and fiber modification"],
  },
  ESE: {
    tagline: "Cleaner production for a water-intensive industry.",
    overview:
      "Environmental Science and Engineering addresses the environmental dimension of textile production: water and wastewater treatment, air and solid-waste management, energy efficiency, life-cycle assessment and environmental compliance.",
    image: "/images/dept-ese.jpg",
    curriculum: ["Environmental chemistry and microbiology", "Water and wastewater engineering", "Effluent treatment plant design and operation", "Air pollution and solid-waste management", "Energy and resource efficiency", "Life-cycle assessment", "Environmental law, standards and auditing"],
    labs: ["Water and effluent analysis", "Treatment process studies", "Environmental monitoring"],
    research: ["Effluent treatment and water reuse", "Sludge and solid-waste valorization", "Carbon and water footprinting", "Cleaner production and circularity"],
  },
  TMDM: {
    tagline: "Designing, automating and maintaining the machines of the mill.",
    overview:
      "Textile Machinery Design and Maintenance covers the mechanical, electrical and control engineering of textile machinery, including machine elements, drives, mechatronics and automation, and the maintenance strategies that keep mills running.",
    image: "/images/dept-tmdm.jpg",
    curriculum: ["Engineering mechanics and machine elements", "Theory of machines and mechanisms", "Electrical drives and industrial electronics", "Mechatronics and PLC-based control", "Textile machinery design", "Maintenance engineering and reliability", "Utilities: boilers, compressors and HVAC"],
    labs: ["Machine shop and workshop practice", "Electrical and electronics practice", "Control and automation"],
    research: ["Machine automation and retrofitting", "Condition monitoring and predictive maintenance", "Energy-efficient drives and utilities", "Machine design for new processes"],
  },
};

export const DEPARTMENT_SEED = DEPARTMENT_INDEX.map((d, i) => {
  const x = DEPT_DETAILS[d.code];
  return {
    slug: d.slug,
    code: d.code,
    name: d.name,
    nameBn: d.nameBn,
    tagline: x.tagline,
    overview: x.overview,
    image: x.image,
    programs: PROGRAM_PLACEHOLDER,
    curriculum: x.curriculum.join("\n"),
    labs: x.labs.join("\n"),
    research: x.research.join("\n"),
    publications: "",
    email: "",
    phone: "",
    office: "",
    sortOrder: i + 1,
  };
});

export const FACULTY_SEED = DEPARTMENT_INDEX.flatMap((d) =>
  [1, 2, 3].map((n) => ({
    departmentSlug: d.slug,
    name: `Faculty profile ${d.code}-0${n}`,
    designation: "Designation to be confirmed",
    email: "",
    phone: "",
    researchInterests: "Research interests to be added by the department.",
    isPlaceholder: true,
    sortOrder: n,
  })),
);

export const STATS_SEED = [
  { key: "departments", label: "Academic departments", labelBn: "একাডেমিক বিভাগ", value: DEPARTMENT_INDEX.length as number | null, suffix: "", sortOrder: 1 },
  { key: "undergraduate_programs", label: "Undergraduate programs", labelBn: "স্নাতক প্রোগ্রাম", value: null as number | null, suffix: "", sortOrder: 2 },
  { key: "students", label: "Students", labelBn: "শিক্ষার্থী", value: null as number | null, suffix: "", sortOrder: 3 },
  { key: "faculty_members", label: "Faculty members", labelBn: "শিক্ষক", value: null as number | null, suffix: "", sortOrder: 4 },
  { key: "research_highlights", label: "Research & innovation projects", labelBn: "গবেষণা ও উদ্ভাবন প্রকল্প", value: null as number | null, suffix: "", sortOrder: 5 },
];

const c = (key: string, section: string, label: string, value: string, help = "") => ({ key, section, label, value, help });

export const CONTENT_SEED = [
  c("announcement", "Homepage", "Site-wide announcement bar", "", "Shown at the very top of every page. Leave empty to hide."),
  c(
    "hero_intro",
    "Homepage",
    "Hero introduction",
    "From a weaving school founded in 1921 to Bangladesh's public university for textile engineering, BUTEX educates the engineers, designers and researchers who shape a global industry.",
  ),
  c(
    "hero_intro_bn",
    "Homepage",
    "Hero introduction (Bengali)",
    "১৯২১ সালে প্রতিষ্ঠিত একটি বয়ন বিদ্যালয় থেকে আজকের বিশ্ববিদ্যালয় — বুটেক্স গড়ে তোলে সেই প্রকৌশলী, ডিজাইনার ও গবেষকদের, যাঁরা একটি বৈশ্বিক শিল্পকে এগিয়ে নেন।",
    "Shown when the visitor switches the site to Bengali.",
  ),
  c(
    "about_summary",
    "About",
    "About summary",
    "Bangladesh University of Textiles (BUTEX) is a public university in Tejgaon, Dhaka, dedicated to textile engineering education and research. Its roots reach back to a weaving school opened at Narinda, Dhaka in 1921. After several transformations, including the College of Textile Engineering and Technology that introduced a four-year bachelor's degree in 1978, it became a university on 22 December 2010.",
  ),
  c(
    "history_timeline",
    "About",
    "History timeline",
    [
      "1921 | A weaving school opens at Narinda, Dhaka, offering artisan-level courses in textiles.",
      "1935 | The school is upgraded and becomes the East Bengal Textile Institute.",
      "1950 | The institute is renamed East Pakistan Textile Institute and offers diploma courses in textile technology.",
      "1960 | Academic activities begin at the present campus in Tejgaon Industrial Area.",
      "1971 | Following independence, the institute becomes the Bangladesh Textile Institute.",
      "1978 | A four-year bachelor's degree in textile technology is introduced in affiliation with the University of Dhaka; the institute becomes the College of Textile Engineering and Technology.",
      "2010 | The Bangladesh Textile University Act, 2010 takes effect on 22 December, establishing Bangladesh University of Textiles.",
      "2011 | The university is formally inaugurated on 15 March.",
    ].join("\n"),
    "One milestone per line in the form: year | description",
  ),
  c("mission", "About", "Mission statement", "", "Leave empty to show an 'awaiting official text' placeholder."),
  c("vision", "About", "Vision statement", "", "Leave empty to show an 'awaiting official text' placeholder."),
  c(
    "leadership",
    "About",
    "Leadership roles",
    ["Chancellor | ", "Vice Chancellor | ", "Pro-Vice Chancellor | ", "Treasurer | ", "Registrar | "].join("\n"),
    "One per line in the form: role | name. Leave the name blank until it is confirmed.",
  ),
  c("vc_name", "About", "Vice Chancellor: name", "", "Leave empty until confirmed."),
  c("vc_message", "About", "Vice Chancellor: message", "", "Separate paragraphs with a blank line."),
  c("achievements", "About", "University achievements", "", "One achievement per line. Leave empty to show a placeholder."),
  c(
    "accreditation",
    "About",
    "Accreditation & recognition",
    "BUTEX is a public university established under the Bangladesh Textile University Act, 2010 (Act No. 49 of 2010) and operates within the framework of the University Grants Commission of Bangladesh (UGC).",
  ),
  c("accreditation_list", "About", "Program accreditation & memberships", "", "One per line in the form: body | detail. Leave empty to show a placeholder."),
  c(
    "admission_intro",
    "Admission",
    "Admission introduction",
    "Admission to BUTEX is competitive and governed by the official circular published for each intake. This page brings the circulars, eligibility rules, key dates and results together in one place.",
  ),
  c(
    "research_intro",
    "Research",
    "Research introduction",
    "Research at BUTEX is oriented towards the questions that matter to Bangladesh's textile and apparel sector: productivity, quality, sustainability, and the technologies that will define the next generation of mills and materials.",
  ),
  c(
    "campus_intro",
    "Campus Life",
    "Campus life introduction",
    "The Tejgaon campus brings classrooms, laboratories, residential halls and playgrounds together in the heart of Dhaka's industrial district, a short distance from the mills and offices where many graduates build their careers.",
  ),
  c("contact_address", "Contact", "Postal address", "92 Shaheed Tajuddin Ahmed Avenue\nTejgaon Industrial Area, Dhaka-1208\nBangladesh"),
  c("contact_phone", "Contact", "Phone", "01500121121"),
  c("contact_fax", "Contact", "Fax", "+880248112698"),
  c("contact_email", "Contact", "Email", "info@butex.edu.bd"),
  c("office_hours", "Contact", "Office hours", "", "Leave empty until confirmed."),
  c("social_facebook", "Social media", "Facebook URL", "https://www.facebook.com/info.butex"),
  c("social_youtube", "Social media", "YouTube URL", "", "Leave empty to hide."),
  c("social_linkedin", "Social media", "LinkedIn URL", "", "Leave empty to hide."),
  c("social_x", "Social media", "X (Twitter) URL", "", "Leave empty to hide."),
].map((row, i) => ({ ...row, sortOrder: i + 1 }));

/** Midnight (Dhaka) of today plus an offset, at a given Dhaka hour. */
export function relativeDate(days: number, hourDhaka = 0): Date {
  const now = new Date(Date.now() + 6 * 3600_000);
  const base = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  return new Date(base + days * 86_400_000 + (hourDhaka - 6) * 3600_000);
}

const SAMPLE_BODY =
  "This is a sample notice created to demonstrate the notice board. It is not an official announcement of Bangladesh University of Textiles. Administrators can replace or delete it from the admin dashboard.";

export const NOTICE_SEED = [
  { title: "Sample notice: Class routine for the upcoming term", category: "academic", summary: "Demonstrates an academic notice with a PDF attachment.", days: -1, pinned: true },
  { title: "Sample notice: Term final examination schedule", category: "examination", summary: "Demonstrates an examination notice with a downloadable schedule.", days: -2, pinned: false },
  { title: "Sample notice: Undergraduate admission circular", category: "admission", summary: "Demonstrates how an admission circular is listed and downloaded.", days: -3, pinned: true },
  { title: "Sample notice: Office hours during the holiday period", category: "administrative", summary: "Demonstrates an administrative notice.", days: -5, pinned: false },
  { title: "Sample notice: Seminar on sustainable textile processing", category: "events", summary: "Demonstrates an event announcement.", days: -6, pinned: false },
  { title: "Sample notice: Course registration deadline", category: "academic", summary: "Demonstrates a deadline reminder.", days: -9, pinned: false },
  { title: "Sample notice: Seat plan for the term final examination", category: "examination", summary: "Demonstrates a seat-plan notice with attachment.", days: -12, pinned: false },
  { title: "Sample notice: Postgraduate admission test result", category: "admission", summary: "Demonstrates a result notice.", days: -15, pinned: false },
  { title: "Sample notice: Tender and procurement notification", category: "administrative", summary: "Demonstrates a procurement notice.", days: -19, pinned: false },
  { title: "Sample notice: Inter-department sports week", category: "events", summary: "Demonstrates a campus activity announcement.", days: -23, pinned: false },
].map((n) => ({ ...n, body: SAMPLE_BODY }));

export const NEWS_SEED = [
  {
    slug: "sample-student-research-showcase",
    title: "Sample story: Student research showcase on textile automation",
    excerpt: "A placeholder article showing how research news will be presented once the news desk begins publishing.",
    image: "/images/robot-white.jpg",
    days: -2,
  },
  {
    slug: "sample-seminar-sustainable-coloration",
    title: "Sample story: Seminar explores sustainable coloration",
    excerpt: "A placeholder article illustrating the layout for seminar and conference coverage.",
    image: "/images/threads.jpg",
    days: -7,
  },
  {
    slug: "sample-welcoming-new-cohort",
    title: "Sample story: Welcoming a new cohort to campus",
    excerpt: "A placeholder article illustrating how campus news and photo stories will appear.",
    image: "/images/graduation-caps.jpg",
    days: -14,
  },
].map((n) => ({
  ...n,
  body:
    "This is sample content created to demonstrate the news section. It does not describe a real event at Bangladesh University of Textiles.\n\nWhen the university's news desk starts publishing, each story will carry a headline, a short summary, a lead photograph with credit, and the full article text. Stories are managed from the admin dashboard and appear on the homepage automatically.\n\nAdministrators can edit or delete this sample at any time.",
}));

export function eventSeed() {
  const year = new Date(Date.now() + 6 * 3600_000).getUTCFullYear();
  const allDay = (y: number, m: number, d: number) => new Date(Date.UTC(y, m - 1, d) - 6 * 3600_000);
  const national = [year, year + 1].flatMap((y) => [
    { title: "International Mother Language Day", description: "National observance (Shaheed Dibosh), 21 February.", startsAt: allDay(y, 2, 21) },
    { title: "Independence Day", description: "National observance, 26 March.", startsAt: allDay(y, 3, 26) },
    { title: "Pohela Boishakh (Bengali New Year)", description: "National observance, 14 April.", startsAt: allDay(y, 4, 14) },
    { title: "Victory Day", description: "National observance, 16 December.", startsAt: allDay(y, 12, 16) },
  ]);
  const sample = [
    { title: "Sample event: Departmental research seminar", description: "Placeholder event demonstrating the events calendar.", location: "Venue to be announced", days: 3, hour: 10 },
    { title: "Sample event: Orientation program", description: "Placeholder event demonstrating the events calendar.", location: "Venue to be announced", days: 9, hour: 9 },
    { title: "Sample event: Industry career talk", description: "Placeholder event demonstrating the events calendar.", location: "Venue to be announced", days: 15, hour: 14 },
    { title: "Sample event: Inter-department sports week", description: "Placeholder event demonstrating a multi-day entry.", location: "Central playground", days: 22, hour: 8, lengthDays: 4 },
    { title: "Sample event: Cultural evening", description: "Placeholder event demonstrating the events calendar.", location: "Venue to be announced", days: 30, hour: 17 },
  ];
  return [
    ...national.map((n) => ({ ...n, location: "", category: "national", endsAt: null as Date | null, isSample: false })),
    ...sample.map((s) => ({
      title: s.title,
      description: s.description,
      location: s.location,
      category: "university",
      startsAt: relativeDate(s.days, s.hour),
      endsAt: s.lengthDays ? relativeDate(s.days + s.lengthDays, 17) : (null as Date | null),
      isSample: true,
    })),
  ];
}

const a = (kind: string, level: string, title: string, body: string, dateText = "", isSample = false) => ({ kind, level, title, body, dateText, isSample });

export const ADMISSION_SEED = [
  a("requirement", "undergraduate", "Academic background", "Applicants are expected to have completed the Higher Secondary Certificate (HSC) or an equivalent qualification with a science background. The subjects and minimum grades required are set out in each year's official admission circular."),
  a("requirement", "undergraduate", "Admission test", "Selection is made through a competitive admission test. The syllabus, distribution of marks and rules for preparing the merit list are published in the circular for the relevant intake."),
  a("requirement", "undergraduate", "Department allocation", "Departments are allocated according to merit position and the preferences submitted by the candidate, following the rules stated in the circular."),
  a("requirement", "postgraduate", "Academic background", "Eligibility for postgraduate programs, including the accepted bachelor's degrees and minimum results, is defined in the postgraduate admission circular."),
  a("requirement", "postgraduate", "Selection", "The selection process for postgraduate applicants (written test, viva voce or both) is described in the relevant circular."),
  a("guideline", "general", "Read the official circular", "Start with the circular for the intake you are applying to. It is the authoritative source for eligibility, fees and dates."),
  a("guideline", "general", "Check your eligibility", "Compare your academic results with the requirements listed in the circular before you begin an application."),
  a("guideline", "general", "Complete the online application", "Fill in the application form through the channel named in the circular and upload the documents requested."),
  a("guideline", "general", "Pay the application fee", "Pay the fee using one of the methods listed in the circular and keep the payment reference."),
  a("guideline", "general", "Download your admit card", "Once admit cards are released, download and print yours. You will need it to enter the examination hall."),
  a("guideline", "general", "Sit the admission test", "Arrive early at the allocated center with your admit card and the identification documents specified."),
  a("guideline", "general", "Follow the result and enrolment instructions", "Results, department allocation and enrolment steps are published on this page and on the notice board."),
  a("date", "undergraduate", "Publication of admission circular", "", "To be announced"),
  a("date", "undergraduate", "Online application opens", "", "To be announced"),
  a("date", "undergraduate", "Application deadline", "", "To be announced"),
  a("date", "undergraduate", "Admit card available", "", "To be announced"),
  a("date", "undergraduate", "Admission test", "", "To be announced"),
  a("date", "undergraduate", "Publication of results", "", "To be announced"),
  a("date", "postgraduate", "Publication of postgraduate circular", "", "To be announced"),
  a("date", "postgraduate", "Application deadline", "", "To be announced"),
  a("circular", "undergraduate", "Sample: Undergraduate admission circular", "Placeholder entry demonstrating how a circular and its PDF are listed.", "", true),
  a("circular", "postgraduate", "Sample: Postgraduate admission circular", "Placeholder entry demonstrating how a circular and its PDF are listed.", "", true),
  a("faq", "general", "Where can I find the official admission circular?", "Circulars are published in the Admission Circulars section of this page and on the Notice Board under the Admission category as soon as they are released."),
  a("faq", "general", "What are the minimum requirements to apply?", "Requirements can change from one intake to the next. Please rely on the circular for the intake you are applying to rather than on figures from previous years."),
  a("faq", "general", "How do I apply?", "Applications are submitted online through the channel named in the circular. The Application Guidelines section above outlines the usual steps."),
  a("faq", "general", "When will the admission test be held?", "Dates are listed under Important Dates once they are confirmed. Entries marked 'To be announced' have not yet been published."),
  a("faq", "general", "How will I know my result?", "Results and merit lists are published in the Admission Results section and on the Notice Board."),
  a("faq", "general", "Who can I contact with a question about admission?", "Please use the contact details on the Contact page. A dedicated admission helpline, if one is announced, will be listed in the circular."),
].map((row, i) => ({ ...row, sortOrder: i + 1 }));

export const DOCUMENT_SEED = [
  { title: "Academic calendar (template)", category: "Calendar", description: "Placeholder for the official academic calendar." },
  { title: "Undergraduate academic ordinance (placeholder)", category: "Regulations", description: "Placeholder for the rules governing undergraduate study." },
  { title: "Undergraduate syllabus (placeholder)", category: "Syllabus", description: "Placeholder for departmental syllabi." },
  { title: "Course registration form (placeholder)", category: "Forms", description: "Placeholder for the course registration form." },
  { title: "Transcript and certificate application (placeholder)", category: "Forms", description: "Placeholder for transcript and certificate requests." },
].map((d, i) => ({ ...d, sortOrder: i + 1, isSample: true }));
