"use client";

import { useSyncExternalStore } from "react";

/** localStorage with an in-memory fallback (storage can be blocked in embedded or private contexts). */
const memory = new Map<string, string>();
export const store = {
  get(key: string): string | null {
    try {
      return window.localStorage.getItem(key) ?? memory.get(key) ?? null;
    } catch {
      return memory.get(key) ?? null;
    }
  },
  set(key: string, value: string) {
    memory.set(key, value);
    try {
      window.localStorage.setItem(key, value);
    } catch {
      /* ignore */
    }
  },
  remove(key: string) {
    memory.delete(key);
    try {
      window.localStorage.removeItem(key);
    } catch {
      /* ignore */
    }
  },
};

const PREFS_EVENT = "butex:prefs";
const subscribe = (cb: () => void) => {
  window.addEventListener(PREFS_EVENT, cb);
  return () => window.removeEventListener(PREFS_EVENT, cb);
};
const notify = () => window.dispatchEvent(new Event(PREFS_EVENT));

export type Lang = "en" | "bn";
export type Theme = "light" | "dark";

export function useLang(): Lang {
  return useSyncExternalStore(
    subscribe,
    () => (document.documentElement.dataset.lang === "bn" ? "bn" : "en"),
    () => "en",
  );
}

export function useTheme(): Theme {
  return useSyncExternalStore(
    subscribe,
    () => (document.documentElement.classList.contains("dark") ? "dark" : "light"),
    () => "light",
  );
}

export function useLargeText(): boolean {
  return useSyncExternalStore(
    subscribe,
    () => document.documentElement.dataset.fs === "lg",
    () => false,
  );
}

export function setLang(lang: Lang) {
  const root = document.documentElement;
  root.dataset.lang = lang;
  root.lang = lang;
  store.set("butex-lang", lang);
  notify();
}

export function setTheme(theme: Theme) {
  document.documentElement.classList.toggle("dark", theme === "dark");
  store.set("butex-theme", theme);
  notify();
}

export function setLargeText(on: boolean) {
  if (on) document.documentElement.dataset.fs = "lg";
  else delete document.documentElement.dataset.fs;
  store.set("butex-fs", on ? "lg" : "md");
  notify();
}

const TOKEN_EVENT = "butex:token";
const subscribeToken = (cb: () => void) => {
  window.addEventListener(TOKEN_EVENT, cb);
  return () => window.removeEventListener(TOKEN_EVENT, cb);
};

/** Session token from storage. `undefined` until the browser has been consulted (server render and hydration). */
export function useStoredToken(key: string): string | null | undefined {
  return useSyncExternalStore(
    subscribeToken,
    () => store.get(key),
    () => undefined,
  );
}

export function setStoredToken(key: string, value: string | null) {
  if (value) store.set(key, value);
  else store.remove(key);
  window.dispatchEvent(new Event(TOKEN_EVENT));
}

export class ApiError extends Error {
  status: number;
  fields: Record<string, string>;
  constructor(message: string, status: number, fields: Record<string, string> = {}) {
    super(message);
    this.status = status;
    this.fields = fields;
  }
}

type ApiOptions = { method?: string; token?: string | null; json?: unknown; form?: FormData; signal?: AbortSignal };

/** fetch wrapper that sends the bearer token and turns failures into readable errors. */
export async function api<T>(path: string, opts: ApiOptions = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: "application/json" };
  if (opts.token) headers.Authorization = `Bearer ${opts.token}`;
  if (opts.json !== undefined) headers["Content-Type"] = "application/json";

  let res: Response;
  try {
    res = await fetch(path, {
      method: opts.method ?? (opts.json !== undefined || opts.form ? "POST" : "GET"),
      headers,
      body: opts.form ?? (opts.json !== undefined ? JSON.stringify(opts.json) : undefined),
      signal: opts.signal,
      cache: "no-store",
    });
  } catch (err) {
    if (err instanceof DOMException && err.name === "AbortError") throw err;
    throw new ApiError("We couldn't reach the server. Check your connection and try again.", 0);
  }

  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    /* non-JSON response */
  }
  if (!res.ok) {
    const body = (data ?? {}) as { error?: string; fields?: Record<string, string> };
    throw new ApiError(body.error ?? `Something went wrong (${res.status}). Please try again.`, res.status, body.fields ?? {});
  }
  return data as T;
}
