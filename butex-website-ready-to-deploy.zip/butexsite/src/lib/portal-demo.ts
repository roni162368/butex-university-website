/**
 * Demonstration data for the student portal. None of this represents real
 * courses, timetables or academic records; it exists to show how the portal
 * will look once it is connected to the university's student information system.
 */
export const PORTAL_DEMO = {
  profile: {
    program: "B.Sc. program (demonstration)",
    level: "Level 2",
    term: "Term I",
    session: "Demonstration session",
    advisor: "To be assigned",
  },
  days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday"],
  slots: ["09:00 – 09:50", "10:00 – 10:50", "11:00 – 11:50", "12:00 – 12:50", "14:00 – 16:50"],
  /** [dayIndex, slotIndex, code, type] */
  routine: [
    [0, 0, "DEMO 201", "Theory"],
    [0, 1, "DEMO 203", "Theory"],
    [0, 4, "DEMO 202", "Lab"],
    [1, 0, "DEMO 205", "Theory"],
    [1, 2, "DEMO 207", "Theory"],
    [2, 1, "DEMO 201", "Theory"],
    [2, 2, "DEMO 203", "Theory"],
    [2, 4, "DEMO 204", "Lab"],
    [3, 0, "DEMO 207", "Theory"],
    [3, 3, "DEMO 205", "Theory"],
    [4, 1, "DEMO 201", "Theory"],
    [4, 4, "DEMO 206", "Lab"],
  ] as [number, number, string, string][],
  courses: {
    "DEMO 201": { title: "Sample Core Course A", credits: 3 },
    "DEMO 202": { title: "Sample Core Course A (Sessional)", credits: 1.5 },
    "DEMO 203": { title: "Sample Core Course B", credits: 3 },
    "DEMO 204": { title: "Sample Core Course B (Sessional)", credits: 1.5 },
    "DEMO 205": { title: "Sample Mathematics Course", credits: 3 },
    "DEMO 206": { title: "Sample Workshop Practice", credits: 1.5 },
    "DEMO 207": { title: "Sample Humanities Course", credits: 2 },
  } as Record<string, { title: string; credits: number }>,
  /** Exam offsets in days from today. */
  exams: [
    { code: "DEMO 201", inDays: 24, time: "10:00 AM – 1:00 PM", room: "Room to be announced" },
    { code: "DEMO 203", inDays: 27, time: "10:00 AM – 1:00 PM", room: "Room to be announced" },
    { code: "DEMO 205", inDays: 31, time: "10:00 AM – 1:00 PM", room: "Room to be announced" },
    { code: "DEMO 207", inDays: 34, time: "10:00 AM – 12:00 PM", room: "Room to be announced" },
  ],
  results: [
    {
      term: "Level 1 · Term I",
      gpa: 3.58,
      courses: [
        { code: "DEMO 101", title: "Sample Foundation Course A", credits: 3, grade: "A-", point: 3.5 },
        { code: "DEMO 103", title: "Sample Physics Course", credits: 3, grade: "A", point: 3.75 },
        { code: "DEMO 105", title: "Sample Chemistry Course", credits: 3, grade: "B+", point: 3.25 },
        { code: "DEMO 107", title: "Sample Mathematics Course", credits: 3, grade: "A", point: 3.75 },
        { code: "DEMO 102", title: "Sample Sessional", credits: 1.5, grade: "A+", point: 4.0 },
      ],
    },
    {
      term: "Level 1 · Term II",
      gpa: 3.67,
      courses: [
        { code: "DEMO 111", title: "Sample Foundation Course B", credits: 3, grade: "A", point: 3.75 },
        { code: "DEMO 113", title: "Sample Engineering Drawing", credits: 3, grade: "A-", point: 3.5 },
        { code: "DEMO 115", title: "Sample Statistics Course", credits: 3, grade: "A", point: 3.75 },
        { code: "DEMO 117", title: "Sample Communication Course", credits: 2, grade: "A-", point: 3.5 },
        { code: "DEMO 112", title: "Sample Sessional", credits: 1.5, grade: "A+", point: 4.0 },
      ],
    },
  ],
  labs: [
    { day: "Sunday", time: "2:00 PM – 4:50 PM", code: "DEMO 202", lab: "Laboratory to be announced", group: "Group A" },
    { day: "Tuesday", time: "2:00 PM – 4:50 PM", code: "DEMO 204", lab: "Laboratory to be announced", group: "Group A" },
    { day: "Thursday", time: "2:00 PM – 4:50 PM", code: "DEMO 206", lab: "Workshop to be announced", group: "Group A" },
  ],
};

export type PortalDemo = typeof PORTAL_DEMO;
