/**
 * Image registry with attribution.
 * `butex: true`  → an actual photograph of BUTEX (Wikimedia Commons, CC BY-SA).
 * `butex: false` → illustrative stock photography (Pexels license) to be replaced
 *                  with official university photography when available.
 */
export type Img = {
  src: string;
  alt: string;
  credit: string;
  license: string;
  source: string;
  butex: boolean;
};

const commons = (file: string) => `https://commons.wikimedia.org/wiki/File:${file}`;
const pexels = (id: number) => `https://www.pexels.com/photo/${id}/`;
const stock = (src: string, alt: string, credit: string, id: number): Img => ({
  src: `/images/${src}.jpg`,
  alt,
  credit,
  license: "Pexels License",
  source: pexels(id),
  butex: false,
});

export const IMAGES = {
  campusOld: {
    src: "/images/campus-old-building.jpg",
    alt: "The old academic building of BUTEX with its garden courtyard",
    credit: "Blackpipets",
    license: "CC BY-SA 4.0",
    source: commons("BUTEX_Old_Academic_Building.jpg"),
    butex: true,
  },
  campusAcademic: {
    src: "/images/campus-academic-building.jpg",
    alt: "High-rise academic building of BUTEX seen above the campus trees",
    credit: "Md. Golam Mukit Khan",
    license: "CC BY-SA 4.0",
    source: commons("Bangabandhu_Academic_Building_of_BUTEX_by_Mukit.jpg"),
    butex: true,
  },
  campusAerial: {
    src: "/images/campus-aerial.jpg",
    alt: "Aerial view of the BUTEX campus in Tejgaon, Dhaka",
    credit: "Blackpipets",
    license: "CC BY-SA 4.0",
    source: commons("Butex_Arial_View.jpg"),
    butex: true,
  },
  shaheedMinar: {
    src: "/images/campus-shaheed-minar.jpg",
    alt: "The Shaheed Minar monument on the BUTEX campus",
    credit: "Md. Golam Mukit Khan",
    license: "CC BY-SA 4.0",
    source: "https://commons.wikimedia.org/wiki/Category:Bangladesh_University_of_Textiles",
    butex: true,
  },
  labYarn: {
    src: "/images/lab-yarn.jpg",
    alt: "Ring spinning frame in the yarn manufacturing laboratory at BUTEX",
    credit: "Saubannnn",
    license: "CC BY-SA 3.0",
    source: commons("Yarnmanufacturinglab.jpg"),
    butex: true,
  },
  labFabric: {
    src: "/images/lab-fabric.jpg",
    alt: "Loom in the fabric manufacturing laboratory at BUTEX",
    credit: "Saubannnn",
    license: "CC BY-SA 3.0",
    source: commons("Fabricmanufacturinglab.jpg"),
    butex: true,
  },
  labWet: {
    src: "/images/lab-wet.jpg",
    alt: "Dyeing machinery in the wet processing laboratory at BUTEX",
    credit: "Saubannnn",
    license: "CC BY-SA 3.0",
    source: commons("Wetprocessinglab.jpg"),
    butex: true,
  },
  labApparel: {
    src: "/images/lab-apparel.jpg",
    alt: "Machinery in the apparel manufacturing laboratory at BUTEX",
    credit: "Saubannnn",
    license: "CC BY-SA 3.0",
    source: commons("Apparelmanufacturinglab.jpg"),
    butex: true,
  },
  deptYE: stock("dept-ye", "White yarn packages on a spinning production line", "Rajesh Kumar Verma", 8246743),
  deptFE: stock("dept-fe", "Close view of white warp threads on a weaving loom", "Magda Ehlers", 32655890),
  deptWPE: stock("dept-wpe", "Lengths of indigo-dyed fabric hanging to dry", "Nguyen Phuong Anh", 40213163),
  deptAE: stock("dept-ae", "Operator sewing a garment on an industrial sewing machine", "EqualStock IN", 31030991),
  deptTEM: stock("dept-tem", "Team reviewing production plans around a table", "Yan Krukau", 7691694),
  deptTFD: stock("dept-tfd", "Designer sketching garments beside fabric swatches", "Kaboompics", 8527903),
  deptDCE: stock("dept-dce", "Researcher examining a colored solution in a chemistry laboratory", "Poddar Group of Institutions", 37951908),
  deptESE: stock("dept-ese", "Aerial view of a wastewater treatment plant", "Hicham Oukachi", 11452356),
  deptTMDM: stock("dept-tmdm", "Close view of precision steel gears", "cottonbro studio", 7568428),
  spinningFloor: stock("spinning-floor", "Technician walking along a modern ring-spinning floor", "Rajesh Kumar Verma", 8246479),
  labResearch: stock("lab-research", "Researcher using a microscope in a laboratory", "Yusuf Çelik", 32213405),
  labStudents: stock("lab-students", "Two students in lab coats carrying out an experiment", "Poddar Group of Institutions", 37765899),
  labAnalysis: stock("lab-analysis", "Researchers working at a laboratory bench", "Mehmet Balcı", 30349990),
  robotArm: stock("robot-arm", "Industrial robotic arm in an automation laboratory", "Diego Martinez", 29320998),
  robotWhite: stock("robot-white", "White collaborative robot arm", "Magda Ehlers", 35280311),
  factoryFloor: stock("factory-floor", "Garment factory floor with sewing lines", "EqualStock IN", 31019572),
  threads: stock("threads", "Brightly colored spools of thread", "Syamhari Syamhari", 7116999),
  bobbins: stock("bobbins", "Thread spools and metal bobbins on a wooden table", "Jahra Tasfia Reza", 39081600),
  sportsField: stock("sports-field", "Green sports field with a pavilion", "Gang Liang", 36393288),
  graduates: stock("graduates", "Group of graduates in gowns in front of a university building", "Saad Bin Hasan", 35487002),
  graduationCaps: stock("graduation-caps", "Graduates throwing their caps in the air", "Sun", 30562665),
  library: stock("library", "Student reading beside library shelves", "Yan Krukau", 8199762),
  dyePowders: stock("dye-powders", "Sacks of vividly colored dye powders", "Francesco Sgura", 37852968),
  planning: stock("planning", "Hands annotating engineering drawings", "Anna Shvets", 5324975),
  waterFilters: stock("water-filters", "Filtration vessels at a water treatment installation", "Alexey Demidov", 12726229),
} satisfies Record<string, Img>;

export type ImageKey = keyof typeof IMAGES;

const BY_SRC = new Map<string, Img>(Object.values(IMAGES).map((i) => [i.src, i]));

/** Look up attribution for an image path stored in the database. */
export function imageBySrc(src: string | null | undefined, fallback: Img = IMAGES.threads): Img {
  if (!src) return fallback;
  return BY_SRC.get(src) ?? { src, alt: "", credit: "", license: "", source: "", butex: false };
}

export function creditLine(img: Img): string {
  if (!img.credit) return "";
  return img.butex ? `Photo: ${img.credit} / ${img.license}` : `Illustrative image · ${img.credit} / Pexels`;
}
