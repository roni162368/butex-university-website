import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { and, eq, gt, lt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users, type User } from "@/db/schema";

const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

/**
 * Demonstration accounts. They exist so the portal and admin dashboard can be
 * explored before the university's own identity system is connected.
 * Set ADMIN_EMAIL / ADMIN_PASSWORD before first start to replace the demo admin.
 */
export const DEMO_MODE = !process.env.ADMIN_PASSWORD;
export const ACCOUNTS = {
  admin: {
    identifier: (process.env.ADMIN_EMAIL || "admin@butex.demo").toLowerCase(),
    password: process.env.ADMIN_PASSWORD || "butex-admin-demo",
    name: "Site Administrator",
  },
  student: {
    identifier: "demo-0001",
    display: "DEMO-0001",
    password: "butex-student-demo",
    name: "Demo Student",
  },
} as const;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [alg, salt, hash] = stored.split("$");
  if (alg !== "scrypt" || !salt || !hash) return false;
  const expected = Buffer.from(hash, "hex");
  const actual = scryptSync(password, salt, expected.length);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

const sha256 = (value: string) => createHash("sha256").update(value).digest("hex");

/** Creates a session and returns the opaque bearer token (only its hash is stored). */
export async function createSession(userId: number): Promise<string> {
  const token = randomBytes(32).toString("hex");
  await db.insert(sessions).values({ tokenHash: sha256(token), userId, expiresAt: new Date(Date.now() + SESSION_TTL_MS) });
  await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
  return token;
}

function bearer(req: Request): string | null {
  const match = /^Bearer\s+([a-f0-9]{64})$/i.exec(req.headers.get("authorization") ?? "");
  return match ? match[1].toLowerCase() : null;
}

export async function getSessionUser(req: Request): Promise<User | null> {
  const token = bearer(req);
  if (!token) return null;
  const rows = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.tokenHash, sha256(token)), gt(sessions.expiresAt, new Date())))
    .limit(1);
  return rows[0]?.user ?? null;
}

export async function destroySession(req: Request): Promise<void> {
  const token = bearer(req);
  if (token) await db.delete(sessions).where(eq(sessions.tokenHash, sha256(token)));
}

/** Returns the authenticated user, or a ready-to-return 401/403 response. */
export async function requireRole(req: Request, role: "admin" | "student"): Promise<User | Response> {
  let user: User | null = null;
  try {
    user = await getSessionUser(req);
  } catch {
    return Response.json({ error: "The service is temporarily unavailable. Please try again." }, { status: 503 });
  }
  if (!user) return Response.json({ error: "Your session has expired. Please sign in again." }, { status: 401 });
  if (user.role !== role) return Response.json({ error: "You do not have permission to do that." }, { status: 403 });
  return user;
}

export function publicUser(user: User) {
  return { id: user.id, name: user.name, role: user.role, identifier: user.identifier, departmentSlug: user.departmentSlug, isDemo: user.isDemo };
}

/** Small in-memory limiter for sign-in and contact-form attempts. */
const buckets = new Map<string, { count: number; reset: number }>();
export function rateLimit(key: string, max = 8, windowMs = 10 * 60_000): boolean {
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.reset < now) {
    buckets.set(key, { count: 1, reset: now + windowMs });
    if (buckets.size > 5000) for (const [k, b] of buckets) if (b.reset < now) buckets.delete(k);
    return true;
  }
  bucket.count += 1;
  return bucket.count <= max;
}

export function clientKey(req: Request): string {
  return (req.headers.get("x-forwarded-for") ?? "local").split(",")[0].trim();
}
