import { BookOpenText, Bot, BrainCircuit, GraduationCap, Handshake, Leaf, Microscope, Shirt, type LucideIcon } from "lucide-react";
import type { ImageKey } from "./images";
import type { L } from "./site";

export type ResearchTheme = {
  id: string;
  icon: LucideIcon;
  title: L;
  short: string;
  body: string[];
  areas: string[];
  image?: ImageKey;
};

/**
 * Research themes describe the scope of each area. They deliberately avoid
 * naming projects, grants or results until those are supplied by the university.
 */
export const RESEARCH_THEMES: ResearchTheme[] = [
  {
    id: "faculty-research",
    icon: Microscope,
    title: { en: "Faculty Research", bn: "শিক্ষক গবেষণা" },
    short: "Department-led inquiry across the whole textile value chain.",
    body: [
      "Faculty research at BUTEX is organized around the university's departments, so that work on fibers and yarns, fabrics, coloration, apparel, chemistry, environment, machinery and management sits side by side.",
      "That breadth makes it possible to follow a question through the entire value chain, from the properties of a fiber to the performance, cost and footprint of the finished product.",
    ],
    areas: ["Materials and process engineering", "Product quality and performance", "Resource efficiency and cleaner production", "Operations, supply chain and compliance"],
    image: "labAnalysis",
  },
  {
    id: "student-research",
    icon: GraduationCap,
    title: { en: "Student Research", bn: "শিক্ষার্থী গবেষণা" },
    short: "Projects and theses grounded in real industrial problems.",
    body: [
      "Undergraduate and postgraduate students carry out project and thesis work under faculty supervision, often framed around problems encountered in mills and factories during industrial attachment.",
      "Student work is a natural route for new ideas to move between the laboratory and the production floor.",
    ],
    areas: ["Final-year projects and theses", "Laboratory-based investigations", "Industrial attachment case studies", "Competitions and student showcases"],
    image: "labStudents",
  },
  {
    id: "publications",
    icon: BookOpenText,
    title: { en: "Publications & Journals", bn: "প্রকাশনা ও জার্নাল" },
    short: "Journal articles, conference papers and theses.",
    body: [
      "Research outputs include articles in peer-reviewed journals, conference contributions and postgraduate theses. BUTEX has also hosted the International Conference on Textile Science and Engineering, bringing researchers and industry together on campus.",
    ],
    areas: ["Peer-reviewed journal articles", "Conference proceedings", "Postgraduate theses", "Departmental publication lists"],
    image: "library",
  },
  {
    id: "automation",
    icon: Bot,
    title: { en: "Textile Automation", bn: "টেক্সটাইল অটোমেশন" },
    short: "Sensing, control and robotics for spinning, weaving, dyeing and sewing.",
    body: [
      "Automation is reshaping every stage of textile production. Research in this area looks at how sensing, control systems and robotics can raise productivity and consistency while improving working conditions.",
    ],
    areas: ["Machine monitoring and control", "Robotics and material handling", "Automated inspection", "Retrofitting existing machinery"],
    image: "robotArm",
  },
  {
    id: "ai",
    icon: BrainCircuit,
    title: { en: "Artificial Intelligence in Textiles", bn: "টেক্সটাইলে কৃত্রিম বুদ্ধিমত্তা" },
    short: "Machine vision, prediction and optimization for quality and planning.",
    body: [
      "Data-driven methods open new possibilities for an industry that generates large volumes of process and quality data. Work in this theme applies machine learning to detect defects, predict properties and plan production.",
    ],
    areas: ["Fabric and garment defect detection", "Prediction of yarn and fabric properties", "Color matching and recipe prediction", "Demand, planning and scheduling models"],
    image: "spinningFloor",
  },
  {
    id: "sustainability",
    icon: Leaf,
    title: { en: "Sustainable Textile Technology", bn: "টেকসই টেক্সটাইল প্রযুক্তি" },
    short: "Water, energy, chemistry and circularity.",
    body: [
      "Textile processing is intensive in water, energy and chemicals. Research on sustainable technology seeks to reduce that footprint through cleaner processes, better treatment and reuse, and materials designed for circularity.",
    ],
    areas: ["Water-saving coloration and finishing", "Effluent treatment and reuse", "Recycled and bio-based fibers", "Life-cycle and footprint assessment"],
    image: "waterFilters",
  },
  {
    id: "smart-textiles",
    icon: Shirt,
    title: { en: "Smart Textiles", bn: "স্মার্ট টেক্সটাইল" },
    short: "Functional, electronic and responsive materials.",
    body: [
      "Smart and technical textiles extend what fabric can do: sensing, protecting, conducting or responding to the environment. This theme connects materials science with product design and electronics.",
    ],
    areas: ["Conductive and sensing fabrics", "Protective and medical textiles", "Functional coatings and finishes", "Wearable product development"],
    image: "threads",
  },
  {
    id: "industry",
    icon: Handshake,
    title: { en: "Industrial Collaboration", bn: "শিল্প সহযোগিতা" },
    short: "Joint projects, testing and training with industry.",
    body: [
      "BUTEX sits within Dhaka's Tejgaon industrial area and has long supplied engineers to Bangladesh's textile and ready-made garment sector. Collaboration with industry takes the form of industrial attachment, joint problem-solving, testing services and professional training.",
    ],
    areas: ["Industrial attachment and internships", "Joint research and consultancy", "Testing and technical services", "Executive and professional development"],
    image: "factoryFloor",
  },
];
