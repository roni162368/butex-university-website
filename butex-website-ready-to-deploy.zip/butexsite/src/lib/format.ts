const TZ = "Asia/Dhaka";

const longFmt = new Intl.DateTimeFormat("en-GB", { timeZone: TZ, day: "numeric", month: "long", year: "numeric" });
const shortFmt = new Intl.DateTimeFormat("en-GB", { timeZone: TZ, day: "2-digit", month: "short", year: "numeric" });
const keyFmt = new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" });
const timeFmt = new Intl.DateTimeFormat("en-GB", { timeZone: TZ, hour: "numeric", minute: "2-digit", hour12: true });
const partsFmt = new Intl.DateTimeFormat("en-GB", { timeZone: TZ, day: "2-digit", month: "short", year: "numeric", weekday: "short" });

const toDate = (d: Date | string) => (d instanceof Date ? d : new Date(d));

/** All dates are rendered in Bangladesh Standard Time so server and client output always match. */
export function fmtDate(d: Date | string, style: "long" | "short" = "long"): string {
  return (style === "long" ? longFmt : shortFmt).format(toDate(d));
}

export function fmtTime(d: Date | string): string {
  return timeFmt.format(toDate(d)).replace(/\s?(am|pm)/i, (m) => m.toUpperCase());
}

/** YYYY-MM-DD in Dhaka time. */
export function dateKey(d: Date | string): string {
  return keyFmt.format(toDate(d));
}

export function dateParts(d: Date | string): { day: string; month: string; year: string; weekday: string } {
  const out = { day: "", month: "", year: "", weekday: "" };
  for (const p of partsFmt.formatToParts(toDate(d))) {
    if (p.type === "day" || p.type === "month" || p.type === "year" || p.type === "weekday") out[p.type] = p.value;
  }
  return out;
}

/** True when the timestamp has a meaningful time-of-day (i.e. is not midnight in Dhaka). */
export function hasTime(d: Date | string): boolean {
  const t = toDate(d);
  return (t.getTime() + 6 * 3600_000) % 86_400_000 !== 0;
}

/** Split a stored multi-line value into trimmed, non-empty lines. */
export function lines(text: string | null | undefined): string[] {
  return (text ?? "")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
}

/** Parse "left | right" lines into pairs. */
export function pairs(text: string | null | undefined): { left: string; right: string }[] {
  return lines(text).map((l) => {
    const i = l.indexOf("|");
    return i === -1 ? { left: l, right: "" } : { left: l.slice(0, i).trim(), right: l.slice(i + 1).trim() };
  });
}

export function slugify(input: string): string {
  return (
    input
      .toLowerCase()
      .normalize("NFKD")
      .replace(/[^a-z0-9\s-]/g, "")
      .trim()
      .replace(/[\s-]+/g, "-")
      .slice(0, 80) || "item"
  );
}

export function fileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
