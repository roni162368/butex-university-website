/**
 * Minimal single-page PDF writer (no dependencies). Used to generate clearly
 * labeled placeholder attachments for sample notices and documents so that
 * every download link on the site resolves to a real file.
 */
const esc = (s: string) => s.replace(/[^\x20-\x7E]/g, "?").replace(/([\\()])/g, "\\$1");

function wrap(text: string, width: number): string[] {
  const out: string[] = [];
  let line = "";
  for (const word of text.split(/\s+/).filter(Boolean)) {
    if (line && (line + " " + word).length > width) {
      out.push(line);
      line = word;
    } else {
      line = line ? `${line} ${word}` : word;
    }
  }
  if (line) out.push(line);
  return out;
}

export function makePdf(title: string, paragraphs: string[]): Buffer {
  const ops: string[] = [];
  ops.push("0.039 0.106 0.212 rg 0 782 595 60 re f");
  ops.push("0.757 0.604 0.271 rg 0 779 595 3 re f");
  ops.push("BT /F2 13 Tf 1 1 1 rg 48 806 Td (Bangladesh University of Textiles \\(BUTEX\\)) Tj ET");
  ops.push("BT /F1 9 Tf 0.9 0.83 0.63 rg 48 791 Td (PLACEHOLDER DOCUMENT - NOT AN OFFICIAL PUBLICATION) Tj ET");

  let y = 728;
  for (const l of wrap(title, 50)) {
    ops.push(`BT /F2 18 Tf 0.039 0.106 0.212 rg 48 ${y} Td (${esc(l)}) Tj ET`);
    y -= 25;
  }
  y -= 12;
  for (const p of paragraphs) {
    for (const l of wrap(p, 94)) {
      if (y < 80) break;
      ops.push(`BT /F1 10.5 Tf 0.16 0.18 0.22 rg 48 ${y} Td (${esc(l)}) Tj ET`);
      y -= 16;
    }
    y -= 8;
  }
  ops.push("0.757 0.604 0.271 rg 48 62 499 0.8 re f");
  ops.push("BT /F1 8.5 Tf 0.4 0.43 0.5 rg 48 46 Td (92 Shaheed Tajuddin Ahmed Avenue, Tejgaon Industrial Area, Dhaka-1208, Bangladesh) Tj ET");

  const stream = ops.join("\n");
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
    `<< /Length ${Buffer.byteLength(stream, "latin1")} >>\nstream\n${stream}\nendstream`,
  ];

  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [];
  objects.forEach((o, i) => {
    offsets.push(Buffer.byteLength(pdf, "latin1"));
    pdf += `${i + 1} 0 obj\n${o}\nendobj\n`;
  });
  const xref = Buffer.byteLength(pdf, "latin1");
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  pdf += offsets.map((o) => `${String(o).padStart(10, "0")} 00000 n \n`).join("");
  pdf += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  return Buffer.from(pdf, "latin1");
}
