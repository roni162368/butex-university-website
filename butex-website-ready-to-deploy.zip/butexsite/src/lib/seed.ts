import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import * as s from "@/db/schema";
import { ACCOUNTS, DEMO_MODE, hashPassword } from "./auth";
import { slugify } from "./format";
import { makePdf } from "./pdf";
import {
  ADMISSION_SEED,
  CONTENT_SEED,
  DEPARTMENT_SEED,
  DOCUMENT_SEED,
  FACULTY_SEED,
  NEWS_SEED,
  NOTICE_SEED,
  STATS_SEED,
  eventSeed,
  relativeDate,
} from "./seed-data";

let state: Promise<boolean> | null = null;

/**
 * Idempotently populates an empty database with default content, sample
 * records and the demonstration accounts. Safe to call on every request:
 * the work runs once per server process, and a failure (for example when the
 * schema has not been pushed yet) is retried on the next call.
 */
export function ensureSeeded(): Promise<boolean> {
  if (!state) {
    state = seed().catch((err) => {
      console.error("[seed] skipped:", err instanceof Error ? err.message : err);
      state = null;
      return false;
    });
  }
  return state;
}

const PLACEHOLDER_PDF_NOTE = [
  "This file is a placeholder generated automatically so that the download link works during the demonstration of the website.",
  "It is not an official document of Bangladesh University of Textiles. An administrator can replace it with the real PDF from the admin dashboard.",
];

async function seed(): Promise<boolean> {
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(s.siteContent);

  if (n > 0) {
    // Add any content blocks introduced after the initial seed, and make sure an admin account exists.
    await db.insert(s.siteContent).values(CONTENT_SEED).onConflictDoNothing();
    const admins = await db.select({ id: s.users.id }).from(s.users).where(eq(s.users.identifier, ACCOUNTS.admin.identifier)).limit(1);
    if (admins.length === 0) {
      await db
        .insert(s.users)
        .values({ role: "admin", identifier: ACCOUNTS.admin.identifier, name: ACCOUNTS.admin.name, passwordHash: hashPassword(ACCOUNTS.admin.password), isDemo: DEMO_MODE })
        .onConflictDoNothing();
    }
    return true;
  }

  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(7412021)`);
    const [{ n: again }] = await tx.select({ n: sql<number>`count(*)::int` }).from(s.siteContent);
    if (again > 0) return;

    const attach = async (title: string, intro: string[]) => {
      const data = makePdf(title, [...intro, ...PLACEHOLDER_PDF_NOTE]);
      const name = `${slugify(title)}.pdf`;
      const [row] = await tx.insert(s.files).values({ name, mime: "application/pdf", size: data.length, data }).returning({ id: s.files.id });
      return { fileId: row.id, fileName: name };
    };

    await tx.insert(s.siteContent).values(CONTENT_SEED);
    await tx.insert(s.departments).values(DEPARTMENT_SEED);
    await tx.insert(s.faculty).values(FACULTY_SEED);
    await tx.insert(s.stats).values(STATS_SEED);

    for (const item of NOTICE_SEED) {
      const file = await attach(item.title, [item.summary]);
      await tx.insert(s.notices).values({
        title: item.title,
        category: item.category,
        summary: item.summary,
        body: item.body,
        publishedAt: relativeDate(item.days, 10),
        pinned: item.pinned,
        isSample: true,
        ...file,
      });
    }

    await tx.insert(s.news).values(
      NEWS_SEED.map((item) => ({
        slug: item.slug,
        title: item.title,
        excerpt: item.excerpt,
        body: item.body,
        image: item.image,
        publishedAt: relativeDate(item.days, 11),
        isSample: true,
      })),
    );

    await tx.insert(s.events).values(eventSeed());

    for (const item of ADMISSION_SEED) {
      const file = item.kind === "circular" ? await attach(item.title, [item.body]) : {};
      await tx.insert(s.admissionItems).values({ ...item, ...file });
    }

    for (const item of DOCUMENT_SEED) {
      const file = await attach(item.title, [item.description]);
      await tx.insert(s.documents).values({ ...item, ...file });
    }

    await tx.insert(s.users).values([
      { role: "admin", identifier: ACCOUNTS.admin.identifier, name: ACCOUNTS.admin.name, passwordHash: hashPassword(ACCOUNTS.admin.password), isDemo: DEMO_MODE },
      {
        role: "student",
        identifier: ACCOUNTS.student.identifier,
        name: ACCOUNTS.student.name,
        passwordHash: hashPassword(ACCOUNTS.student.password),
        departmentSlug: "yarn-engineering",
        isDemo: true,
      },
    ]);
  });

  return true;
}
