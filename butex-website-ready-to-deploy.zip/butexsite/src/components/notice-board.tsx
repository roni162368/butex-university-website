"use client";

import { useEffect, useMemo, useState } from "react";
import { Search, X } from "lucide-react";
import type { Notice } from "@/db/schema";
import { useLang } from "@/lib/client";
import { NOTICE_CATEGORIES } from "@/lib/site";
import { NoticeRow } from "./cards";
import { T } from "./t";
import { EmptyState, PlaceholderNote } from "./ui";

const PAGE_SIZE = 8;

export function NoticeBoard({ notices, initialCategory, initialQuery }: { notices: Notice[]; initialCategory: string; initialQuery: string }) {
  const lang = useLang();
  const [category, setCategory] = useState(NOTICE_CATEGORIES.some((c) => c.key === initialCategory) ? initialCategory : "all");
  const [query, setQuery] = useState(initialQuery);
  const [visible, setVisible] = useState(PAGE_SIZE);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: notices.length };
    for (const n of notices) map[n.category] = (map[n.category] ?? 0) + 1;
    return map;
  }, [notices]);

  const filtered = useMemo(() => {
    const words = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
    return notices.filter((n) => {
      if (category !== "all" && n.category !== category) return false;
      const hay = `${n.title} ${n.summary} ${n.fileName}`.toLowerCase();
      return words.every((w) => hay.includes(w));
    });
  }, [notices, category, query]);

  // Keep the address bar shareable without triggering a navigation.
  useEffect(() => {
    const params = new URLSearchParams();
    if (category !== "all") params.set("category", category);
    if (query.trim()) params.set("q", query.trim());
    const qs = params.toString();
    window.history.replaceState(null, "", qs ? `?${qs}` : window.location.pathname);
  }, [category, query]);

  const hasSamples = notices.some((n) => n.isSample);
  const shown = filtered.slice(0, visible);
  const reset = () => {
    setCategory("all");
    setQuery("");
    setVisible(PAGE_SIZE);
  };

  return (
    <div>
      <div className="rounded-2xl border border-line bg-surface p-4 sm:p-5">
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-accent" aria-hidden="true" />
          <input
            type="search"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setVisible(PAGE_SIZE);
            }}
            placeholder={lang === "bn" ? "নোটিশ খুঁজুন…" : "Search notices by title or keyword…"}
            aria-label="Search notices"
            className="field h-12 !rounded-full !pl-12 !pr-12 [&::-webkit-search-cancel-button]:hidden"
          />
          {query && (
            <button type="button" onClick={() => setQuery("")} aria-label="Clear search" className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full p-1.5 text-muted hover:bg-surface-2 hover:text-brand">
              <X className="size-4" aria-hidden="true" />
            </button>
          )}
        </div>
        <div role="group" aria-label="Filter by category" className="mt-4 flex flex-wrap gap-2">
          {[{ key: "all", en: "All notices", bn: "সকল নোটিশ" }, ...NOTICE_CATEGORIES].map((c) => {
            const on = category === c.key;
            return (
              <button
                key={c.key}
                type="button"
                aria-pressed={on}
                onClick={() => {
                  setCategory(c.key);
                  setVisible(PAGE_SIZE);
                }}
                className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm font-medium transition ${
                  on ? "border-navy-900 bg-navy-900 text-white dark:border-gold-500 dark:bg-gold-500 dark:text-navy-950" : "border-line bg-bg text-muted hover:border-gold-500 hover:text-brand"
                }`}
              >
                <T en={c.en} bn={c.bn} />
                <span className={`rounded-full px-1.5 text-[0.7rem] tabular-nums ${on ? "bg-white/20" : "bg-surface-2"}`}>{counts[c.key] ?? 0}</span>
              </button>
            );
          })}
        </div>
      </div>

      <p className="mt-6 text-sm text-muted" role="status" aria-live="polite">
        {filtered.length === 0 ? "No notices match your filters." : `Showing ${shown.length} of ${filtered.length} notice${filtered.length === 1 ? "" : "s"}`}
      </p>

      {filtered.length === 0 ? (
        <div className="mt-4">
          <EmptyState title="Nothing found">
            Try a different keyword or category.{" "}
            <button type="button" onClick={reset} className="font-semibold text-accent underline-offset-4 hover:underline">
              Clear all filters
            </button>
          </EmptyState>
        </div>
      ) : (
        <ul className="mt-2 divide-y divide-line border-y border-line">
          {shown.map((n) => (
            <NoticeRow key={n.id} notice={n} />
          ))}
        </ul>
      )}

      {filtered.length > visible && (
        <div className="mt-8 text-center">
          <button
            type="button"
            onClick={() => setVisible((v) => v + PAGE_SIZE)}
            className="rounded-full border border-line bg-surface px-6 py-3 text-sm font-semibold text-brand transition hover:border-gold-500 hover:text-accent"
          >
            Show more notices ({filtered.length - visible} remaining)
          </button>
        </div>
      )}

      {hasSamples && (
        <PlaceholderNote className="mt-10">
          Notices marked “Sample” are demonstration entries with placeholder PDF attachments. They are not official announcements and can be removed from the admin dashboard.
        </PlaceholderNote>
      )}
    </div>
  );
}
