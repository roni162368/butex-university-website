import type { ReactNode } from "react";

/**
 * Bilingual text. Both languages are rendered and CSS shows the active one
 * (see globals.css), so switching language is instant, flash-free and works in
 * server components. When no Bengali text is supplied the English is shown.
 */
export function T({ en, bn }: { en: ReactNode; bn?: ReactNode }) {
  if (bn === undefined || bn === null || bn === "") return <>{en}</>;
  return (
    <>
      <span data-l="en">{en}</span>
      <span data-l="bn" lang="bn">
        {bn}
      </span>
    </>
  );
}
