import Link from "next/link";
import { ExternalLink, Mail, MapPin, Phone, Printer } from "lucide-react";
import { getContent } from "@/lib/data";
import { lines } from "@/lib/format";
import { DEPARTMENT_INDEX, SITE } from "@/lib/site";
import { Emblem } from "./logo";
import { T } from "./t";
import { Container } from "./ui";

const LINKS = [
  { en: "Admission", bn: "ভর্তি", href: "/admission" },
  { en: "Academics", bn: "একাডেমিক্স", href: "/academics" },
  { en: "Research & Innovation", bn: "গবেষণা ও উদ্ভাবন", href: "/research" },
  { en: "Notice Board", bn: "নোটিশ বোর্ড", href: "/notices" },
  { en: "News", bn: "সংবাদ", href: "/news" },
  { en: "Events Calendar", bn: "ইভেন্ট ক্যালেন্ডার", href: "/events" },
  { en: "Faculty Directory", bn: "শিক্ষক নির্দেশিকা", href: "/faculty" },
  { en: "Campus Map", bn: "ক্যাম্পাস মানচিত্র", href: "/campus-life#map" },
  { en: "Student Portal", bn: "স্টুডেন্ট পোর্টাল", href: "/portal" },
  { en: "Contact", bn: "যোগাযোগ", href: "/contact" },
];

const SOCIAL: { key: string; label: string; path: string }[] = [
  { key: "social_facebook", label: "Facebook", path: "M13.5 21v-7.5h2.5l.5-3h-3V8.6c0-.9.3-1.6 1.6-1.6H17V4.3c-.4-.1-1.4-.3-2.5-.3-2.5 0-4 1.5-4 4.2v2.3H8v3h2.5V21h3z" },
  { key: "social_youtube", label: "YouTube", path: "M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4a2.5 2.5 0 0 0-1.8 1.8C2 8.8 2 12 2 12s0 3.2.4 4.8a2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8c.4-1.6.4-4.8.4-4.8s0-3.2-.4-4.8zM10 15V9l5.2 3-5.2 3z" },
  { key: "social_linkedin", label: "LinkedIn", path: "M6.5 8.5H3.6V20h2.9V8.5zM5 3.8a1.7 1.7 0 1 0 0 3.4 1.7 1.7 0 0 0 0-3.4zM20.4 20v-6.3c0-3.1-1.7-4.5-3.9-4.5-1.8 0-2.6 1-3 1.7V8.5h-2.9V20h2.9v-6.4c0-1.2.6-2.2 1.9-2.2s2 .9 2 2.2V20h3z" },
  { key: "social_x", label: "X", path: "M17.8 3h3l-6.6 7.6L22 21h-6.1l-4.8-6.2L5.6 21h-3l7.1-8.1L2.2 3h6.2l4.3 5.7L17.8 3zm-1 16.2h1.7L7.4 4.7H5.6l11.2 14.5z" },
];

const isHttpUrl = (value: string) => /^https?:\/\/\S+$/i.test(value);

export async function SiteFooter() {
  const content = await getContent();
  const address = lines(content.contact_address);
  const social = SOCIAL.filter((s) => isHttpUrl(content[s.key] ?? ""));
  const year = new Date().getFullYear();

  return (
    <footer className="no-print relative bg-navy-950 text-white/70">
      <div className="thread" aria-hidden="true" />
      <div className="weave">
        <Container className="grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-[1.25fr_0.8fr_1.15fr_1.2fr]">
          <div>
            <Link href="/" className="flex items-center gap-3">
              <Emblem className="size-12 shrink-0" />
              <span>
                <span className="block font-serif text-xl leading-tight text-white">
                  <T en={SITE.name} bn={SITE.nameBn} />
                </span>
                <span className="mt-1 block text-[0.65rem] font-semibold uppercase tracking-[0.24em] text-gold-400">BUTEX</span>
              </span>
            </Link>
            <address className="mt-6 space-y-3 text-sm not-italic leading-relaxed">
              <p className="flex gap-3">
                <MapPin className="mt-0.5 size-4 shrink-0 text-gold-400" aria-hidden="true" />
                <span>
                  {address.map((l) => (
                    <span key={l} className="block">
                      {l}
                    </span>
                  ))}
                </span>
              </p>
              {content.contact_phone && (
                <p className="flex gap-3">
                  <Phone className="mt-0.5 size-4 shrink-0 text-gold-400" aria-hidden="true" />
                  <a href={`tel:${content.contact_phone.replace(/[^\d+]/g, "")}`} className="transition hover:text-white">
                    {content.contact_phone}
                  </a>
                </p>
              )}
              {content.contact_fax && (
                <p className="flex gap-3">
                  <Printer className="mt-0.5 size-4 shrink-0 text-gold-400" aria-hidden="true" />
                  <span>Fax: {content.contact_fax}</span>
                </p>
              )}
              {content.contact_email && (
                <p className="flex gap-3">
                  <Mail className="mt-0.5 size-4 shrink-0 text-gold-400" aria-hidden="true" />
                  <a href={`mailto:${content.contact_email}`} className="transition hover:text-white">
                    {content.contact_email}
                  </a>
                </p>
              )}
            </address>
            {social.length > 0 && (
              <ul className="mt-6 flex gap-2" aria-label="Social media">
                {social.map((s) => (
                  <li key={s.key}>
                    <a
                      href={content[s.key]}
                      target="_blank"
                      rel="noopener noreferrer"
                      aria-label={`BUTEX on ${s.label}`}
                      className="inline-flex size-10 items-center justify-center rounded-full border border-white/15 text-white/80 transition hover:border-gold-400 hover:text-gold-300"
                    >
                      <svg viewBox="0 0 24 24" className="size-[1.05rem]" fill="currentColor" aria-hidden="true">
                        <path d={s.path} />
                      </svg>
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <nav aria-label="Important links">
            <h2 className="text-[0.72rem] font-semibold uppercase tracking-[0.22em] text-gold-400">
              <T en="Important links" bn="গুরুত্বপূর্ণ লিংক" />
            </h2>
            <ul className="mt-5 space-y-2.5 text-sm">
              {LINKS.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} className="transition hover:text-white">
                    <T en={l.en} bn={l.bn} />
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <nav aria-label="Departments">
            <h2 className="text-[0.72rem] font-semibold uppercase tracking-[0.22em] text-gold-400">
              <T en="Departments" bn="বিভাগসমূহ" />
            </h2>
            <ul className="mt-5 space-y-2.5 text-sm">
              {DEPARTMENT_INDEX.map((d) => (
                <li key={d.slug}>
                  <Link href={`/departments/${d.slug}`} className="transition hover:text-white">
                    <T en={d.name} bn={d.nameBn} />
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h2 className="text-[0.72rem] font-semibold uppercase tracking-[0.22em] text-gold-400">
              <T en="Find us" bn="অবস্থান" />
            </h2>
            <div className="mt-5 overflow-hidden rounded-xl border border-white/10 bg-navy-900">
              <iframe
                src={SITE.mapsEmbed}
                title="Map showing the location of Bangladesh University of Textiles"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="block h-48 w-full border-0 grayscale-[35%]"
              />
            </div>
            <a href={SITE.mapsLink} target="_blank" rel="noopener noreferrer" className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-gold-300 transition hover:text-white">
              <T en="Open in Google Maps" bn="গুগল ম্যাপে খুলুন" />
              <ExternalLink className="size-3.5" aria-hidden="true" />
            </a>
          </div>
        </Container>
      </div>

      <div className="border-t border-white/10">
        <Container className="flex flex-col gap-3 py-6 text-xs leading-relaxed md:flex-row md:items-center md:justify-between">
          <p>
            © {year} {SITE.name}. <T en="All rights reserved." bn="সর্বস্বত্ব সংরক্ষিত।" />
          </p>
          <ul className="flex flex-wrap gap-x-5 gap-y-1">
            <li>
              <Link href="/credits" className="transition hover:text-white">
                <T en="Image credits" bn="ছবির কৃতজ্ঞতা" />
              </Link>
            </li>
            <li>
              <Link href="/search" className="transition hover:text-white">
                <T en="Search" bn="অনুসন্ধান" />
              </Link>
            </li>
            <li>
              <Link href="/admin" className="transition hover:text-white">
                <T en="Staff sign-in" bn="স্টাফ সাইন-ইন" />
              </Link>
            </li>
            <li>
              <a href={SITE.officialUrl} target="_blank" rel="noopener noreferrer" className="transition hover:text-white">
                butex.edu.bd
              </a>
            </li>
          </ul>
        </Container>
        <Container className="pb-6 text-[0.7rem] leading-relaxed text-white/45">
          <p>
            <T
              en="Pre-launch build. Items labeled “Sample” are demonstration content, and sections marked as pending await verified information from the university."
              bn="প্রাক-উদ্বোধনী সংস্করণ। “নমুনা” চিহ্নিত বিষয়বস্তু প্রদর্শনের জন্য, এবং অপেক্ষমাণ অংশগুলো বিশ্ববিদ্যালয়ের যাচাইকৃত তথ্যের অপেক্ষায় আছে।"
            />
          </p>
        </Container>
      </div>
    </footer>
  );
}
