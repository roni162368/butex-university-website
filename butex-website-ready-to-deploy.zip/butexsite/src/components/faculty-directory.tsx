"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { Mail, Phone, Search, UserRound, X } from "lucide-react";
import type { FacultyMember } from "@/db/schema";
import { useLang } from "@/lib/client";
import type { DeptRef } from "@/lib/site";
import { Badge, EmptyState, PlaceholderNote } from "./ui";

export function FacultyDirectory({
  members,
  departments,
  initialDepartment,
  initialQuery,
}: {
  members: FacultyMember[];
  departments: DeptRef[];
  initialDepartment: string;
  initialQuery: string;
}) {
  const lang = useLang();
  const [query, setQuery] = useState(initialQuery);
  const [department, setDepartment] = useState(departments.some((d) => d.slug === initialDepartment) ? initialDepartment : "all");
  const [designation, setDesignation] = useState("all");

  const deptBySlug = useMemo(() => new Map(departments.map((d) => [d.slug, d])), [departments]);
  const designations = useMemo(() => [...new Set(members.map((m) => m.designation).filter(Boolean))].sort(), [members]);

  const filtered = useMemo(() => {
    const words = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
    return members.filter((m) => {
      if (department !== "all" && m.departmentSlug !== department) return false;
      if (designation !== "all" && m.designation !== designation) return false;
      const dept = deptBySlug.get(m.departmentSlug);
      const hay = `${m.name} ${m.designation} ${m.researchInterests} ${m.email} ${dept?.name ?? ""} ${dept?.code ?? ""}`.toLowerCase();
      return words.every((w) => hay.includes(w));
    });
  }, [members, query, department, designation, deptBySlug]);

  useEffect(() => {
    const params = new URLSearchParams();
    if (department !== "all") params.set("department", department);
    if (query.trim()) params.set("q", query.trim());
    const qs = params.toString();
    window.history.replaceState(null, "", qs ? `?${qs}` : window.location.pathname);
  }, [department, query]);

  const reset = () => {
    setQuery("");
    setDepartment("all");
    setDesignation("all");
  };
  const filtersActive = query.trim() !== "" || department !== "all" || designation !== "all";

  return (
    <div>
      <div className="grid gap-3 rounded-2xl border border-line bg-surface p-4 sm:p-5 md:grid-cols-[1.6fr_1fr_1fr]">
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-accent" aria-hidden="true" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={lang === "bn" ? "নাম, পদবি বা গবেষণা ক্ষেত্র…" : "Name, designation or research interest…"}
            aria-label="Search faculty"
            className="field h-12 !pl-12 [&::-webkit-search-cancel-button]:hidden"
          />
        </div>
        <label className="block">
          <span className="sr-only">Department</span>
          <select value={department} onChange={(e) => setDepartment(e.target.value)} className="field h-12">
            <option value="all">All departments</option>
            {departments.map((d) => (
              <option key={d.slug} value={d.slug}>
                {d.name} ({d.code})
              </option>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="sr-only">Designation</span>
          <select value={designation} onChange={(e) => setDesignation(e.target.value)} className="field h-12">
            <option value="all">All designations</option>
            {designations.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted" role="status" aria-live="polite">
          {filtered.length} {filtered.length === 1 ? "profile" : "profiles"} found
        </p>
        {filtersActive && (
          <button type="button" onClick={reset} className="inline-flex items-center gap-1.5 text-sm font-semibold text-accent hover:underline">
            <X className="size-4" aria-hidden="true" /> Clear filters
          </button>
        )}
      </div>

      {members.some((m) => m.isPlaceholder) && (
        <PlaceholderNote className="mt-4">
          Entries marked “Placeholder” are empty profile slots that keep the directory layout testable. Names, designations and contact details are added by each department; none are invented here.
        </PlaceholderNote>
      )}

      {filtered.length === 0 ? (
        <div className="mt-6">
          <EmptyState title="No profiles match your search.">Try a different name, or clear the department and designation filters.</EmptyState>
        </div>
      ) : (
        <ul className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((m) => {
            const dept = deptBySlug.get(m.departmentSlug);
            return (
              <li key={m.id} className="flex gap-4 rounded-2xl border border-line bg-surface p-5 transition hover:border-gold-500/60">
                <span className="flex size-14 shrink-0 items-center justify-center rounded-full bg-surface-2 text-muted">
                  <UserRound className="size-6" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-semibold leading-snug text-ink">{m.name}</h3>
                    {m.isPlaceholder && <Badge tone="sample">Placeholder</Badge>}
                  </div>
                  <p className="mt-0.5 text-sm text-muted">{m.designation}</p>
                  {dept && (
                    <Link href={`/departments/${dept.slug}`} className="mt-2 inline-block text-xs font-semibold uppercase tracking-[0.12em] text-accent hover:underline">
                      {dept.code} · {dept.name}
                    </Link>
                  )}
                  {m.researchInterests && <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted">{m.researchInterests}</p>}
                  {(m.email || m.phone) && (
                    <p className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm">
                      {m.email && (
                        <a href={`mailto:${m.email}`} className="inline-flex min-w-0 items-center gap-1.5 text-brand hover:text-accent">
                          <Mail className="size-4 shrink-0" aria-hidden="true" />
                          <span className="truncate">{m.email}</span>
                        </a>
                      )}
                      {m.phone && (
                        <a href={`tel:${m.phone.replace(/[^\d+]/g, "")}`} className="inline-flex items-center gap-1.5 text-brand hover:text-accent">
                          <Phone className="size-4" aria-hidden="true" />
                          {m.phone}
                        </a>
                      )}
                    </p>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
