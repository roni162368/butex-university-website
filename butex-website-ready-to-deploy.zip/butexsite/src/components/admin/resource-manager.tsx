"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent } from "react";
import { Eye, FileText, Loader2, Pencil, Plus, RefreshCw, Search, Trash2, Upload, X } from "lucide-react";
import { ApiError, api } from "@/lib/client";
import { fileSize, fmtDate, fmtTime } from "@/lib/format";
import { Badge } from "../ui";
import type { ColumnDef, FieldDef, ResourceDef } from "./config";

type Row = Record<string, unknown>;
type Notify = (kind: "success" | "error", text: string) => void;
type Editing = { mode: "create" | "edit" | "view"; row: Row };

const MAX_UPLOAD = 8 * 1024 * 1024;

const toLocalInput = (value: unknown): string => {
  if (!value) return "";
  const d = new Date(String(value));
  if (Number.isNaN(d.getTime())) return "";
  return new Date(d.getTime() - d.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
};

function Cell({ row, col }: { row: Row; col: ColumnDef }) {
  const value = row[col.key];
  switch (col.kind) {
    case "date":
      return value ? (
        <span className="whitespace-nowrap tabular-nums">
          {fmtDate(String(value), "short")} <span className="text-muted">{fmtTime(String(value))}</span>
        </span>
      ) : (
        <span className="text-muted">—</span>
      );
    case "bool":
      return value ? <Badge tone="sample">Yes</Badge> : <span className="text-muted">No</span>;
    case "badge": {
      const label = col.options?.find((o) => o.value === value)?.label ?? String(value ?? "");
      return label ? <Badge>{label}</Badge> : <span className="text-muted">—</span>;
    }
    case "file":
      return typeof value === "number" ? (
        <a href={`/api/files/${value}`} target="_blank" rel="noopener" className="inline-flex items-center gap-1.5 text-sm font-semibold text-accent hover:underline">
          <FileText className="size-4" aria-hidden="true" /> View
        </a>
      ) : (
        <span className="text-muted">—</span>
      );
    case "number":
      return value === null || value === undefined ? <span className="italic text-muted">Awaiting figure</span> : <span className="tabular-nums">{Number(value).toLocaleString("en-US")}</span>;
    default: {
      const text = String(value ?? "");
      return text ? <span className={`line-clamp-2 ${col.wide ? "font-medium text-ink" : ""}`}>{text}</span> : <span className="italic text-muted">Empty</span>;
    }
  }
}

export function ResourceManager({ def, token, onUnauthorized, notify }: { def: ResourceDef; token: string; onUnauthorized: () => void; notify: Notify }) {
  const [rows, setRows] = useState<Row[] | null>(null);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<Editing | null>(null);
  const [confirmId, setConfirmId] = useState<string | number | null>(null);
  const [deletingId, setDeletingId] = useState<string | number | null>(null);

  const handleError = useCallback(
    (err: unknown, fallback: string) => {
      if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
        onUnauthorized();
        return "";
      }
      return err instanceof Error ? err.message : fallback;
    },
    [onUnauthorized],
  );

  const [reload, setReload] = useState(0);

  useEffect(() => {
    let cancelled = false;
    api<{ rows: Row[] }>(`/api/admin/${def.key}`, { token })
      .then((data) => {
        if (cancelled) return;
        setRows(data.rows);
        setError("");
      })
      .catch((err) => {
        if (!cancelled) setError(handleError(err, "The records could not be loaded."));
      });
    return () => {
      cancelled = true;
    };
  }, [def.key, token, handleError, reload]);

  const filtered = useMemo(() => {
    if (!rows) return [];
    const words = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
    if (words.length === 0) return rows;
    return rows.filter((r) => {
      const hay = def.searchFields.map((f) => String(r[f] ?? "")).join(" ").toLowerCase();
      return words.every((w) => hay.includes(w));
    });
  }, [rows, query, def.searchFields]);

  const remove = async (id: string | number) => {
    setDeletingId(id);
    try {
      await api(`/api/admin/${def.key}/${id}`, { method: "DELETE", token });
      setRows((rs) => rs?.filter((r) => r[def.idField] !== id) ?? null);
      notify("success", `The ${def.singular} was deleted.`);
    } catch (err) {
      const msg = handleError(err, "The record could not be deleted.");
      if (msg) notify("error", msg);
    } finally {
      setDeletingId(null);
      setConfirmId(null);
    }
  };

  const onSaved = (row: Row, mode: "create" | "edit") => {
    setRows((rs) => {
      if (!rs) return rs;
      return mode === "create" ? [row, ...rs] : rs.map((r) => (r[def.idField] === row[def.idField] ? row : r));
    });
    setEditing(null);
    notify("success", mode === "create" ? `The ${def.singular} was created and is now live.` : "Your changes were saved and are now live.");
  };

  return (
    <div>
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="font-serif text-3xl text-brand">{def.label}</h1>
          <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-muted">{def.description}</p>
        </div>
        {def.create && (
          <button
            type="button"
            onClick={() => setEditing({ mode: "create", row: { ...def.defaults } })}
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-full bg-navy-900 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-navy-700 dark:bg-gold-500 dark:text-navy-950 dark:hover:bg-gold-400"
          >
            <Plus className="size-4" aria-hidden="true" /> New {def.singular}
          </button>
        )}
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <div className="relative min-w-0 flex-1 sm:max-w-sm">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted" aria-hidden="true" />
          <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder={`Filter ${def.label.toLowerCase()}…`} aria-label={`Filter ${def.label}`} className="field !pl-10" />
        </div>
        {rows && (
          <p className="text-sm text-muted" role="status">
            {filtered.length} of {rows.length}
          </p>
        )}
      </div>

      {error && (
        <div role="alert" className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-orange-700/30 bg-orange-500/10 px-4 py-3 text-sm text-orange-800 dark:text-orange-300">
          {error}
          <button
            type="button"
            onClick={() => {
              setError("");
              setReload((n) => n + 1);
            }}
            className="inline-flex items-center gap-1.5 font-semibold hover:underline"
          >
            <RefreshCw className="size-3.5" aria-hidden="true" /> Try again
          </button>
        </div>
      )}

      <div className="mt-4 overflow-x-auto rounded-2xl border border-line bg-surface">
        <table className="w-full min-w-[44rem] text-left text-sm">
          <caption className="sr-only">{def.label}</caption>
          <thead className="border-b border-line bg-surface-2 text-[0.68rem] uppercase tracking-[0.14em] text-muted">
            <tr>
              {def.columns.map((c) => (
                <th key={c.key} scope="col" className="px-4 py-3 font-semibold">
                  {c.label}
                </th>
              ))}
              <th scope="col" className="px-4 py-3 text-right font-semibold">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {!rows &&
              !error &&
              [0, 1, 2, 3, 4].map((i) => (
                <tr key={i}>
                  <td colSpan={def.columns.length + 1} className="px-4 py-4">
                    <div className="skeleton h-5 w-full" />
                  </td>
                </tr>
              ))}
            {rows && filtered.length === 0 && (
              <tr>
                <td colSpan={def.columns.length + 1} className="px-4 py-12 text-center text-muted">
                  {rows.length === 0 ? `No ${def.label.toLowerCase()} yet.${def.create ? ` Use “New ${def.singular}” to add the first one.` : ""}` : "Nothing matches your filter."}
                </td>
              </tr>
            )}
            {filtered.map((row) => {
              const id = row[def.idField] as string | number;
              const confirming = confirmId === id;
              return (
                <tr key={String(id)} className="align-top transition hover:bg-surface-2/60">
                  {def.columns.map((c) => (
                    <td key={c.key} className={`px-4 py-3.5 text-muted ${c.wide ? "min-w-[14rem]" : ""} ${c.key === "value" ? "max-w-xs" : ""}`}>
                      <Cell row={row} col={c} />
                    </td>
                  ))}
                  <td className="px-4 py-3 text-right">
                    {confirming ? (
                      <span className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => void remove(id)}
                          disabled={deletingId === id}
                          className="inline-flex items-center gap-1.5 rounded-full bg-red-700 px-3.5 py-1.5 text-xs font-semibold text-white transition hover:bg-red-800 disabled:opacity-70"
                        >
                          {deletingId === id && <Loader2 className="size-3.5 animate-spin" aria-hidden="true" />}
                          Delete {def.singular}
                        </button>
                        <button type="button" onClick={() => setConfirmId(null)} className="rounded-full border border-line px-3.5 py-1.5 text-xs font-semibold text-brand hover:border-gold-500">
                          Keep
                        </button>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => setEditing({ mode: def.edit ? "edit" : "view", row })}
                          aria-label={`${def.edit ? "Edit" : "View"} ${String(row[def.titleField] ?? def.singular)}`}
                          className="inline-flex items-center gap-1.5 rounded-full border border-line px-3.5 py-1.5 text-xs font-semibold text-brand transition hover:border-gold-500 hover:text-accent"
                        >
                          {def.edit ? <Pencil className="size-3.5" aria-hidden="true" /> : <Eye className="size-3.5" aria-hidden="true" />}
                          {def.edit ? "Edit" : "View"}
                        </button>
                        {def.remove && (
                          <button
                            type="button"
                            onClick={() => setConfirmId(id)}
                            aria-label={`Delete ${String(row[def.titleField] ?? def.singular)}`}
                            className="inline-flex size-8 items-center justify-center rounded-full text-muted transition hover:bg-red-600/10 hover:text-red-700 dark:hover:text-red-400"
                          >
                            <Trash2 className="size-4" aria-hidden="true" />
                          </button>
                        )}
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {editing && <Editor key={`${editing.mode}-${String(editing.row[def.idField] ?? "new")}`} def={def} editing={editing} token={token} onClose={() => setEditing(null)} onSaved={onSaved} handleError={handleError} />}
    </div>
  );
}

function Editor({
  def,
  editing,
  token,
  onClose,
  onSaved,
  handleError,
}: {
  def: ResourceDef;
  editing: Editing;
  token: string;
  onClose: () => void;
  onSaved: (row: Row, mode: "create" | "edit") => void;
  handleError: (err: unknown, fallback: string) => string;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const readOnly = editing.mode === "view";
  const [values, setValues] = useState<Row>(() => {
    const initial: Row = { ...editing.row };
    for (const f of def.fields) if (f.type === "datetime") initial[f.name] = toLocalInput(editing.row[f.name]);
    return initial;
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (dialog && !dialog.open) dialog.showModal();
  }, []);

  const set = (name: string, value: unknown) => {
    setValues((v) => ({ ...v, [name]: value }));
    if (errors[name]) setErrors((e) => ({ ...e, [name]: "" }));
  };

  const upload = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (file.type !== "application/pdf" && !/\.pdf$/i.test(file.name)) return setErrors((x) => ({ ...x, fileId: "Only PDF files can be uploaded." }));
    if (file.size > MAX_UPLOAD) return setErrors((x) => ({ ...x, fileId: `This file is ${fileSize(file.size)}. The limit is 8 MB.` }));
    setUploading(true);
    setErrors((x) => ({ ...x, fileId: "" }));
    try {
      const form = new FormData();
      form.append("file", file);
      const res = await api<{ file: { id: number; name: string } }>("/api/admin/upload", { token, form });
      setValues((v) => ({ ...v, fileId: res.file.id, fileName: res.file.name }));
    } catch (err) {
      setErrors((x) => ({ ...x, fileId: handleError(err, "The upload failed. Please try again.") }));
    } finally {
      setUploading(false);
    }
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (readOnly || saving || uploading) return;
    const payload: Row = {};
    const found: Record<string, string> = {};
    for (const f of def.fields) {
      const v = values[f.name];
      if (f.required && (v === "" || v === null || v === undefined)) found[f.name] = `Enter ${f.label.toLowerCase()}.`;
      if (f.type === "datetime") {
        if (v) payload[f.name] = new Date(String(v)).toISOString();
        else if (!f.required && editing.mode === "edit" && f.name === "endsAt") payload[f.name] = null;
      } else if (f.type === "number") {
        payload[f.name] = v === "" || v === null || v === undefined ? null : Number(v);
      } else if (f.type === "checkbox") {
        payload[f.name] = Boolean(v);
      } else if (f.type === "file") {
        payload.fileId = typeof values.fileId === "number" ? values.fileId : null;
        payload.fileName = String(values.fileName ?? "");
      } else {
        payload[f.name] = String(v ?? "");
      }
    }
    setErrors(found);
    setFormError("");
    if (Object.keys(found).length > 0) return;

    setSaving(true);
    try {
      const id = editing.row[def.idField];
      const res =
        editing.mode === "create"
          ? await api<{ row: Row }>(`/api/admin/${def.key}`, { token, json: payload })
          : await api<{ row: Row }>(`/api/admin/${def.key}/${String(id)}`, { method: "PATCH", token, json: payload });
      onSaved(res.row, editing.mode === "create" ? "create" : "edit");
    } catch (err) {
      if (err instanceof ApiError) setErrors(err.fields);
      setFormError(handleError(err, "The changes could not be saved."));
      setSaving(false);
    }
  };

  const title = editing.mode === "create" ? `New ${def.singular}` : readOnly ? `View ${def.singular}` : `Edit ${def.singular}`;
  const help = typeof editing.row.help === "string" ? editing.row.help : "";

  const renderField = (f: FieldDef) => {
    const id = `field-${f.name}`;
    const err = errors[f.name];
    const common = { id, disabled: readOnly, "aria-invalid": err ? ("true" as const) : undefined, "aria-describedby": err ? `${id}-error` : f.help ? `${id}-help` : undefined };

    if (f.type === "checkbox") {
      return (
        <div key={f.name} className="sm:col-span-2">
          <label className="flex items-start gap-3 text-sm font-medium text-ink">
            <input type="checkbox" checked={Boolean(values[f.name])} onChange={(e) => set(f.name, e.target.checked)} disabled={readOnly} className="mt-0.5 size-4 accent-[#c19a45]" />
            <span>
              {f.label}
              {f.help && <span className="mt-0.5 block text-xs font-normal text-muted">{f.help}</span>}
            </span>
          </label>
        </div>
      );
    }

    if (f.type === "file") {
      const fileId = typeof values.fileId === "number" ? values.fileId : null;
      return (
        <div key={f.name} className="sm:col-span-2">
          <p className="mb-1.5 text-sm font-semibold text-ink">{f.label}</p>
          <div className="flex flex-wrap items-center gap-3 rounded-xl border border-dashed border-line bg-bg p-4">
            {fileId ? (
              <>
                <FileText className="size-5 shrink-0 text-accent" aria-hidden="true" />
                <a href={`/api/files/${fileId}`} target="_blank" rel="noopener" className="min-w-0 flex-1 truncate text-sm font-semibold text-brand hover:text-accent hover:underline">
                  {String(values.fileName || "Attachment.pdf")}
                </a>
                <button type="button" onClick={() => setValues((v) => ({ ...v, fileId: null, fileName: "" }))} className="rounded-full border border-line px-3 py-1.5 text-xs font-semibold text-brand hover:border-red-600 hover:text-red-700">
                  Remove
                </button>
              </>
            ) : (
              <p className="min-w-0 flex-1 text-sm text-muted">No file attached.</p>
            )}
            <label className={`inline-flex cursor-pointer items-center gap-2 rounded-full border border-line bg-surface px-4 py-2 text-xs font-semibold text-brand transition hover:border-gold-500 hover:text-accent ${uploading ? "pointer-events-none opacity-70" : ""}`}>
              {uploading ? <Loader2 className="size-3.5 animate-spin" aria-hidden="true" /> : <Upload className="size-3.5" aria-hidden="true" />}
              {uploading ? "Uploading…" : fileId ? "Replace PDF" : "Upload PDF"}
              <input type="file" accept="application/pdf,.pdf" onChange={upload} className="sr-only" disabled={uploading} />
            </label>
          </div>
          {err ? (
            <p role="alert" className="mt-1.5 text-sm text-orange-700 dark:text-orange-400">
              {err}
            </p>
          ) : (
            f.help && <p className="mt-1.5 text-xs text-muted">{f.help}</p>
          )}
        </div>
      );
    }

    return (
      <div key={f.name} className={f.half ? "" : "sm:col-span-2"}>
        <label htmlFor={id} className="mb-1.5 block text-sm font-semibold text-ink">
          {f.label}
          {f.required && (
            <span className="text-orange-700" aria-hidden="true">
              {" "}
              *
            </span>
          )}
        </label>
        {f.type === "textarea" ? (
          <textarea {...common} rows={f.rows ?? 4} value={String(values[f.name] ?? "")} onChange={(e) => set(f.name, e.target.value)} className="field resize-y" />
        ) : f.type === "select" ? (
          <select {...common} value={String(values[f.name] ?? "")} onChange={(e) => set(f.name, e.target.value)} className="field">
            {f.options?.map((o) => (
              <option key={o.value} value={o.value}>
                {o.label}
              </option>
            ))}
          </select>
        ) : (
          <input
            {...common}
            type={f.type === "datetime" ? "datetime-local" : f.type === "number" ? "number" : "text"}
            min={f.type === "number" ? 0 : undefined}
            step={f.type === "number" ? 1 : undefined}
            value={String(values[f.name] ?? "")}
            onChange={(e) => set(f.name, e.target.value)}
            className="field"
          />
        )}
        {err ? (
          <p id={`${id}-error`} className="mt-1.5 text-sm text-orange-700 dark:text-orange-400">
            {err}
          </p>
        ) : (
          f.help && (
            <p id={`${id}-help`} className="mt-1.5 text-xs text-muted">
              {f.help}
            </p>
          )
        )}
      </div>
    );
  };

  return (
    <dialog
      ref={dialogRef}
      onClose={onClose}
      aria-labelledby="editor-title"
      className="m-0 mx-auto my-[4vh] max-h-[92vh] w-[calc(100%-1.5rem)] max-w-3xl overflow-hidden rounded-2xl border border-line bg-surface p-0 text-ink shadow-lift"
    >
      <form onSubmit={submit} noValidate className="flex max-h-[92vh] flex-col">
        <header className="flex items-start justify-between gap-4 border-b border-line px-6 py-4">
          <div className="min-w-0">
            <h2 id="editor-title" className="font-serif text-2xl text-brand">
              {title}
            </h2>
            {def.key === "content" && <p className="mt-0.5 truncate text-sm text-muted">{String(editing.row.label ?? "")}</p>}
          </div>
          <button type="button" onClick={onClose} aria-label="Close" className="rounded-full p-2 text-muted transition hover:bg-surface-2 hover:text-brand">
            <X className="size-5" aria-hidden="true" />
          </button>
        </header>

        <div className="grid gap-5 overflow-y-auto px-6 py-6 sm:grid-cols-2">
          {help && <p className="rounded-lg bg-surface-2 px-4 py-3 text-sm text-muted sm:col-span-2">{help}</p>}
          {def.fields.map(renderField)}
          {formError && (
            <p role="alert" className="rounded-lg border border-orange-700/30 bg-orange-500/10 px-4 py-3 text-sm text-orange-800 sm:col-span-2 dark:text-orange-300">
              {formError}
            </p>
          )}
        </div>

        <footer className="flex flex-wrap items-center justify-end gap-3 border-t border-line bg-bg px-6 py-4">
          <button type="button" onClick={onClose} className="rounded-full border border-line px-5 py-2.5 text-sm font-semibold text-brand transition hover:border-gold-500">
            {readOnly ? "Close" : "Cancel"}
          </button>
          {!readOnly && (
            <button
              type="submit"
              disabled={saving || uploading}
              className="inline-flex items-center gap-2 rounded-full bg-navy-900 px-6 py-2.5 text-sm font-semibold text-white transition hover:bg-navy-700 disabled:opacity-70 dark:bg-gold-500 dark:text-navy-950 dark:hover:bg-gold-400"
            >
              {saving && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
              {saving ? "Saving…" : editing.mode === "create" ? `Publish ${def.singular}` : "Save changes"}
            </button>
          )}
        </footer>
      </form>
    </dialog>
  );
}
