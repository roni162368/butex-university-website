import { BarChart3, BellRing, Building2, CalendarDays, FileText, FolderOpen, GraduationCap, Inbox, Newspaper, Users, type LucideIcon } from "lucide-react";
import { IMAGES } from "@/lib/images";
import { DEPARTMENT_INDEX, NOTICE_CATEGORIES } from "@/lib/site";

export type Option = { value: string; label: string };

export type FieldDef = {
  name: string;
  label: string;
  type: "text" | "textarea" | "select" | "checkbox" | "datetime" | "number" | "file";
  options?: Option[];
  required?: boolean;
  help?: string;
  rows?: number;
  half?: boolean;
};

export type ColumnDef = { key: string; label: string; kind?: "text" | "date" | "bool" | "badge" | "file" | "number"; options?: Option[]; wide?: boolean };

export type ResourceDef = {
  key: string;
  label: string;
  singular: string;
  icon: LucideIcon;
  description: string;
  idField: string;
  titleField: string;
  create: boolean;
  remove: boolean;
  edit: boolean;
  columns: ColumnDef[];
  fields: FieldDef[];
  defaults: Record<string, unknown>;
  searchFields: string[];
};

const categoryOptions: Option[] = NOTICE_CATEGORIES.map((c) => ({ value: c.key, label: c.en }));
const departmentOptions: Option[] = DEPARTMENT_INDEX.map((d) => ({ value: d.slug, label: `${d.name} (${d.code})` }));
const imageOptions: Option[] = [
  { value: "", label: "No image" },
  ...Object.values(IMAGES).map((i) => ({ value: i.src, label: `${i.butex ? "BUTEX" : "Stock"} · ${i.alt}` })),
];
const eventCategoryOptions: Option[] = ["university", "academic", "national", "cultural", "sports"].map((v) => ({ value: v, label: v[0].toUpperCase() + v.slice(1) }));
const kindOptions: Option[] = [
  { value: "circular", label: "Circular" },
  { value: "requirement", label: "Eligibility requirement" },
  { value: "guideline", label: "Application guideline" },
  { value: "date", label: "Important date" },
  { value: "result", label: "Result" },
  { value: "faq", label: "FAQ" },
];
const levelOptions: Option[] = [
  { value: "general", label: "All applicants" },
  { value: "undergraduate", label: "Undergraduate" },
  { value: "postgraduate", label: "Postgraduate" },
];

const sampleField: FieldDef = { name: "isSample", label: "Mark as sample (demonstration content)", type: "checkbox", help: "Sample records carry a “Sample” badge on the public site. Untick for official content." };
const pdfField: FieldDef = { name: "fileId", label: "PDF attachment", type: "file", help: "PDF only, up to 8 MB." };
const LIST_HELP = "One item per line.";

export const RESOURCE_DEFS: ResourceDef[] = [
  {
    key: "notices",
    label: "Notices",
    singular: "notice",
    icon: BellRing,
    description: "Publish notices with optional PDF attachments. They appear on the notice board, the homepage and the student portal.",
    idField: "id",
    titleField: "title",
    create: true,
    remove: true,
    edit: true,
    columns: [
      { key: "title", label: "Title", wide: true },
      { key: "category", label: "Category", kind: "badge", options: categoryOptions },
      { key: "publishedAt", label: "Published", kind: "date" },
      { key: "fileId", label: "PDF", kind: "file" },
      { key: "isSample", label: "Sample", kind: "bool" },
    ],
    fields: [
      { name: "title", label: "Title", type: "text", required: true },
      { name: "category", label: "Category", type: "select", options: categoryOptions, required: true, half: true },
      { name: "publishedAt", label: "Publication date", type: "datetime", half: true, help: "Shown on the site in Bangladesh time." },
      { name: "summary", label: "Summary", type: "textarea", rows: 2, help: "One or two sentences shown in lists." },
      { name: "body", label: "Full text", type: "textarea", rows: 6, help: "Separate paragraphs with a blank line." },
      pdfField,
      { name: "pinned", label: "Pin to the top of the notice board", type: "checkbox" },
      sampleField,
    ],
    defaults: { title: "", category: "academic", publishedAt: null, summary: "", body: "", fileId: null, fileName: "", pinned: false, isSample: false },
    searchFields: ["title", "summary", "category"],
  },
  {
    key: "news",
    label: "News",
    singular: "news story",
    icon: Newspaper,
    description: "Write news stories and announcements for the homepage and the news section.",
    idField: "id",
    titleField: "title",
    create: true,
    remove: true,
    edit: true,
    columns: [
      { key: "title", label: "Headline", wide: true },
      { key: "publishedAt", label: "Published", kind: "date" },
      { key: "isSample", label: "Sample", kind: "bool" },
    ],
    fields: [
      { name: "title", label: "Headline", type: "text", required: true },
      { name: "excerpt", label: "Summary", type: "textarea", rows: 2 },
      { name: "body", label: "Article text", type: "textarea", rows: 8, help: "Separate paragraphs with a blank line." },
      { name: "image", label: "Lead image", type: "select", options: imageOptions, half: true, help: "Choose from the site's image library." },
      { name: "publishedAt", label: "Publication date", type: "datetime", half: true },
      sampleField,
    ],
    defaults: { title: "", excerpt: "", body: "", image: "", publishedAt: null, isSample: false },
    searchFields: ["title", "excerpt"],
  },
  {
    key: "events",
    label: "Events",
    singular: "event",
    icon: CalendarDays,
    description: "Manage the events calendar shown on the homepage, the calendar page and the student portal.",
    idField: "id",
    titleField: "title",
    create: true,
    remove: true,
    edit: true,
    columns: [
      { key: "title", label: "Event", wide: true },
      { key: "category", label: "Category", kind: "badge", options: eventCategoryOptions },
      { key: "startsAt", label: "Starts", kind: "date" },
      { key: "isSample", label: "Sample", kind: "bool" },
    ],
    fields: [
      { name: "title", label: "Event title", type: "text", required: true },
      { name: "category", label: "Category", type: "select", options: eventCategoryOptions, half: true },
      { name: "location", label: "Location", type: "text", half: true },
      { name: "startsAt", label: "Starts", type: "datetime", required: true, half: true },
      { name: "endsAt", label: "Ends (optional)", type: "datetime", half: true },
      { name: "description", label: "Description", type: "textarea", rows: 3 },
      sampleField,
    ],
    defaults: { title: "", category: "university", location: "", startsAt: null, endsAt: null, description: "", isSample: false },
    searchFields: ["title", "location", "category"],
  },
  {
    key: "departments",
    label: "Departments",
    singular: "department",
    icon: Building2,
    description: "Update each department's overview, programs, curriculum, laboratories, research, publications and contact details.",
    idField: "id",
    titleField: "name",
    create: false,
    remove: false,
    edit: true,
    columns: [
      { key: "code", label: "Code", kind: "badge" },
      { key: "name", label: "Department", wide: true },
      { key: "updatedAt", label: "Last updated", kind: "date" },
    ],
    fields: [
      { name: "name", label: "Name (English)", type: "text", required: true, half: true },
      { name: "nameBn", label: "Name (Bengali)", type: "text", half: true },
      { name: "tagline", label: "Tagline", type: "text" },
      { name: "overview", label: "Overview", type: "textarea", rows: 4 },
      { name: "image", label: "Cover image", type: "select", options: imageOptions },
      { name: "programs", label: "Academic programs", type: "textarea", rows: 3, help: "One per line in the form: Level | Description" },
      { name: "curriculum", label: "Curriculum", type: "textarea", rows: 5, help: LIST_HELP },
      { name: "labs", label: "Laboratories and facilities", type: "textarea", rows: 4, help: LIST_HELP },
      { name: "research", label: "Research activities", type: "textarea", rows: 4, help: LIST_HELP },
      { name: "publications", label: "Publications", type: "textarea", rows: 5, help: "One full citation per line." },
      { name: "office", label: "Office location", type: "text" },
      { name: "email", label: "Email", type: "text", half: true },
      { name: "phone", label: "Phone", type: "text", half: true },
    ],
    defaults: {},
    searchFields: ["name", "code"],
  },
  {
    key: "faculty",
    label: "Faculty",
    singular: "faculty profile",
    icon: Users,
    description: "Maintain the faculty directory. Replace placeholder slots with confirmed profiles.",
    idField: "id",
    titleField: "name",
    create: true,
    remove: true,
    edit: true,
    columns: [
      { key: "name", label: "Name", wide: true },
      { key: "designation", label: "Designation" },
      { key: "departmentSlug", label: "Department", kind: "badge", options: DEPARTMENT_INDEX.map((d) => ({ value: d.slug, label: d.code })) },
      { key: "isPlaceholder", label: "Placeholder", kind: "bool" },
    ],
    fields: [
      { name: "name", label: "Full name", type: "text", required: true, half: true },
      { name: "designation", label: "Designation", type: "text", half: true },
      { name: "departmentSlug", label: "Department", type: "select", options: departmentOptions, required: true },
      { name: "email", label: "Email", type: "text", half: true },
      { name: "phone", label: "Phone", type: "text", half: true },
      { name: "researchInterests", label: "Research interests", type: "textarea", rows: 3 },
      { name: "sortOrder", label: "Display order", type: "number", half: true, help: "Lower numbers appear first within a department." },
      { name: "isPlaceholder", label: "This is a placeholder slot, not a confirmed profile", type: "checkbox" },
    ],
    defaults: { name: "", designation: "", departmentSlug: DEPARTMENT_INDEX[0].slug, email: "", phone: "", researchInterests: "", sortOrder: 10, isPlaceholder: false },
    searchFields: ["name", "designation", "departmentSlug", "email"],
  },
  {
    key: "admission",
    label: "Admission",
    singular: "admission entry",
    icon: GraduationCap,
    description: "Manage circulars, eligibility requirements, application guidelines, important dates, results and FAQs on the Admission page.",
    idField: "id",
    titleField: "title",
    create: true,
    remove: true,
    edit: true,
    columns: [
      { key: "title", label: "Title", wide: true },
      { key: "kind", label: "Type", kind: "badge", options: kindOptions },
      { key: "level", label: "Level", kind: "badge", options: levelOptions },
      { key: "dateText", label: "Date" },
      { key: "fileId", label: "PDF", kind: "file" },
    ],
    fields: [
      { name: "kind", label: "Type", type: "select", options: kindOptions, required: true, half: true },
      { name: "level", label: "Level", type: "select", options: levelOptions, half: true },
      { name: "title", label: "Title or question", type: "text", required: true },
      { name: "body", label: "Details or answer", type: "textarea", rows: 4 },
      { name: "dateText", label: "Date", type: "text", half: true, help: "Free text, for example “12 March 2027” or “To be announced”." },
      { name: "sortOrder", label: "Display order", type: "number", half: true },
      pdfField,
      sampleField,
    ],
    defaults: { kind: "circular", level: "undergraduate", title: "", body: "", dateText: "", sortOrder: 100, fileId: null, fileName: "", isSample: false },
    searchFields: ["title", "kind", "level"],
  },
  {
    key: "documents",
    label: "Documents",
    singular: "document",
    icon: FolderOpen,
    description: "Upload downloadable academic documents: calendars, regulations, syllabi and forms.",
    idField: "id",
    titleField: "title",
    create: true,
    remove: true,
    edit: true,
    columns: [
      { key: "title", label: "Title", wide: true },
      { key: "category", label: "Category", kind: "badge" },
      { key: "fileId", label: "PDF", kind: "file" },
      { key: "isSample", label: "Sample", kind: "bool" },
    ],
    fields: [
      { name: "title", label: "Title", type: "text", required: true },
      { name: "category", label: "Category", type: "text", half: true, help: "For example: Calendar, Regulations, Syllabus, Forms." },
      { name: "sortOrder", label: "Display order", type: "number", half: true },
      { name: "description", label: "Description", type: "textarea", rows: 2 },
      pdfField,
      sampleField,
    ],
    defaults: { title: "", category: "General", sortOrder: 100, description: "", fileId: null, fileName: "", isSample: false },
    searchFields: ["title", "category"],
  },
  {
    key: "content",
    label: "Site content",
    singular: "content block",
    icon: FileText,
    description: "Edit the text blocks used across the site: homepage introduction, history, mission and vision, leadership, the Vice Chancellor's message, contact details and social links.",
    idField: "key",
    titleField: "label",
    create: false,
    remove: false,
    edit: true,
    columns: [
      { key: "label", label: "Block", wide: true },
      { key: "section", label: "Section", kind: "badge" },
      { key: "value", label: "Current value" },
    ],
    fields: [{ name: "value", label: "Content", type: "textarea", rows: 10 }],
    defaults: {},
    searchFields: ["label", "section", "value"],
  },
  {
    key: "stats",
    label: "Statistics",
    singular: "statistic",
    icon: BarChart3,
    description: "Set the “University at a glance” figures. Leave a value empty to show an “awaiting verified figure” placeholder instead of a number.",
    idField: "id",
    titleField: "label",
    create: false,
    remove: false,
    edit: true,
    columns: [
      { key: "label", label: "Statistic", wide: true },
      { key: "value", label: "Value", kind: "number" },
      { key: "suffix", label: "Suffix" },
    ],
    fields: [
      { name: "label", label: "Label (English)", type: "text", required: true, half: true },
      { name: "labelBn", label: "Label (Bengali)", type: "text", half: true },
      { name: "value", label: "Verified value", type: "number", half: true, help: "Leave empty until the figure has been verified." },
      { name: "suffix", label: "Suffix", type: "text", half: true, help: "Optional, for example “+”." },
    ],
    defaults: {},
    searchFields: ["label"],
  },
  {
    key: "messages",
    label: "Messages",
    singular: "message",
    icon: Inbox,
    description: "Messages submitted through the public contact form.",
    idField: "id",
    titleField: "subject",
    create: false,
    remove: true,
    edit: false,
    columns: [
      { key: "name", label: "From" },
      { key: "email", label: "Email" },
      { key: "subject", label: "Subject", wide: true },
      { key: "createdAt", label: "Received", kind: "date" },
    ],
    fields: [
      { name: "name", label: "From", type: "text", half: true },
      { name: "email", label: "Email", type: "text", half: true },
      { name: "subject", label: "Subject", type: "text" },
      { name: "message", label: "Message", type: "textarea", rows: 8 },
    ],
    defaults: {},
    searchFields: ["name", "email", "subject", "message"],
  },
];
