"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { CheckCircle2, ExternalLink, FlaskConical, LayoutDashboard, Loader2, LogOut, RefreshCw, TriangleAlert } from "lucide-react";
import { ApiError, api, setStoredToken, useStoredToken } from "@/lib/client";
import { fmtDate } from "@/lib/format";
import { LoginPanel, type SessionUser } from "../login-panel";
import { Emblem } from "../logo";
import { ThemeToggle } from "../prefs-controls";
import { RESOURCE_DEFS } from "./config";
import { ResourceManager } from "./resource-manager";

const TOKEN_KEY = "butex-admin-token";

type Overview = {
  counts: Record<string, number>;
  recentMessages: { id: number; name: string; email: string; subject: string; message: string; createdAt: string }[];
  demoMode: boolean;
};
type Toast = { kind: "success" | "error"; text: string; id: number };

export function AdminApp({ demo }: { demo: { identifier: string; password: string } | null }) {
  const token = useStoredToken(TOKEN_KEY);
  const [user, setUser] = useState<SessionUser | null>(null);
  const [section, setSection] = useState("overview");
  const [toast, setToast] = useState<Toast | null>(null);

  const signOutLocal = useCallback(() => {
    setStoredToken(TOKEN_KEY, null);
    setUser(null);
  }, []);

  // A token restored from storage is verified with the server before the dashboard is shown.
  useEffect(() => {
    if (!token || user) return;
    let cancelled = false;
    api<{ user: SessionUser }>("/api/auth/session", { token })
      .then((res) => {
        if (cancelled) return;
        if (res.user.role === "admin") setUser(res.user);
        else setStoredToken(TOKEN_KEY, null);
      })
      .catch(() => {
        if (!cancelled) setStoredToken(TOKEN_KEY, null);
      });
    return () => {
      cancelled = true;
    };
  }, [token, user]);

  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(null), 4500);
    return () => window.clearTimeout(t);
  }, [toast]);

  const notify = useCallback((kind: "success" | "error", text: string) => setToast({ kind, text, id: Date.now() }), []);
  const onUnauthorized = useCallback(() => {
    signOutLocal();
  }, [signOutLocal]);

  const signOut = async () => {
    const t = token;
    signOutLocal();
    if (t) await api("/api/auth/session", { method: "DELETE", token: t }).catch(() => undefined);
  };

  if (token === undefined || (token && !user)) {
    return (
      <div className="flex min-h-screen items-center justify-center" role="status" aria-label="Loading">
        <Loader2 className="size-8 animate-spin text-accent" aria-hidden="true" />
      </div>
    );
  }

  if (!token || !user) {
    return (
      <LoginPanel
        role="admin"
        title="Admin Dashboard"
        tagline="Publish notices, update news and keep every part of the university website current."
        features={["Publish notices", "Upload PDF attachments", "Update news and events", "Manage departments", "Maintain faculty profiles", "Edit admission information"]}
        idLabel="Email"
        idPlaceholder="name@butex.edu.bd"
        idType="email"
        demo={demo}
        onSuccess={(t, u) => {
          setUser(u);
          setStoredToken(TOKEN_KEY, t);
        }}
      />
    );
  }

  const def = RESOURCE_DEFS.find((d) => d.key === section);
  const navItems = [{ key: "overview", label: "Overview", icon: LayoutDashboard }, ...RESOURCE_DEFS.map((d) => ({ key: d.key, label: d.label, icon: d.icon }))];

  return (
    <div className="min-h-screen bg-bg lg:grid lg:grid-cols-[16.5rem_1fr]">
      <aside className="hidden bg-navy-950 text-white lg:sticky lg:top-0 lg:flex lg:h-screen lg:flex-col">
        <div className="flex items-center gap-3 border-b border-white/10 px-6 py-5">
          <Emblem className="size-10 shrink-0" />
          <div>
            <p className="font-serif text-lg leading-tight">BUTEX Admin</p>
            <p className="text-[0.6rem] font-semibold uppercase tracking-[0.22em] text-gold-400">Content dashboard</p>
          </div>
        </div>
        <nav aria-label="Admin sections" className="flex-1 space-y-0.5 overflow-y-auto p-3">
          {navItems.map((item) => (
            <button
              key={item.key}
              type="button"
              onClick={() => setSection(item.key)}
              aria-current={section === item.key ? "page" : undefined}
              className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition ${
                section === item.key ? "bg-gold-500 text-navy-950" : "text-white/75 hover:bg-white/10 hover:text-white"
              }`}
            >
              <item.icon className="size-4 shrink-0" aria-hidden="true" />
              {item.label}
            </button>
          ))}
        </nav>
        <div className="border-t border-white/10 p-4 text-xs text-white/60">
          <p className="truncate font-semibold text-white">{user.name}</p>
          <p className="truncate">{user.identifier}</p>
        </div>
      </aside>

      <div className="min-w-0">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-line bg-surface/95 px-4 backdrop-blur sm:px-8">
          <div className="flex min-w-0 items-center gap-3 lg:hidden">
            <Emblem className="size-9 shrink-0" />
            <label className="min-w-0">
              <span className="sr-only">Section</span>
              <select value={section} onChange={(e) => setSection(e.target.value)} className="field !py-2 font-semibold">
                {navItems.map((item) => (
                  <option key={item.key} value={item.key}>
                    {item.label}
                  </option>
                ))}
              </select>
            </label>
          </div>
          <p className="hidden text-sm text-muted lg:block">Changes are published to the public website immediately.</p>
          <div className="flex shrink-0 items-center gap-2">
            <ThemeToggle className="inline-flex size-9 items-center justify-center rounded-full border border-line text-brand transition hover:border-gold-500" />
            <Link href="/" target="_blank" className="hidden items-center gap-1.5 rounded-full border border-line px-4 py-2 text-xs font-semibold text-brand transition hover:border-gold-500 hover:text-accent sm:inline-flex">
              View website <ExternalLink className="size-3" aria-hidden="true" />
            </Link>
            <button type="button" onClick={signOut} className="inline-flex items-center gap-1.5 rounded-full bg-navy-900 px-4 py-2 text-xs font-semibold text-white transition hover:bg-navy-700 dark:bg-surface-2 dark:text-ink">
              <LogOut className="size-3.5" aria-hidden="true" /> Sign out
            </button>
          </div>
        </header>

        <main id="main" className="mx-auto max-w-6xl px-4 py-8 sm:px-8 lg:py-10">
          {def ? (
            <ResourceManager key={def.key} def={def} token={token} onUnauthorized={onUnauthorized} notify={notify} />
          ) : (
            <OverviewPanel token={token} user={user} onUnauthorized={onUnauthorized} go={setSection} />
          )}
        </main>
      </div>

      <div aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-6 z-[60] flex justify-center px-4">
        {toast && (
          <div
            key={toast.id}
            role="status"
            className={`pointer-events-auto flex max-w-lg animate-fade-up items-center gap-3 rounded-full px-5 py-3 text-sm font-medium shadow-lift ${
              toast.kind === "success" ? "bg-navy-900 text-white" : "bg-red-700 text-white"
            }`}
          >
            {toast.kind === "success" ? <CheckCircle2 className="size-4 shrink-0 text-gold-300" aria-hidden="true" /> : <TriangleAlert className="size-4 shrink-0" aria-hidden="true" />}
            {toast.text}
          </div>
        )}
      </div>
    </div>
  );
}

function OverviewPanel({ token, user, onUnauthorized, go }: { token: string; user: SessionUser; onUnauthorized: () => void; go: (section: string) => void }) {
  const [data, setData] = useState<Overview | null>(null);
  const [error, setError] = useState("");

  const [reload, setReload] = useState(0);

  useEffect(() => {
    let cancelled = false;
    api<Overview>("/api/admin/overview", { token })
      .then((fresh) => {
        if (cancelled) return;
        setData(fresh);
        setError("");
      })
      .catch((err) => {
        if (cancelled) return;
        if (err instanceof ApiError && (err.status === 401 || err.status === 403)) onUnauthorized();
        else setError(err instanceof Error ? err.message : "The overview could not be loaded.");
      });
    return () => {
      cancelled = true;
    };
  }, [token, onUnauthorized, reload]);

  return (
    <div>
      <h1 className="font-serif text-3xl text-brand">Welcome, {user.name}</h1>
      <p className="mt-1.5 text-muted">Choose a section to update the public website.</p>

      {data?.demoMode && (
        <div role="note" className="mt-6 flex gap-3 rounded-xl border border-dashed border-gold-600/50 bg-gold-500/[0.07] px-4 py-3 text-sm leading-relaxed text-muted">
          <FlaskConical className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
          <p>
            <strong className="text-ink">Demonstration mode.</strong> You are signed in with the built-in demo administrator, whose credentials are shown on the sign-in page. Before launch, set the{" "}
            <code className="rounded bg-surface-2 px-1">ADMIN_EMAIL</code> and <code className="rounded bg-surface-2 px-1">ADMIN_PASSWORD</code> environment variables or connect the university&apos;s single sign-on.
          </p>
        </div>
      )}

      {error && (
        <div role="alert" className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-orange-700/30 bg-orange-500/10 px-4 py-3 text-sm text-orange-800 dark:text-orange-300">
          {error}
          <button
            type="button"
            onClick={() => {
              setError("");
              setReload((n) => n + 1);
            }}
            className="inline-flex items-center gap-1.5 font-semibold hover:underline"
          >
            <RefreshCw className="size-3.5" aria-hidden="true" /> Try again
          </button>
        </div>
      )}

      <ul className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {RESOURCE_DEFS.filter((d) => d.key !== "content" && d.key !== "stats").map((d) => (
          <li key={d.key}>
            <button type="button" onClick={() => go(d.key)} className="flex h-full w-full flex-col rounded-2xl border border-line bg-surface p-5 text-left transition hover:border-gold-500/60 hover:shadow-soft">
              <d.icon className="size-5 text-accent" aria-hidden="true" />
              <span className="mt-4 block font-serif text-4xl leading-none text-brand">{data ? (data.counts[d.key] ?? 0) : <span className="skeleton inline-block h-9 w-12 align-middle" />}</span>
              <span className="mt-2 block text-sm font-medium text-ink">{d.label}</span>
            </button>
          </li>
        ))}
      </ul>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <section className="rounded-2xl border border-line bg-surface">
          <header className="flex items-center justify-between border-b border-line px-6 py-4">
            <h2 className="font-serif text-xl text-brand">Recent messages</h2>
            <button type="button" onClick={() => go("messages")} className="text-sm font-semibold text-accent hover:underline">
              View all
            </button>
          </header>
          <div className="p-6">
            {!data && !error && <div className="skeleton h-24" />}
            {data && data.recentMessages.length === 0 && <p className="text-sm text-muted">No messages yet. Submissions from the Contact page will appear here.</p>}
            {data && data.recentMessages.length > 0 && (
              <ul className="divide-y divide-line">
                {data.recentMessages.map((m) => (
                  <li key={m.id} className="py-3 first:pt-0 last:pb-0">
                    <p className="flex flex-wrap items-baseline justify-between gap-2">
                      <span className="font-semibold text-ink">{m.name}</span>
                      <span className="text-xs text-muted">{fmtDate(m.createdAt, "short")}</span>
                    </p>
                    <p className="text-sm text-muted">{m.subject || "No subject"}</p>
                    <p className="mt-1 line-clamp-2 text-sm text-muted">{m.message}</p>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>

        <section className="rounded-2xl border border-line bg-surface">
          <header className="border-b border-line px-6 py-4">
            <h2 className="font-serif text-xl text-brand">Site-wide content</h2>
          </header>
          <ul className="divide-y divide-line">
            {RESOURCE_DEFS.filter((d) => d.key === "content" || d.key === "stats").map((d) => (
              <li key={d.key}>
                <button type="button" onClick={() => go(d.key)} className="flex w-full items-start gap-4 px-6 py-5 text-left transition hover:bg-surface-2">
                  <d.icon className="mt-0.5 size-5 shrink-0 text-accent" aria-hidden="true" />
                  <span>
                    <span className="block font-semibold text-ink">{d.label}</span>
                    <span className="mt-0.5 block text-sm leading-relaxed text-muted">{d.description}</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
