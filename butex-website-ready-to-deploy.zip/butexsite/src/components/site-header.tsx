"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { ChevronDown, GraduationCap, LogIn, Menu, Search, X } from "lucide-react";
import { NAV, SITE } from "@/lib/site";
import { Emblem } from "./logo";
import { LanguageToggle, TextSizeToggle, ThemeToggle } from "./prefs-controls";
import { SearchDialog } from "./search-dialog";
import { T } from "./t";
import { Container } from "./ui";

const UTILITY_LINKS = [
  { en: "Faculty Directory", bn: "শিক্ষক নির্দেশিকা", href: "/faculty" },
  { en: "News", bn: "সংবাদ", href: "/news" },
  { en: "Events", bn: "ইভেন্ট", href: "/events" },
  { en: "Academic Documents", bn: "একাডেমিক নথিপত্র", href: "/academics#documents" },
];

function isActive(pathname: string, href: string) {
  return href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);
}

export function SiteHeader({ announcement = "" }: { announcement?: string }) {
  const pathname = usePathname();
  // The menu remembers the route it was opened on, so navigating away closes it without an effect.
  const [menuPath, setMenuPath] = useState<string | null>(null);
  const menuOpen = menuPath === pathname;
  const closeMenu = () => setMenuPath(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [stuck, setStuck] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
      if (e.key === "Escape") setMenuPath(null);
    };
    const onScroll = () => setStuck(window.scrollY > 150);
    onScroll();
    window.addEventListener("keydown", onKey);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (menuOpen) root.dataset.lock = "1";
    else delete root.dataset.lock;
    return () => {
      delete root.dataset.lock;
    };
  }, [menuOpen]);

  return (
    <>
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-md focus:bg-gold-500 focus:px-4 focus:py-2 focus:text-sm focus:font-semibold focus:text-navy-950"
      >
        <T en="Skip to main content" bn="মূল বিষয়বস্তুতে যান" />
      </a>

      {announcement && (
        <div role="status" className="bg-gold-500 px-4 py-2 text-center text-sm font-medium text-navy-950">
          {announcement}
        </div>
      )}

      {/* Utility bar */}
      <div className="no-print bg-navy-950 text-xs text-white/75">
        <Container className="flex h-10 items-center justify-between gap-4">
          <nav aria-label="Quick links" className="hidden items-center gap-6 md:flex">
            {UTILITY_LINKS.map((l) => (
              <Link key={l.href} href={l.href} className="transition hover:text-gold-300">
                <T en={l.en} bn={l.bn} />
              </Link>
            ))}
          </nav>
          <p className="truncate md:hidden">
            <T en="Tejgaon, Dhaka" bn="তেজগাঁও, ঢাকা" />
          </p>
          <div className="flex items-center gap-1.5">
            <TextSizeToggle />
            <ThemeToggle />
            <LanguageToggle />
            <Link
              href="/portal"
              className="ml-1.5 hidden items-center gap-1.5 rounded-full border border-white/20 px-3 py-1 font-semibold text-white transition hover:border-gold-400 hover:text-gold-300 sm:inline-flex"
            >
              <LogIn className="size-3.5" aria-hidden="true" />
              <T en="Student Portal" bn="স্টুডেন্ট পোর্টাল" />
            </Link>
          </div>
        </Container>
      </div>

      {/* Brand row (sticky on small screens) */}
      <header className="sticky top-0 z-40 border-b border-line bg-surface/95 backdrop-blur lg:static lg:border-b-0">
        <Container className="flex h-[4.5rem] items-center justify-between gap-4 lg:h-[6.25rem]">
          <Link href="/" className="flex min-w-0 items-center gap-3 lg:gap-4" aria-label={`${SITE.name} — home`}>
            <Emblem className="size-11 shrink-0 lg:size-14" />
            <span className="min-w-0">
              <span className="block font-serif text-[0.98rem] leading-[1.15] text-brand sm:truncate sm:text-xl sm:leading-tight lg:text-[1.7rem]">
                <T en={SITE.name} bn={SITE.nameBn} />
              </span>
              <span className="mt-1 hidden truncate text-[0.6rem] font-semibold uppercase tracking-[0.24em] text-accent sm:block lg:text-[0.7rem]">
                <T en="BUTEX · Tejgaon, Dhaka" bn="বুটেক্স · তেজগাঁও, ঢাকা" />
              </span>
            </span>
          </Link>

          <div className="flex shrink-0 items-center gap-2 lg:gap-3">
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="hidden w-64 items-center gap-3 rounded-full border border-line bg-bg px-4 py-2.5 text-sm text-muted transition hover:border-gold-500 hover:text-brand lg:flex xl:w-72"
            >
              <Search className="size-4 text-accent" aria-hidden="true" />
              <span className="flex-1 text-left">
                <T en="Search BUTEX" bn="বুটেক্স অনুসন্ধান" />
              </span>
              <kbd className="rounded border border-line bg-surface px-1.5 py-0.5 font-sans text-[0.65rem] text-muted">Ctrl K</kbd>
            </button>
            <Link
              href="/admission"
              className="hidden items-center gap-2 rounded-full bg-gold-500 px-5 py-2.5 text-sm font-semibold text-navy-950 shadow-[0_10px_26px_-12px_rgba(193,154,69,0.9)] transition hover:bg-gold-400 sm:inline-flex"
            >
              <GraduationCap className="size-4" aria-hidden="true" />
              <T en="Admission Info" bn="ভর্তি তথ্য" />
            </Link>
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              aria-label="Search"
              className="inline-flex size-11 items-center justify-center rounded-full border border-line text-brand transition hover:border-gold-500 lg:hidden"
            >
              <Search className="size-5" aria-hidden="true" />
            </button>
            <button
              type="button"
              onClick={() => setMenuPath(pathname)}
              aria-label="Open menu"
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
              className="inline-flex size-11 items-center justify-center rounded-full bg-navy-900 text-white transition hover:bg-navy-700 lg:hidden"
            >
              <Menu className="size-5" aria-hidden="true" />
            </button>
          </div>
        </Container>
      </header>

      {/* Primary navigation (desktop, sticky) */}
      <div className={`no-print sticky top-0 z-40 hidden border-y border-line bg-surface/95 backdrop-blur transition-shadow duration-300 lg:block ${stuck ? "shadow-soft" : ""}`}>
        <Container className="flex items-center">
          <Link
            href="/"
            aria-label="BUTEX home"
            tabIndex={stuck ? 0 : -1}
            aria-hidden={!stuck}
            className={`hidden items-center gap-2 overflow-hidden transition-all duration-300 xl:flex ${stuck ? "mr-5 w-[6.75rem] opacity-100" : "w-0 opacity-0"}`}
          >
            <Emblem className="size-8 shrink-0" />
            <span className="font-serif text-lg text-brand">BUTEX</span>
          </Link>
          <nav aria-label="Primary" className="flex-1">
            <ul className="-mx-3 flex items-stretch justify-between xl:justify-start xl:gap-1">
              {NAV.map((item, index) => {
                const active = isActive(pathname, item.href);
                const alignRight = index >= NAV.length - 3;
                return (
                  <li key={item.href} className="group relative">
                    <Link
                      href={item.href}
                      aria-current={active ? "page" : undefined}
                      className={`nav-underline flex h-[3.25rem] items-center gap-1 whitespace-nowrap px-3 text-[0.9rem] font-medium xl:px-3.5 ${active ? "text-accent" : "text-ink hover:text-accent"}`}
                    >
                      <T en={item.label.en} bn={item.label.bn} />
                      {item.children && <ChevronDown className="hidden size-3.5 opacity-60 transition-transform duration-200 group-hover:rotate-180 xl:block" aria-hidden="true" />}
                    </Link>
                    {item.children && (
                      <div
                        className={`invisible absolute top-full z-50 translate-y-1 pt-px opacity-0 transition duration-200 group-focus-within:visible group-focus-within:translate-y-0 group-focus-within:opacity-100 group-hover:visible group-hover:translate-y-0 group-hover:opacity-100 ${alignRight ? "right-0" : "left-0"}`}
                      >
                        <ul className={`rounded-b-xl border border-t-2 border-line border-t-gold-500 bg-surface p-2 shadow-lift ${item.wide ? "grid w-[38rem] grid-cols-2" : "w-72"}`}>
                          {item.children.map((child) => (
                            <li key={child.href}>
                              <Link
                                href={child.href}
                                onClick={(e) => e.currentTarget.blur()}
                                className="block rounded-lg px-3 py-2 text-sm text-ink transition hover:bg-surface-2 hover:text-accent"
                              >
                                <T en={child.label.en} bn={child.label.bn} />
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          </nav>
          <button
            type="button"
            onClick={() => setSearchOpen(true)}
            aria-label="Search"
            tabIndex={stuck ? 0 : -1}
            aria-hidden={!stuck}
            className={`hidden size-9 items-center justify-center rounded-full border border-line text-brand transition hover:border-gold-500 xl:inline-flex ${stuck ? "opacity-100" : "pointer-events-none opacity-0"}`}
          >
            <Search className="size-4" aria-hidden="true" />
          </button>
        </Container>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div id="mobile-menu" role="dialog" aria-modal="true" aria-label="Menu" className="fixed inset-0 z-50 flex flex-col overflow-y-auto bg-surface lg:hidden">
          <div className="flex h-[4.5rem] shrink-0 items-center justify-between border-b border-line px-5">
            <span className="flex items-center gap-3">
              <Emblem className="size-10" />
              <span className="font-serif text-xl text-brand">BUTEX</span>
            </span>
            <button
              type="button"
              autoFocus
              onClick={closeMenu}
              aria-label="Close menu"
              className="inline-flex size-11 items-center justify-center rounded-full border border-line text-brand"
            >
              <X className="size-5" aria-hidden="true" />
            </button>
          </div>
          <nav aria-label="Primary" className="flex-1 px-5 py-4">
            <ul className="divide-y divide-line">
              {NAV.map((item) =>
                item.children ? (
                  <li key={item.href}>
                    <details className="group">
                      <summary className="flex list-none items-center justify-between py-4 font-serif text-xl text-brand">
                        <T en={item.label.en} bn={item.label.bn} />
                        <ChevronDown className="size-5 text-accent transition-transform group-open:rotate-180" aria-hidden="true" />
                      </summary>
                      <ul className="pb-4 pl-1">
                        <li>
                          <Link href={item.href} onClick={closeMenu} className="block py-2 text-[0.95rem] font-semibold text-accent">
                            <T en="Overview" bn="সারসংক্ষেপ" />
                          </Link>
                        </li>
                        {item.children.map((child) => (
                          <li key={child.href}>
                            <Link href={child.href} onClick={closeMenu} className="block py-2 text-[0.95rem] text-muted">
                              <T en={child.label.en} bn={child.label.bn} />
                            </Link>
                          </li>
                        ))}
                      </ul>
                    </details>
                  </li>
                ) : (
                  <li key={item.href}>
                    <Link href={item.href} onClick={closeMenu} className="block py-4 font-serif text-xl text-brand">
                      <T en={item.label.en} bn={item.label.bn} />
                    </Link>
                  </li>
                ),
              )}
            </ul>
          </nav>
          <div className="grid shrink-0 gap-3 border-t border-line bg-bg p-5">
            <Link href="/admission" onClick={closeMenu} className="inline-flex items-center justify-center gap-2 rounded-full bg-gold-500 px-5 py-3 text-sm font-semibold text-navy-950">
              <GraduationCap className="size-4" aria-hidden="true" />
              <T en="Admission Info" bn="ভর্তি তথ্য" />
            </Link>
            <Link href="/portal" onClick={closeMenu} className="inline-flex items-center justify-center gap-2 rounded-full border border-line px-5 py-3 text-sm font-semibold text-brand">
              <LogIn className="size-4" aria-hidden="true" />
              <T en="Student Portal" bn="স্টুডেন্ট পোর্টাল" />
            </Link>
          </div>
        </div>
      )}

      <SearchDialog open={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  );
}
