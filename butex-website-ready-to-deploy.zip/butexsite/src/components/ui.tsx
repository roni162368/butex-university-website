import Image from "next/image";
import Link from "next/link";
import type { ReactNode } from "react";
import { ArrowRight, Download, FileText, Info } from "lucide-react";
import { creditLine, type Img } from "@/lib/images";
import type { L } from "@/lib/site";
import { T } from "./t";

export function Container({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`mx-auto w-full max-w-[82rem] px-5 sm:px-8 ${className}`}>{children}</div>;
}

export function Eyebrow({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return (
    <p className={`flex items-center gap-3 text-[0.7rem] font-semibold uppercase tracking-[0.16em] sm:text-[0.72rem] sm:tracking-[0.22em] ${light ? "text-gold-300" : "text-accent"}`}>
      <span className="h-px w-8 shrink-0 bg-gold-500" aria-hidden="true" />
      <span>{children}</span>
    </p>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  lead,
  action,
  light = false,
}: {
  eyebrow?: ReactNode;
  title: ReactNode;
  lead?: ReactNode;
  action?: ReactNode;
  light?: boolean;
}) {
  return (
    <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
      <div className="max-w-2xl">
        {eyebrow && <Eyebrow light={light}>{eyebrow}</Eyebrow>}
        <h2 className={`mt-4 font-serif text-3xl leading-[1.12] tracking-tight sm:text-4xl lg:text-[2.75rem] ${light ? "text-white" : "text-brand"}`}>{title}</h2>
        {lead && <p className={`mt-4 text-lg leading-relaxed ${light ? "text-white/70" : "text-muted"}`}>{lead}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </div>
  );
}

const BUTTON_BASE =
  "inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-semibold tracking-wide transition duration-200 focus-visible:outline-offset-4";
const BUTTON_VARIANTS = {
  gold: "bg-gold-500 text-navy-950 shadow-[0_10px_26px_-12px_rgba(193,154,69,0.9)] hover:bg-gold-400",
  navy: "bg-navy-900 text-white hover:bg-navy-700 dark:bg-gold-500 dark:text-navy-950 dark:hover:bg-gold-400",
  outline: "border border-line bg-surface text-brand hover:border-gold-500 hover:text-accent",
  light: "border border-white/45 text-white backdrop-blur-sm hover:bg-white hover:text-navy-900",
} as const;

export function buttonClass(variant: keyof typeof BUTTON_VARIANTS = "navy", extra = "") {
  return `${BUTTON_BASE} ${BUTTON_VARIANTS[variant]} ${extra}`;
}

export function ButtonLink({
  href,
  variant = "navy",
  children,
  className = "",
}: {
  href: string;
  variant?: keyof typeof BUTTON_VARIANTS;
  children: ReactNode;
  className?: string;
}) {
  return (
    <Link href={href} className={buttonClass(variant, className)}>
      {children}
    </Link>
  );
}

export function TextLink({ href, children, light = false }: { href: string; children: ReactNode; light?: boolean }) {
  return (
    <Link
      href={href}
      className={`group inline-flex items-center gap-2 text-sm font-semibold transition-colors ${light ? "text-gold-300 hover:text-white" : "text-brand hover:text-accent"}`}
    >
      <span>{children}</span>
      <ArrowRight className="size-4 transition-transform duration-200 group-hover:translate-x-1" aria-hidden="true" />
    </Link>
  );
}

const BADGE_TONES = {
  neutral: "bg-surface-2 text-muted border-transparent",
  gold: "bg-gold-500/15 text-accent border-gold-500/30",
  navy: "bg-navy-900 text-white border-transparent dark:bg-navy-700",
  sample: "border-dashed border-gold-600/60 text-accent bg-transparent",
  goldOnDark: "bg-gold-400/20 text-gold-200 border-gold-400/40",
  sampleOnDark: "border-dashed border-gold-300/70 text-gold-200 bg-transparent",
} as const;

export function Badge({ children, tone = "neutral", title }: { children: ReactNode; tone?: keyof typeof BADGE_TONES; title?: string }) {
  return (
    <span title={title} className={`inline-flex items-center whitespace-nowrap rounded-full border px-2.5 py-0.5 text-[0.7rem] font-semibold uppercase tracking-wider ${BADGE_TONES[tone]}`}>
      {children}
    </span>
  );
}

/** Marks demonstration records so they are never mistaken for official content. */
export function SampleBadge({ onDark = false }: { onDark?: boolean }) {
  return (
    <Badge tone={onDark ? "sampleOnDark" : "sample"} title="Demonstration content, not an official record">
      <T en="Sample" bn="নমুনা" />
    </Badge>
  );
}

export function PlaceholderNote({ children, className = "" }: { children?: ReactNode; className?: string }) {
  return (
    <div role="note" className={`flex gap-3 rounded-lg border border-dashed border-gold-600/50 bg-gold-500/[0.07] px-4 py-3 text-sm leading-relaxed text-muted ${className}`}>
      <Info className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
      <p>
        {children ?? (
          <T
            en="Official information pending. This section will be completed once the university supplies verified content."
            bn="অফিসিয়াল তথ্য অপেক্ষমাণ। বিশ্ববিদ্যালয় যাচাইকৃত তথ্য প্রদান করলে এই অংশটি সম্পূর্ণ করা হবে।"
          />
        )}
      </p>
    </div>
  );
}

export function Photo({
  img,
  className = "",
  imgClassName = "",
  sizes = "(min-width: 1024px) 50vw, 100vw",
  priority = false,
  credit = true,
  creditLeft = false,
}: {
  img: Img;
  className?: string;
  imgClassName?: string;
  sizes?: string;
  priority?: boolean;
  credit?: boolean;
  creditLeft?: boolean;
}) {
  const line = creditLine(img);
  return (
    <figure className={`relative overflow-hidden bg-navy-900 ${className}`}>
      <Image src={img.src} alt={img.alt} fill sizes={sizes} priority={priority} className={`object-cover ${imgClassName}`} />
      {credit && line && (
        <figcaption className={`absolute bottom-0 max-w-full truncate bg-navy-950/70 px-2 py-1 text-[0.625rem] leading-none text-white/85 ${creditLeft ? "left-0 rounded-tr-md" : "right-0 rounded-tl-md"}`}>{line}</figcaption>
      )}
    </figure>
  );
}

export function FileLink({ fileId, fileName, compact = false }: { fileId: number; fileName?: string; compact?: boolean }) {
  return (
    <a
      href={`/api/files/${fileId}`}
      target="_blank"
      rel="noopener"
      className="inline-flex shrink-0 items-center gap-2 rounded-full border border-line bg-surface px-3.5 py-2 text-xs font-semibold text-brand transition hover:border-gold-500 hover:text-accent"
      aria-label={`Download PDF${fileName ? `: ${fileName}` : ""}`}
    >
      <FileText className="size-4 text-accent" aria-hidden="true" />
      {!compact && <span className="max-w-[11rem] truncate">{fileName || "Attachment"}</span>}
      <span>PDF</span>
      <Download className="size-3.5" aria-hidden="true" />
    </a>
  );
}

/** "On this page" navigation for long pages: a sticky rail on desktop, a scrollable strip on mobile. */
export function SectionNav({ items }: { items: { id: string; label: L }[] }) {
  return (
    <nav aria-label="On this page" className="no-print min-w-0 lg:sticky lg:top-24">
      <p className="hidden text-[0.7rem] font-semibold uppercase tracking-[0.2em] text-muted lg:block">
        <T en="On this page" bn="এই পৃষ্ঠায়" />
      </p>
      <ul className="-mx-5 flex gap-2 overflow-x-auto px-5 pb-2 lg:mx-0 lg:mt-4 lg:block lg:space-y-0.5 lg:overflow-visible lg:border-l lg:border-line lg:px-0 lg:pb-0">
        {items.map((item) => (
          <li key={item.id} className="shrink-0">
            <a
              href={`#${item.id}`}
              className="block whitespace-nowrap rounded-full border border-line bg-surface px-4 py-2 text-sm text-muted transition hover:border-gold-500 hover:text-brand lg:-ml-px lg:whitespace-normal lg:rounded-none lg:border-0 lg:border-l-2 lg:border-transparent lg:bg-transparent lg:py-1.5 lg:hover:border-gold-500"
            >
              <T en={item.label.en} bn={item.label.bn} />
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export function PageSection({ id, title, eyebrow, children }: { id: string; title: L; eyebrow?: ReactNode; children: ReactNode }) {
  return (
    <section id={id} aria-labelledby={`${id}-title`} className="scroll-mt-28 border-t border-line pt-12 first:border-t-0 first:pt-0">
      {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}
      <h2 id={`${id}-title`} className={`font-serif text-[1.75rem] leading-tight tracking-tight text-brand sm:text-4xl ${eyebrow ? "mt-3" : ""}`}>
        <T en={title.en} bn={title.bn} />
      </h2>
      <div className="mt-6">{children}</div>
    </section>
  );
}

export function EmptyState({ title, children }: { title: ReactNode; children?: ReactNode }) {
  return (
    <div className="rounded-xl border border-dashed border-line bg-surface px-6 py-10 text-center">
      <p className="font-serif text-xl text-brand">{title}</p>
      {children && <p className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-muted">{children}</p>}
    </div>
  );
}
