"use client";

import { useState } from "react";
import { ExternalLink, MapPin } from "lucide-react";
import { SITE } from "@/lib/site";

type Zone = {
  id: string;
  name: string;
  kind: string;
  description: string;
  x: number;
  y: number;
  w: number;
  h: number;
  green?: boolean;
};

/**
 * Schematic zones. The layout is illustrative only (it is not a survey and is
 * not to scale); it should be replaced with the official campus plan.
 */
const ZONES: Zone[] = [
  { id: "gate", name: "Main Gate", kind: "Entrance", description: "Main entrance from Shaheed Tajuddin Ahmed Avenue.", x: 40, y: 318, w: 110, h: 44 },
  { id: "admin", name: "Administrative Building", kind: "Administration", description: "University administration and central offices.", x: 180, y: 250, w: 170, h: 112 },
  { id: "academic", name: "Academic Buildings", kind: "Teaching", description: "Classrooms, departmental offices and teaching spaces.", x: 380, y: 60, w: 200, h: 130 },
  { id: "labs", name: "Laboratories & Workshops", kind: "Laboratories", description: "Yarn, fabric, wet processing and apparel laboratories and workshops.", x: 610, y: 60, w: 210, h: 130 },
  { id: "library", name: "Library", kind: "Learning", description: "Reading rooms and reference collections.", x: 180, y: 60, w: 170, h: 100 },
  { id: "minar", name: "Shaheed Minar", kind: "Monument", description: "Campus monument and focal point for national observances.", x: 400, y: 232, w: 90, h: 70, green: true },
  { id: "playground", name: "Central Playground", kind: "Sports", description: "Open field for sports and outdoor events.", x: 520, y: 222, w: 180, h: 140, green: true },
  { id: "halls", name: "Residential Halls", kind: "Residence", description: "Halls of residence for students.", x: 730, y: 222, w: 130, h: 140 },
  { id: "auditorium", name: "Auditorium", kind: "Events", description: "Venue for seminars, ceremonies and cultural programs.", x: 40, y: 60, w: 110, h: 100 },
  { id: "cafeteria", name: "Cafeteria", kind: "Amenities", description: "Food and refreshments for students and staff.", x: 40, y: 190, w: 110, h: 90 },
];

export function CampusMap() {
  const [activeId, setActiveId] = useState("academic");
  const active = ZONES.find((z) => z.id === activeId) ?? ZONES[0];

  return (
    <div className="space-y-5">
      <div className="overflow-hidden rounded-2xl border border-line bg-surface">
        <div className="overflow-x-auto" tabIndex={0} role="region" aria-label="Campus map (scroll sideways on small screens)">
        <svg viewBox="0 0 900 420" role="group" aria-label="Schematic map of the BUTEX campus" className="block h-auto w-full min-w-[44rem]">
          <rect width="900" height="420" className="fill-surface-2" />
          {/* avenue */}
          <rect x="0" y="378" width="900" height="42" className="fill-line" />
          <line x1="0" y1="399" x2="900" y2="399" strokeDasharray="14 12" className="stroke-surface" strokeWidth="2" />
          <text x="450" y="412" textAnchor="middle" className="fill-muted text-[11px]" style={{ letterSpacing: "0.2em" }}>
            SHAHEED TAJUDDIN AHMED AVENUE
          </text>
          {/* internal paths */}
          <path d="M95 318 V300 H365 V205 H845 M365 205 V40" fill="none" className="stroke-surface" strokeWidth="14" strokeLinecap="round" strokeLinejoin="round" />

          {ZONES.map((z) => {
            const on = z.id === activeId;
            return (
              <g
                key={z.id}
                role="button"
                tabIndex={0}
                aria-pressed={on}
                aria-label={`${z.name}: ${z.description}`}
                onClick={() => setActiveId(z.id)}
                onMouseEnter={() => setActiveId(z.id)}
                onFocus={() => setActiveId(z.id)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    setActiveId(z.id);
                  }
                }}
                className="cursor-pointer outline-none [&:focus-visible>rect]:stroke-[3px]"
              >
                <rect
                  x={z.x}
                  y={z.y}
                  width={z.w}
                  height={z.h}
                  rx="10"
                  className={`transition-all duration-200 ${
                    on ? "fill-navy-900 stroke-gold-500 dark:fill-gold-500" : z.green ? "fill-emerald-600/15 stroke-emerald-700/40" : "fill-surface stroke-line"
                  }`}
                  strokeWidth={on ? 2.5 : 1.5}
                />
                <text
                  x={z.x + z.w / 2}
                  y={z.y + z.h / 2 + 4}
                  textAnchor="middle"
                  className={`pointer-events-none text-[13px] font-semibold transition-colors ${on ? "fill-white dark:fill-navy-950" : "fill-ink"}`}
                >
                  {z.name.length > 16 && z.w < 180 ? (
                    <>
                      <tspan x={z.x + z.w / 2} dy="-6">
                        {z.name.split(" ").slice(0, Math.ceil(z.name.split(" ").length / 2)).join(" ")}
                      </tspan>
                      <tspan x={z.x + z.w / 2} dy="16">
                        {z.name.split(" ").slice(Math.ceil(z.name.split(" ").length / 2)).join(" ")}
                      </tspan>
                    </>
                  ) : (
                    z.name
                  )}
                </text>
              </g>
            );
          })}
          {/* compass */}
          <g transform="translate(858 34)" className="text-muted">
            <circle r="15" className="fill-surface stroke-line" />
            <path d="M0 -10 L4 3 L0 0 L-4 3 Z" className="fill-gold-500" />
            <text y="12" textAnchor="middle" className="fill-muted text-[7px] font-bold">
              N
            </text>
          </g>
        </svg>
        </div>
        <p className="border-t border-line px-5 py-3 text-xs leading-relaxed text-muted">
          Illustrative schematic, not to scale. Building positions are indicative and will be replaced with the official campus plan.
        </p>
      </div>

      <div className="grid gap-5 md:grid-cols-[1fr_1.4fr]">
        <div className="rounded-2xl border border-line bg-surface p-6" aria-live="polite">
          <p className="text-[0.7rem] font-semibold uppercase tracking-[0.18em] text-accent">{active.kind}</p>
          <h3 className="mt-2 flex items-center gap-2 font-serif text-2xl text-brand">
            <MapPin className="size-5 text-accent" aria-hidden="true" />
            {active.name}
          </h3>
          <p className="mt-3 leading-relaxed text-muted">{active.description}</p>
        </div>
        <div className="flex flex-col gap-4">
        <ul className="grid grid-cols-2 gap-2 text-sm sm:grid-cols-3 md:grid-cols-2 xl:grid-cols-3">
          {ZONES.map((z) => (
            <li key={z.id}>
              <button
                type="button"
                onClick={() => setActiveId(z.id)}
                aria-pressed={z.id === activeId}
                className={`w-full rounded-lg border px-3 py-2 text-left transition ${
                  z.id === activeId ? "border-gold-500 bg-gold-500/10 font-semibold text-brand" : "border-line bg-surface text-muted hover:border-gold-500/60 hover:text-brand"
                }`}
              >
                {z.name}
              </button>
            </li>
          ))}
        </ul>
        <a href={SITE.mapsLink} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm font-semibold text-brand transition hover:text-accent">
          Get directions in Google Maps <ExternalLink className="size-3.5" aria-hidden="true" />
        </a>
        </div>
      </div>
    </div>
  );
}
