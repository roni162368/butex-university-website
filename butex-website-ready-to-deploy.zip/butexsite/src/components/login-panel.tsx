"use client";

import Link from "next/link";
import { useState, type FormEvent, type ReactNode } from "react";
import { ArrowLeft, CheckCircle2, Eye, EyeOff, FlaskConical, Loader2, LogIn } from "lucide-react";
import { ApiError, api } from "@/lib/client";
import { Emblem } from "./logo";
import { ThemeToggle } from "./prefs-controls";

export type SessionUser = { id: number; name: string; role: string; identifier: string; departmentSlug: string; isDemo: boolean };

export function LoginPanel({
  role,
  title,
  tagline,
  features,
  idLabel,
  idPlaceholder,
  idType = "text",
  demo,
  footnote,
  onSuccess,
}: {
  role: "admin" | "student";
  title: string;
  tagline: string;
  features: string[];
  idLabel: string;
  idPlaceholder: string;
  idType?: "text" | "email";
  demo: { identifier: string; password: string } | null;
  footnote?: ReactNode;
  onSuccess: (token: string, user: SessionUser) => void;
}) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [fields, setFields] = useState<Record<string, string>>({});

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError("");
    setFields({});
    try {
      const data = await api<{ token: string; user: SessionUser }>("/api/auth/login", { json: { identifier, password, role } });
      onSuccess(data.token, data.user);
    } catch (err) {
      if (err instanceof ApiError) {
        setError(err.message);
        setFields(err.fields);
      } else {
        setError("Sign-in failed. Please try again.");
      }
      setBusy(false);
    }
  };

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <aside className="relative hidden overflow-hidden bg-navy-900 text-white lg:block">
        <div className="weave absolute inset-0" aria-hidden="true" />
        <div className="relative flex h-full flex-col justify-between p-12 xl:p-16">
          <Link href="/" className="flex items-center gap-3">
            <Emblem className="size-12" />
            <span>
              <span className="block font-serif text-xl leading-tight">Bangladesh University of Textiles</span>
              <span className="mt-1 block text-[0.65rem] font-semibold uppercase tracking-[0.24em] text-gold-400">BUTEX</span>
            </span>
          </Link>
          <div>
            <p className="flex items-center gap-3 text-[0.72rem] font-semibold uppercase tracking-[0.22em] text-gold-300">
              <span className="h-px w-8 bg-gold-500" aria-hidden="true" />
              {role === "admin" ? "Staff access" : "Student access"}
            </p>
            <h1 className="mt-5 font-serif text-5xl leading-[1.06] tracking-tight xl:text-6xl">{title}</h1>
            <p className="mt-5 max-w-md text-lg leading-relaxed text-white/70">{tagline}</p>
            <ul className="mt-10 grid max-w-lg gap-3 sm:grid-cols-2">
              {features.map((f) => (
                <li key={f} className="flex items-center gap-2.5 text-sm text-white/85">
                  <CheckCircle2 className="size-4 shrink-0 text-gold-400" aria-hidden="true" />
                  {f}
                </li>
              ))}
            </ul>
          </div>
          <p className="text-xs text-white/45">92 Shaheed Tajuddin Ahmed Avenue, Tejgaon Industrial Area, Dhaka-1208</p>
        </div>
      </aside>

      <main id="main" className="flex flex-col bg-bg">
        <div className="flex items-center justify-between px-6 py-5 sm:px-10">
          <Link href="/" className="group inline-flex items-center gap-2 text-sm font-semibold text-brand hover:text-accent">
            <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" aria-hidden="true" />
            University website
          </Link>
          <ThemeToggle className="inline-flex size-9 items-center justify-center rounded-full border border-line text-brand transition hover:border-gold-500" />
        </div>

        <div className="flex flex-1 items-center justify-center px-6 pb-16 sm:px-10">
          <div className="w-full max-w-md">
            <div className="lg:hidden">
              <Emblem className="size-12" />
              <h1 className="mt-5 font-serif text-4xl leading-tight text-brand">{title}</h1>
            </div>
            <h2 className="mt-4 font-serif text-3xl text-brand lg:mt-0">Sign in</h2>
            <p className="mt-2 text-muted">{role === "admin" ? "Use your administrator account to manage website content." : "Use your student ID and password to continue."}</p>

            <form onSubmit={submit} noValidate className="mt-8 space-y-5">
              <div>
                <label htmlFor="login-id" className="mb-1.5 block text-sm font-semibold text-ink">
                  {idLabel}
                </label>
                <input
                  id="login-id"
                  type={idType}
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder={idPlaceholder}
                  autoComplete="username"
                  autoCapitalize="none"
                  spellCheck={false}
                  aria-invalid={fields.identifier ? "true" : undefined}
                  aria-describedby={fields.identifier ? "login-id-error" : undefined}
                  className="field h-12"
                />
                {fields.identifier && (
                  <p id="login-id-error" className="mt-1.5 text-sm text-orange-700 dark:text-orange-400">
                    {fields.identifier}
                  </p>
                )}
              </div>
              <div>
                <label htmlFor="login-password" className="mb-1.5 block text-sm font-semibold text-ink">
                  Password
                </label>
                <div className="relative">
                  <input
                    id="login-password"
                    type={show ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="current-password"
                    aria-invalid={fields.password ? "true" : undefined}
                    aria-describedby={fields.password ? "login-password-error" : undefined}
                    className="field h-12 !pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShow((s) => !s)}
                    aria-label={show ? "Hide password" : "Show password"}
                    aria-pressed={show}
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full p-2 text-muted hover:text-brand"
                  >
                    {show ? <EyeOff className="size-4" aria-hidden="true" /> : <Eye className="size-4" aria-hidden="true" />}
                  </button>
                </div>
                {fields.password && (
                  <p id="login-password-error" className="mt-1.5 text-sm text-orange-700 dark:text-orange-400">
                    {fields.password}
                  </p>
                )}
              </div>

              {error && (
                <p role="alert" className="rounded-lg border border-orange-700/30 bg-orange-500/10 px-4 py-3 text-sm text-orange-800 dark:text-orange-300">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={busy}
                className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-full bg-navy-900 text-sm font-semibold text-white transition hover:bg-navy-700 disabled:opacity-70 dark:bg-gold-500 dark:text-navy-950 dark:hover:bg-gold-400"
              >
                {busy ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <LogIn className="size-4" aria-hidden="true" />}
                {busy ? "Signing in…" : "Sign in"}
              </button>
            </form>

            {demo && (
              <div className="mt-8 rounded-2xl border border-dashed border-gold-600/50 bg-gold-500/[0.07] p-5">
                <p className="flex items-center gap-2 text-[0.72rem] font-semibold uppercase tracking-[0.18em] text-accent">
                  <FlaskConical className="size-4" aria-hidden="true" /> Demonstration account
                </p>
                <p className="mt-2 text-sm leading-relaxed text-muted">
                  The university&apos;s identity system is not connected yet. Use this demonstration account to explore the {role === "admin" ? "dashboard" : "portal"}.
                </p>
                <dl className="mt-3 grid grid-cols-[auto_1fr] gap-x-4 gap-y-1 text-sm">
                  <dt className="text-muted">{idLabel}</dt>
                  <dd className="font-mono font-semibold text-ink">{demo.identifier}</dd>
                  <dt className="text-muted">Password</dt>
                  <dd className="font-mono font-semibold text-ink">{demo.password}</dd>
                </dl>
                <button
                  type="button"
                  onClick={() => {
                    setIdentifier(demo.identifier);
                    setPassword(demo.password);
                    setError("");
                    setFields({});
                  }}
                  className="mt-4 rounded-full border border-gold-600/50 px-4 py-2 text-sm font-semibold text-accent transition hover:bg-gold-500/15"
                >
                  Fill in demo credentials
                </button>
              </div>
            )}
            {footnote && <div className="mt-6 text-sm text-muted">{footnote}</div>}
          </div>
        </div>
      </main>
    </div>
  );
}
