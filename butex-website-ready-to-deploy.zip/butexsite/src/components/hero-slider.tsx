"use client";

import Image from "next/image";
import { useEffect, useState, type ReactNode } from "react";
import { ChevronLeft, ChevronRight, Pause, Play } from "lucide-react";
import { Container } from "./ui";

export type Slide = { src: string; alt: string; label: string; credit: string };

const CONTROL =
  "inline-flex size-10 items-center justify-center rounded-full border border-white/30 text-white backdrop-blur-sm transition hover:border-gold-400 hover:bg-white/10 hover:text-gold-300";

export function HeroSlider({ slides, children }: { slides: Slide[]; children: ReactNode }) {
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [engaged, setEngaged] = useState(false);
  const [loadRest, setLoadRest] = useState(false);
  const count = slides.length;

  // Defer the off-screen slides so the first image owns the initial load.
  useEffect(() => {
    const t = window.setTimeout(() => setLoadRest(true), 1800);
    return () => window.clearTimeout(t);
  }, []);

  useEffect(() => {
    if (!playing || engaged || !loadRest || count < 2) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = window.setTimeout(() => setIndex((i) => (i + 1) % count), 6500);
    return () => window.clearTimeout(t);
  }, [index, playing, engaged, loadRest, count]);

  const go = (delta: number) => {
    setLoadRest(true);
    setIndex((i) => (i + delta + count) % count);
  };
  const current = slides[index];

  return (
    <section
      aria-roledescription="carousel"
      aria-label="Campus, laboratories and student life"
      className="relative isolate overflow-hidden bg-navy-950 text-white"
      onMouseEnter={() => setEngaged(true)}
      onMouseLeave={() => setEngaged(false)}
      onFocusCapture={() => setEngaged(true)}
      onBlurCapture={() => setEngaged(false)}
    >
      <div className="absolute inset-0 -z-10">
        {slides.map((slide, i) =>
          i === 0 || loadRest ? (
            <div
              key={slide.src}
              role="group"
              aria-roledescription="slide"
              aria-label={`${i + 1} of ${count}`}
              aria-hidden={i !== index}
              className={`absolute inset-0 transition-opacity duration-[1400ms] ease-out ${i === index ? "opacity-100" : "opacity-0"}`}
            >
              <Image src={slide.src} alt={slide.alt} fill priority={i === 0} sizes="100vw" className={`object-cover ${i === index ? "animate-kenburns" : ""}`} />
            </div>
          ) : null,
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-navy-950/95 via-navy-950/70 to-navy-950/15" aria-hidden="true" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/85 via-transparent to-navy-950/35" aria-hidden="true" />
      </div>

      <Container className="flex min-h-[37rem] flex-col justify-center pb-40 pt-16 sm:min-h-[40rem] lg:min-h-[min(47rem,calc(100svh-12rem))] lg:pb-44 lg:pt-20">{children}</Container>

      <div className="absolute inset-x-0 bottom-16 sm:bottom-[4.5rem]">
        <Container className="flex items-end justify-between gap-6">
          <div className="flex items-center gap-2 sm:gap-3">
            {slides.map((slide, i) => (
              <button
                key={slide.src}
                type="button"
                onClick={() => {
                  setLoadRest(true);
                  setIndex(i);
                }}
                aria-label={`Show slide ${i + 1}: ${slide.label}`}
                aria-current={i === index ? "true" : undefined}
                className="group py-3"
              >
                <span className={`block h-[3px] rounded-full transition-all duration-500 ${i === index ? "w-12 bg-gold-400 sm:w-16" : "w-6 bg-white/40 group-hover:bg-white/75 sm:w-10"}`} />
              </button>
            ))}
          </div>

          <div className="flex items-center gap-5">
            <p className="hidden max-w-xs text-right text-xs leading-snug text-white/70 md:block" aria-live="polite">
              <span className="block font-medium text-white">{current.label}</span>
              <span>{current.credit}</span>
            </p>
            <div className="flex items-center gap-1.5">
              <button type="button" className={CONTROL} onClick={() => go(-1)} aria-label="Previous slide">
                <ChevronLeft className="size-5" aria-hidden="true" />
              </button>
              <button type="button" className={CONTROL} onClick={() => setPlaying((p) => !p)} aria-label={playing ? "Pause slideshow" : "Play slideshow"}>
                {playing ? <Pause className="size-4" aria-hidden="true" /> : <Play className="size-4" aria-hidden="true" />}
              </button>
              <button type="button" className={CONTROL} onClick={() => go(1)} aria-label="Next slide">
                <ChevronRight className="size-5" aria-hidden="true" />
              </button>
            </div>
          </div>
        </Container>
      </div>
    </section>
  );
}
