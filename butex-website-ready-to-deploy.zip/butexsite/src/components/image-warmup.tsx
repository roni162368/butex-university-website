"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";

type Connection = { saveData?: boolean; effectiveType?: string };

/**
 * Images below the fold are lazy-loaded so the first paint stays fast. Once the
 * page has finished loading, and only on fast connections without Data Saver,
 * the remaining images are fetched in the background so scrolling never reveals
 * empty frames.
 */
export function ImageWarmup() {
  const pathname = usePathname();

  useEffect(() => {
    const connection = (navigator as Navigator & { connection?: Connection }).connection;
    if (connection?.saveData || (connection?.effectiveType && connection.effectiveType !== "4g")) return;

    let timer = 0;
    const warm = () => {
      document.querySelectorAll<HTMLImageElement>('img[loading="lazy"]').forEach((img) => {
        img.loading = "eager";
      });
    };
    const schedule = () => {
      timer = window.setTimeout(warm, 1200);
    };

    if (document.readyState === "complete") schedule();
    else window.addEventListener("load", schedule, { once: true });

    return () => {
      window.removeEventListener("load", schedule);
      window.clearTimeout(timer);
    };
  }, [pathname]);

  return null;
}
