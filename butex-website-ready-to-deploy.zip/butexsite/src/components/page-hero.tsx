import Image from "next/image";
import Link from "next/link";
import type { ReactNode } from "react";
import { ChevronRight } from "lucide-react";
import { creditLine, type Img } from "@/lib/images";
import type { L } from "@/lib/site";
import { T } from "./t";
import { Container, Eyebrow } from "./ui";

export type Crumb = { label: L; href?: string };

export function Breadcrumbs({ crumbs }: { crumbs: Crumb[] }) {
  const all: Crumb[] = [{ label: { en: "Home", bn: "হোম" }, href: "/" }, ...crumbs];
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: all.map((c, i) => ({ "@type": "ListItem", position: i + 1, name: c.label.en, ...(c.href ? { item: c.href } : {}) })),
  };
  return (
    <nav aria-label="Breadcrumb">
      <ol className="flex flex-wrap items-center gap-x-1.5 gap-y-1 text-[0.8rem] text-white/65">
        {all.map((c, i) => {
          const last = i === all.length - 1;
          return (
            <li key={`${c.label.en}-${i}`} className="flex items-center gap-1.5">
              {c.href && !last ? (
                <Link href={c.href} className="transition hover:text-gold-300">
                  <T en={c.label.en} bn={c.label.bn} />
                </Link>
              ) : (
                <span aria-current={last ? "page" : undefined} className={last ? "text-white" : undefined}>
                  <T en={c.label.en} bn={c.label.bn} />
                </span>
              )}
              {!last && <ChevronRight className="size-3.5 text-gold-500/80" aria-hidden="true" />}
            </li>
          );
        })}
      </ol>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }} />
    </nav>
  );
}

export function PageHero({
  title,
  lead,
  eyebrow,
  crumbs,
  image,
  children,
}: {
  title: L;
  lead?: ReactNode;
  eyebrow?: ReactNode;
  crumbs: Crumb[];
  image?: Img;
  children?: ReactNode;
}) {
  const credit = image ? creditLine(image) : "";
  return (
    <section className="relative isolate overflow-hidden bg-navy-900 text-white">
      {image && <Image src={image.src} alt="" fill priority sizes="100vw" className="-z-10 object-cover opacity-35" />}
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-navy-950 via-navy-900/90 to-navy-900/40" aria-hidden="true" />
      <div className="weave absolute inset-0 -z-10" aria-hidden="true" />
      <Container className="py-12 sm:py-16 lg:py-20">
        <Breadcrumbs crumbs={crumbs} />
        <div className="mt-8 max-w-3xl animate-fade-up">
          {eyebrow && <Eyebrow light>{eyebrow}</Eyebrow>}
          <h1 className={`font-serif text-4xl leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl ${eyebrow ? "mt-4" : ""}`}>
            <T en={title.en} bn={title.bn} />
          </h1>
          {lead && <p className="mt-5 max-w-2xl text-lg leading-relaxed text-white/75">{lead}</p>}
          {children && <div className="mt-8">{children}</div>}
        </div>
      </Container>
      {credit && <p className="absolute bottom-2 right-3 hidden text-[0.625rem] text-white/50 sm:block">{credit}</p>}
      <div className="thread absolute inset-x-0 bottom-0" aria-hidden="true" />
    </section>
  );
}
