"use client";

import { useEffect, useRef } from "react";

/**
 * Counts up to `value` when scrolled into view. The final value is what React
 * renders (so it is correct without JavaScript and for reduced-motion users);
 * the animation only rewrites the text node while it runs.
 */
export function StatCounter({ value, suffix = "" }: { value: number; suffix?: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const final = `${value.toLocaleString("en-US")}${suffix}`;

  useEffect(() => {
    const el = ref.current;
    if (!el || !("IntersectionObserver" in window)) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const paint = (n: number) => {
      const text = `${n.toLocaleString("en-US")}${suffix}`;
      if (el.firstChild) el.firstChild.nodeValue = text;
      else el.textContent = text;
    };

    let raf = 0;
    let started = false;
    paint(0);

    const run = () => {
      started = true;
      const start = performance.now();
      const duration = 1400;
      const tick = (now: number) => {
        const p = Math.min(1, (now - start) / duration);
        paint(Math.round(value * (1 - Math.pow(1 - p, 3))));
        if (p < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    };

    const io = new IntersectionObserver(
      (entries) => {
        if (!started && entries.some((e) => e.isIntersecting)) {
          io.disconnect();
          run();
        }
      },
      { threshold: 0.4 },
    );
    io.observe(el);
    // Never leave a zero on screen if the observer does not fire.
    const fallback = window.setTimeout(() => {
      if (!started) {
        io.disconnect();
        paint(value);
      }
    }, 3000);

    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
      window.clearTimeout(fallback);
      paint(value);
    };
  }, [value, suffix]);

  return (
    <span className="tabular-nums">
      <span ref={ref} aria-hidden="true">
        {final}
      </span>
      <span className="sr-only">{final}</span>
    </span>
  );
}
