"use client";

import { Moon, Sun } from "lucide-react";
import { setLang, setLargeText, setTheme, useLang, useLargeText, useTheme } from "@/lib/client";

const ICON_BUTTON =
  "inline-flex h-7 min-w-7 items-center justify-center rounded-full px-1.5 text-white/80 transition hover:bg-white/10 hover:text-white";

export function ThemeToggle({ className = ICON_BUTTON }: { className?: string }) {
  const theme = useTheme();
  const next = theme === "dark" ? "light" : "dark";
  return (
    <button type="button" className={className} onClick={() => setTheme(next)} aria-label={`Switch to ${next} mode`} title={`Switch to ${next} mode`}>
      {theme === "dark" ? <Sun className="size-4" aria-hidden="true" /> : <Moon className="size-4" aria-hidden="true" />}
    </button>
  );
}

export function TextSizeToggle({ className = ICON_BUTTON }: { className?: string }) {
  const large = useLargeText();
  return (
    <button
      type="button"
      className={className}
      onClick={() => setLargeText(!large)}
      aria-pressed={large}
      aria-label={large ? "Use standard text size" : "Use larger text"}
      title={large ? "Use standard text size" : "Use larger text"}
    >
      <span className="text-[0.8rem] font-bold leading-none" aria-hidden="true">
        A{large ? "−" : "+"}
      </span>
    </button>
  );
}

export function LanguageToggle({ tone = "dark" }: { tone?: "dark" | "light" }) {
  const lang = useLang();
  const wrap = tone === "dark" ? "border-white/20" : "border-line";
  const active = tone === "dark" ? "bg-white text-navy-950" : "bg-navy-900 text-white";
  const idle = tone === "dark" ? "text-white/75 hover:text-white" : "text-muted hover:text-brand";
  return (
    <div role="group" aria-label="Language" className={`inline-flex items-center rounded-full border p-0.5 text-[0.7rem] font-semibold ${wrap}`}>
      <button type="button" onClick={() => setLang("en")} aria-pressed={lang === "en"} className={`rounded-full px-2.5 py-1 leading-none transition ${lang === "en" ? active : idle}`}>
        EN
      </button>
      <button type="button" lang="bn" onClick={() => setLang("bn")} aria-pressed={lang === "bn"} className={`rounded-full px-2.5 py-1 leading-none transition ${lang === "bn" ? active : idle}`}>
        বাংলা
      </button>
    </div>
  );
}
