"use client";

import Link from "next/link";
import { useEffect, useState, type ReactNode } from "react";
import {
  Award,
  BellRing,
  CalendarDays,
  ClipboardList,
  Clock,
  Download,
  ExternalLink,
  FlaskConical,
  FolderOpen,
  LayoutDashboard,
  Loader2,
  LogOut,
  RefreshCw,
  UserRound,
} from "lucide-react";
import { ApiError, api, setStoredToken, useStoredToken } from "@/lib/client";
import { fmtDate, fmtTime, hasTime } from "@/lib/format";
import type { PortalDemo } from "@/lib/portal-demo";
import { noticeCategory, type DeptRef } from "@/lib/site";
import { LoginPanel, type SessionUser } from "../login-panel";
import { Emblem } from "../logo";
import { ThemeToggle } from "../prefs-controls";
import { Badge, SampleBadge } from "../ui";

const TOKEN_KEY = "butex-student-token";

type PortalData = {
  student: SessionUser & { department: DeptRef | null };
  demo: PortalDemo;
  exams: { code: string; time: string; room: string; date: string }[];
  notices: { id: number; title: string; category: string; publishedAt: string; fileId: number | null; isSample: boolean }[];
  calendar: { id: number; title: string; category: string; startsAt: string; endsAt: string | null; location: string; isSample: boolean }[];
  documents: { id: number; title: string; category: string; fileId: number | null; isSample: boolean }[];
};

const TABS = [
  { id: "overview", label: "Dashboard", icon: LayoutDashboard },
  { id: "calendar", label: "Academic Calendar", icon: CalendarDays },
  { id: "routine", label: "Class Routine", icon: Clock },
  { id: "exams", label: "Exam Routine", icon: ClipboardList },
  { id: "results", label: "Results", icon: Award },
  { id: "materials", label: "Course Materials", icon: FolderOpen },
  { id: "labs", label: "Lab Schedule", icon: FlaskConical },
  { id: "notices", label: "Academic Notices", icon: BellRing },
] as const;
type TabId = (typeof TABS)[number]["id"];

function Panel({ title, action, children, className = "" }: { title: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-2xl border border-line bg-surface ${className}`}>
      <header className="flex items-center justify-between gap-4 border-b border-line px-5 py-4 sm:px-6">
        <h2 className="font-serif text-xl text-brand">{title}</h2>
        {action}
      </header>
      <div className="p-5 sm:p-6">{children}</div>
    </section>
  );
}

function DemoNote({ children }: { children?: ReactNode }) {
  return (
    <p role="note" className="mb-6 flex items-start gap-3 rounded-xl border border-dashed border-gold-600/50 bg-gold-500/[0.07] px-4 py-3 text-sm leading-relaxed text-muted">
      <FlaskConical className="mt-0.5 size-4 shrink-0 text-accent" aria-hidden="true" />
      <span>{children ?? "Demonstration data. Courses, timetables and grades shown here are samples, not real academic records."}</span>
    </p>
  );
}

const TH = "px-4 py-3 text-left text-[0.68rem] font-semibold uppercase tracking-[0.14em] text-muted";
const TD = "px-4 py-3.5 align-top text-sm text-ink";

export function PortalApp({ demo }: { demo: { identifier: string; password: string } }) {
  const token = useStoredToken(TOKEN_KEY);
  const [data, setData] = useState<PortalData | null>(null);
  const [error, setError] = useState("");
  const [tab, setTab] = useState<TabId>("overview");

  const [reload, setReload] = useState(0);

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    api<PortalData>("/api/portal", { token })
      .then((fresh) => {
        if (cancelled) return;
        setData(fresh);
        setError("");
      })
      .catch((err) => {
        if (cancelled) return;
        if (err instanceof ApiError && (err.status === 401 || err.status === 403)) {
          setStoredToken(TOKEN_KEY, null);
          setData(null);
        } else {
          setError(err instanceof Error ? err.message : "The portal could not be loaded.");
        }
      });
    return () => {
      cancelled = true;
    };
  }, [token, reload]);

  const signOut = async () => {
    const t = token;
    setStoredToken(TOKEN_KEY, null);
    setData(null);
    if (t) await api("/api/auth/session", { method: "DELETE", token: t }).catch(() => undefined);
  };

  if (token === undefined) {
    return (
      <div className="flex min-h-screen items-center justify-center" role="status" aria-label="Loading">
        <Loader2 className="size-8 animate-spin text-accent" aria-hidden="true" />
      </div>
    );
  }

  if (!token) {
    return (
      <LoginPanel
        role="student"
        title="Student Portal"
        tagline="Your routine, results, course materials and notices in one place."
        features={["Personal academic dashboard", "Class and exam routines", "Term results", "Course materials", "Laboratory schedules", "Academic notices"]}
        idLabel="Student ID"
        idPlaceholder="e.g. DEMO-0001"
        demo={demo}
        onSuccess={(t) => setStoredToken(TOKEN_KEY, t)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-bg">
      <header className="bg-navy-950 text-white">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-5 sm:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <Emblem className="size-9 shrink-0" />
            <div className="min-w-0">
              <p className="truncate font-serif text-lg leading-tight">Student Portal</p>
              <p className="truncate text-[0.6rem] font-semibold uppercase tracking-[0.22em] text-gold-400">BUTEX · Demonstration</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Link href="/" className="hidden items-center gap-1.5 rounded-full border border-white/20 px-3 py-1.5 text-xs font-semibold text-white/85 transition hover:border-gold-400 hover:text-gold-300 sm:inline-flex">
              University website <ExternalLink className="size-3" aria-hidden="true" />
            </Link>
            <button type="button" onClick={signOut} className="inline-flex shrink-0 items-center gap-1.5 whitespace-nowrap rounded-full bg-white/10 px-3 py-1.5 text-xs font-semibold transition hover:bg-white/20">
              <LogOut className="size-3.5" aria-hidden="true" /> Sign out
            </button>
          </div>
        </div>
      </header>

      <nav aria-label="Portal sections" className="sticky top-0 z-30 border-b border-line bg-surface/95 backdrop-blur">
        <div role="tablist" className="mx-auto flex max-w-7xl gap-1 overflow-x-auto px-3 sm:px-6">
          {TABS.map((t) => (
            <button
              key={t.id}
              type="button"
              role="tab"
              id={`tab-${t.id}`}
              aria-selected={tab === t.id}
              aria-controls="portal-panel"
              onClick={() => setTab(t.id)}
              className={`inline-flex shrink-0 items-center gap-2 border-b-2 px-3 py-4 text-sm font-medium transition ${
                tab === t.id ? "border-gold-500 text-accent" : "border-transparent text-muted hover:text-brand"
              }`}
            >
              <t.icon className="size-4" aria-hidden="true" />
              {t.label}
            </button>
          ))}
        </div>
      </nav>

      <main id="portal-panel" role="tabpanel" aria-labelledby={`tab-${tab}`} className="mx-auto max-w-7xl px-5 py-8 sm:px-8 lg:py-10">
        {error && (
          <div role="alert" className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-orange-700/30 bg-orange-500/10 px-4 py-3 text-sm text-orange-800 dark:text-orange-300">
            {error}
            <button
              type="button"
              onClick={() => {
                setError("");
                setReload((n) => n + 1);
              }}
              className="inline-flex items-center gap-1.5 font-semibold underline-offset-4 hover:underline"
            >
              <RefreshCw className="size-3.5" aria-hidden="true" /> Try again
            </button>
          </div>
        )}
        {!data && !error && (
          <div className="grid gap-4 md:grid-cols-3" role="status" aria-label="Loading your dashboard">
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="skeleton h-32" />
            ))}
          </div>
        )}
        {data && <PortalContent data={data} tab={tab} setTab={setTab} />}
      </main>
    </div>
  );
}

function PortalContent({ data, tab, setTab }: { data: PortalData; tab: TabId; setTab: (t: TabId) => void }) {
  const { demo, student } = data;
  const course = (code: string) => demo.courses[code]?.title ?? code;
  const allCourses = demo.results.flatMap((r) => r.courses);
  const credits = allCourses.reduce((s, c) => s + c.credits, 0);
  const cgpa = credits ? allCourses.reduce((s, c) => s + c.point * c.credits, 0) / credits : 0;
  const weekday = new Intl.DateTimeFormat("en-US", { weekday: "long", timeZone: "Asia/Dhaka" }).format(new Date());
  const dayIndex = demo.days.indexOf(weekday);
  const todays = demo.routine.filter((r) => r[0] === dayIndex).sort((a, b) => a[1] - b[1]);

  if (tab === "overview") {
    return (
      <>
        <DemoNote />
        <div className="grid gap-6 lg:grid-cols-[1.1fr_2fr]">
          <section className="relative overflow-hidden rounded-2xl bg-navy-900 p-6 text-white sm:p-8">
            <div className="weave absolute inset-0" aria-hidden="true" />
            <div className="relative">
              <span className="flex size-16 items-center justify-center rounded-full border border-gold-500/40 bg-navy-800 text-gold-300">
                <UserRound className="size-7" aria-hidden="true" />
              </span>
              <p className="mt-5 text-[0.7rem] font-semibold uppercase tracking-[0.2em] text-gold-300">Welcome back</p>
              <h1 className="mt-1 font-serif text-3xl leading-tight">{student.name}</h1>
              <dl className="mt-6 space-y-2.5 text-sm">
                {[
                  ["Student ID", student.identifier.toUpperCase()],
                  ["Department", student.department ? `${student.department.name} (${student.department.code})` : "Not assigned"],
                  ["Program", demo.profile.program],
                  ["Level / Term", `${demo.profile.level} · ${demo.profile.term}`],
                  ["Advisor", demo.profile.advisor],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-6 border-b border-white/10 pb-2.5 last:border-0">
                    <dt className="text-white/60">{k}</dt>
                    <dd className="text-right font-medium">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </section>

          <div className="space-y-6">
            <ul className="grid grid-cols-2 gap-4 xl:grid-cols-4">
              {[
                { label: "CGPA (demo)", value: cgpa.toFixed(2), go: "results" as TabId },
                { label: "Credits completed", value: String(credits), go: "results" as TabId },
                { label: "Upcoming exams", value: String(data.exams.length), go: "exams" as TabId },
                { label: "Academic notices", value: String(data.notices.length), go: "notices" as TabId },
              ].map((s) => (
                <li key={s.label}>
                  <button type="button" onClick={() => setTab(s.go)} className="w-full rounded-2xl border border-line bg-surface p-5 text-left transition hover:border-gold-500/60 hover:shadow-soft">
                    <span className="block font-serif text-4xl leading-none text-brand">{s.value}</span>
                    <span className="mt-3 block text-sm text-muted">{s.label}</span>
                  </button>
                </li>
              ))}
            </ul>

            <Panel
              title={`Today's classes · ${weekday}`}
              action={
                <button type="button" onClick={() => setTab("routine")} className="text-sm font-semibold text-accent hover:underline">
                  Full routine
                </button>
              }
            >
              {todays.length > 0 ? (
                <ul className="divide-y divide-line">
                  {todays.map((r) => (
                    <li key={`${r[0]}-${r[1]}`} className="flex flex-wrap items-center justify-between gap-3 py-3 first:pt-0 last:pb-0">
                      <span>
                        <span className="block font-semibold text-ink">{course(r[2])}</span>
                        <span className="text-sm text-muted">{r[2]}</span>
                      </span>
                      <span className="flex items-center gap-3 text-sm text-muted">
                        <Badge tone={r[3] === "Lab" ? "gold" : "neutral"}>{r[3]}</Badge>
                        <span className="tabular-nums">{demo.slots[r[1]]}</span>
                      </span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-muted">No classes are scheduled today. Classes run Sunday to Thursday.</p>
              )}
            </Panel>

            <Panel
              title="Latest academic notices"
              action={
                <button type="button" onClick={() => setTab("notices")} className="text-sm font-semibold text-accent hover:underline">
                  All notices
                </button>
              }
            >
              <NoticeList notices={data.notices.slice(0, 3)} />
            </Panel>
          </div>
        </div>
      </>
    );
  }

  if (tab === "calendar") {
    return (
      <Panel title="Academic calendar">
        <p className="mb-5 text-sm text-muted">Upcoming dates from the university calendar. These entries are live data from the public events calendar.</p>
        {data.calendar.length === 0 ? (
          <p className="text-sm text-muted">No upcoming dates have been published.</p>
        ) : (
          <ul className="divide-y divide-line">
            {data.calendar.map((e) => (
              <li key={e.id} className="flex flex-wrap items-center justify-between gap-3 py-3.5 first:pt-0 last:pb-0">
                <span className="min-w-0">
                  <span className="flex flex-wrap items-center gap-2 font-semibold text-ink">
                    {e.title}
                    {e.isSample && <SampleBadge />}
                  </span>
                  {e.location && <span className="text-sm text-muted">{e.location}</span>}
                </span>
                <span className="text-sm tabular-nums text-muted">
                  {fmtDate(e.startsAt)}
                  {hasTime(e.startsAt) ? `, ${fmtTime(e.startsAt)}` : ""}
                </span>
              </li>
            ))}
          </ul>
        )}
        <p className="mt-6">
          <Link href="/events" className="text-sm font-semibold text-accent hover:underline">
            Open the full events calendar
          </Link>
        </p>
      </Panel>
    );
  }

  if (tab === "routine") {
    return (
      <>
        <DemoNote />
        <Panel title={`Class routine · ${demo.profile.level}, ${demo.profile.term}`}>
          <div className="-mx-5 overflow-x-auto sm:-mx-6">
            <table className="w-full min-w-[46rem] border-collapse">
              <caption className="sr-only">Weekly class routine</caption>
              <thead>
                <tr className="border-b border-line bg-surface-2">
                  <th scope="col" className={TH}>Time</th>
                  {demo.days.map((d) => (
                    <th key={d} scope="col" className={`${TH} ${d === weekday ? "text-accent" : ""}`}>
                      {d}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {demo.slots.map((slot, si) => (
                  <tr key={slot}>
                    <th scope="row" className={`${TD} whitespace-nowrap font-medium tabular-nums text-muted`}>
                      {slot}
                    </th>
                    {demo.days.map((d, di) => {
                      const entry = demo.routine.find((r) => r[0] === di && r[1] === si);
                      return (
                        <td key={d} className={`${TD} ${d === weekday ? "bg-gold-500/[0.06]" : ""}`}>
                          {entry ? (
                            <div className={`rounded-lg border px-3 py-2 ${entry[3] === "Lab" ? "border-gold-500/40 bg-gold-500/10" : "border-line bg-bg"}`}>
                              <p className="text-xs font-bold tracking-wide text-accent">{entry[2]}</p>
                              <p className="mt-0.5 text-[0.8rem] leading-snug">{course(entry[2])}</p>
                              <p className="mt-1 text-[0.7rem] uppercase tracking-wider text-muted">{entry[3]}</p>
                            </div>
                          ) : (
                            <span className="text-muted/50" aria-label="No class">
                              —
                            </span>
                          )}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </>
    );
  }

  if (tab === "exams") {
    return (
      <>
        <DemoNote />
        <Panel title="Examination routine">
          <div className="-mx-5 overflow-x-auto sm:-mx-6">
            <table className="w-full min-w-[36rem]">
              <caption className="sr-only">Examination routine</caption>
              <thead>
                <tr className="border-b border-line bg-surface-2">
                  <th scope="col" className={TH}>Date</th>
                  <th scope="col" className={TH}>Course</th>
                  <th scope="col" className={TH}>Time</th>
                  <th scope="col" className={TH}>Room</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {data.exams.map((e) => (
                  <tr key={e.code}>
                    <td className={`${TD} whitespace-nowrap font-semibold`}>{fmtDate(e.date)}</td>
                    <td className={TD}>
                      <span className="block font-medium">{course(e.code)}</span>
                      <span className="text-xs text-muted">{e.code}</span>
                    </td>
                    <td className={`${TD} whitespace-nowrap tabular-nums`}>{e.time}</td>
                    <td className={`${TD} text-muted`}>{e.room}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </>
    );
  }

  if (tab === "results") {
    return (
      <>
        <DemoNote />
        <div className="mb-6 grid gap-4 sm:grid-cols-3">
          {[
            ["CGPA (demo)", cgpa.toFixed(2)],
            ["Credits completed", String(credits)],
            ["Terms completed", String(demo.results.length)],
          ].map(([k, v]) => (
            <div key={k} className="rounded-2xl border border-line bg-surface p-5">
              <p className="font-serif text-4xl leading-none text-brand">{v}</p>
              <p className="mt-3 text-sm text-muted">{k}</p>
            </div>
          ))}
        </div>
        <div className="space-y-6">
          {demo.results.map((r) => (
            <Panel key={r.term} title={r.term} action={<Badge tone="gold">GPA {r.gpa.toFixed(2)}</Badge>}>
              <div className="-mx-5 -my-5 overflow-x-auto sm:-mx-6 sm:-my-6">
                <table className="w-full min-w-[34rem]">
                  <caption className="sr-only">Results for {r.term}</caption>
                  <thead>
                    <tr className="border-b border-line bg-surface-2">
                      <th scope="col" className={TH}>Course</th>
                      <th scope="col" className={`${TH} text-right`}>Credits</th>
                      <th scope="col" className={`${TH} text-right`}>Grade</th>
                      <th scope="col" className={`${TH} text-right`}>Grade point</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-line">
                    {r.courses.map((c) => (
                      <tr key={c.code}>
                        <td className={TD}>
                          <span className="block font-medium">{c.title}</span>
                          <span className="text-xs text-muted">{c.code}</span>
                        </td>
                        <td className={`${TD} text-right tabular-nums`}>{c.credits}</td>
                        <td className={`${TD} text-right font-semibold`}>{c.grade}</td>
                        <td className={`${TD} text-right tabular-nums`}>{c.point.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>
          ))}
        </div>
      </>
    );
  }

  if (tab === "materials") {
    return (
      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="Course materials">
          <DemoNote>Lecture notes and slides will appear under each course once teachers upload them. The course list below is sample data.</DemoNote>
          <ul className="divide-y divide-line">
            {Object.entries(demo.courses).map(([code, c]) => (
              <li key={code} className="flex items-center justify-between gap-4 py-3.5 first:pt-0 last:pb-0">
                <span>
                  <span className="block font-medium text-ink">{c.title}</span>
                  <span className="text-xs text-muted">
                    {code} · {c.credits} credits
                  </span>
                </span>
                <span className="text-xs text-muted">No files yet</span>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel title="Academic documents">
          <p className="mb-4 text-sm text-muted">Downloads published by the university. These links are live.</p>
          {data.documents.length === 0 ? (
            <p className="text-sm text-muted">No documents have been published.</p>
          ) : (
            <ul className="divide-y divide-line">
              {data.documents.map((d) => (
                <li key={d.id} className="flex items-center justify-between gap-4 py-3.5 first:pt-0 last:pb-0">
                  <span className="min-w-0">
                    <span className="flex flex-wrap items-center gap-2 font-medium text-ink">
                      {d.title}
                      {d.isSample && <SampleBadge />}
                    </span>
                    <span className="text-xs text-muted">{d.category}</span>
                  </span>
                  {d.fileId ? (
                    <a href={`/api/files/${d.fileId}?download=1`} className="inline-flex shrink-0 items-center gap-1.5 rounded-full border border-line px-3.5 py-2 text-xs font-semibold text-brand transition hover:border-gold-500 hover:text-accent">
                      <Download className="size-3.5" aria-hidden="true" /> PDF
                    </a>
                  ) : (
                    <span className="text-xs text-muted">Pending</span>
                  )}
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    );
  }

  if (tab === "labs") {
    return (
      <>
        <DemoNote />
        <Panel title="Laboratory schedule">
          <div className="-mx-5 overflow-x-auto sm:-mx-6">
            <table className="w-full min-w-[36rem]">
              <caption className="sr-only">Laboratory schedule</caption>
              <thead>
                <tr className="border-b border-line bg-surface-2">
                  <th scope="col" className={TH}>Day</th>
                  <th scope="col" className={TH}>Time</th>
                  <th scope="col" className={TH}>Course</th>
                  <th scope="col" className={TH}>Laboratory</th>
                  <th scope="col" className={TH}>Group</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {demo.labs.map((l) => (
                  <tr key={`${l.day}-${l.code}`}>
                    <td className={`${TD} font-semibold`}>{l.day}</td>
                    <td className={`${TD} whitespace-nowrap tabular-nums`}>{l.time}</td>
                    <td className={TD}>
                      <span className="block font-medium">{course(l.code)}</span>
                      <span className="text-xs text-muted">{l.code}</span>
                    </td>
                    <td className={`${TD} text-muted`}>{l.lab}</td>
                    <td className={TD}>{l.group}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>
      </>
    );
  }

  return (
    <Panel title="Academic notices">
      <p className="mb-5 text-sm text-muted">Academic and examination notices from the public notice board. This list is live.</p>
      <NoticeList notices={data.notices} />
      <p className="mt-6">
        <Link href="/notices" className="text-sm font-semibold text-accent hover:underline">
          Open the notice board
        </Link>
      </p>
    </Panel>
  );
}

function NoticeList({ notices }: { notices: PortalData["notices"] }) {
  if (notices.length === 0) return <p className="text-sm text-muted">No academic notices have been published.</p>;
  return (
    <ul className="divide-y divide-line">
      {notices.map((n) => (
        <li key={n.id} className="flex flex-wrap items-center justify-between gap-3 py-3.5 first:pt-0 last:pb-0">
          <span className="min-w-0">
            <span className="flex flex-wrap items-center gap-2">
              <Badge tone="gold">{noticeCategory(n.category).en}</Badge>
              {n.isSample && <SampleBadge />}
            </span>
            <Link href={`/notices/${n.id}`} className="mt-1.5 block font-medium text-ink hover:text-accent">
              {n.title}
            </Link>
          </span>
          <span className="flex items-center gap-3 text-sm text-muted">
            <span className="tabular-nums">{fmtDate(n.publishedAt, "short")}</span>
            {n.fileId && (
              <a href={`/api/files/${n.fileId}`} target="_blank" rel="noopener" aria-label={`Open PDF for ${n.title}`} className="inline-flex items-center gap-1 rounded-full border border-line px-3 py-1.5 text-xs font-semibold text-brand hover:border-gold-500 hover:text-accent">
                <Download className="size-3.5" aria-hidden="true" /> PDF
              </a>
            )}
          </span>
        </li>
      ))}
    </ul>
  );
}
