import Image from "next/image";
import Link from "next/link";
import { ArrowRight, CalendarDays, MapPin, Pin } from "lucide-react";
import type { Department, EventItem, NewsItem, Notice } from "@/db/schema";
import { dateParts, fmtDate, fmtTime, hasTime } from "@/lib/format";
import { imageBySrc } from "@/lib/images";
import { noticeCategory } from "@/lib/site";
import { T } from "./t";
import { Badge, FileLink, SampleBadge } from "./ui";

export function DepartmentCard({ department: d }: { department: Department }) {
  const img = imageBySrc(d.image);
  return (
    <Link
      href={`/departments/${d.slug}`}
      className="group flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-surface transition duration-300 hover:-translate-y-1 hover:border-gold-500/60 hover:shadow-lift"
    >
      <div className="relative aspect-[16/10] overflow-hidden bg-navy-900">
        <Image src={img.src} alt={img.alt} fill sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw" className="object-cover transition duration-700 ease-out group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy-950/70 via-navy-950/10 to-transparent" aria-hidden="true" />
        <span className="absolute left-4 top-4 rounded-md bg-navy-950/85 px-2.5 py-1 text-xs font-bold tracking-[0.18em] text-gold-300 backdrop-blur-sm">{d.code}</span>
        {!img.butex && <span className="absolute bottom-2 right-3 text-[0.6rem] text-white/80">Illustrative image</span>}
      </div>
      <div className="flex flex-1 flex-col p-6">
        <h3 className="font-serif text-[1.35rem] leading-snug text-brand">
          <T en={d.name} bn={d.nameBn} />
        </h3>
        <p className="mt-2 flex-1 text-sm leading-relaxed text-muted">{d.tagline}</p>
        <span className="mt-5 inline-flex items-center gap-2 text-sm font-semibold text-accent">
          <T en="Explore department" bn="বিভাগ দেখুন" />
          <ArrowRight className="size-4 transition-transform duration-200 group-hover:translate-x-1" aria-hidden="true" />
        </span>
      </div>
    </Link>
  );
}

export function NoticeRow({ notice: n }: { notice: Notice }) {
  const date = dateParts(n.publishedAt);
  const category = noticeCategory(n.category);
  return (
    <li className="flex gap-4 py-5 sm:gap-6">
      <time dateTime={new Date(n.publishedAt).toISOString()} className="w-14 shrink-0 text-center sm:w-16">
        <span className="block font-serif text-3xl leading-none text-brand">{date.day}</span>
        <span className="mt-1.5 block text-[0.68rem] font-semibold uppercase tracking-[0.14em] text-accent">
          {date.month} {date.year}
        </span>
      </time>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <Badge tone="gold">
            <T en={category.en} bn={category.bn} />
          </Badge>
          {n.pinned && (
            <Badge tone="navy">
              <Pin className="mr-1 size-3" aria-hidden="true" />
              <T en="Pinned" bn="পিন করা" />
            </Badge>
          )}
          {n.isSample && <SampleBadge />}
        </div>
        <h3 className="mt-2 text-[1.05rem] font-semibold leading-snug text-ink">
          <Link href={`/notices/${n.id}`} className="transition hover:text-accent">
            {n.title}
          </Link>
        </h3>
        {n.summary && <p className="mt-1 line-clamp-2 text-sm leading-relaxed text-muted">{n.summary}</p>}
        {n.fileId && (
          <div className="mt-3 sm:hidden">
            <FileLink fileId={n.fileId} compact />
          </div>
        )}
      </div>
      {n.fileId && (
        <div className="hidden self-center sm:block">
          <FileLink fileId={n.fileId} fileName={n.fileName} compact />
        </div>
      )}
    </li>
  );
}

export function NewsCard({ item, priority = false }: { item: NewsItem; priority?: boolean }) {
  const img = imageBySrc(item.image);
  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-2xl border border-line bg-surface transition duration-300 hover:-translate-y-1 hover:shadow-lift">
      <div className="relative aspect-[16/10] overflow-hidden bg-navy-900">
        <Image src={img.src} alt={img.alt} fill priority={priority} sizes="(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw" className="object-cover transition duration-700 ease-out group-hover:scale-105" />
        {!img.butex && img.credit && <span className="absolute bottom-2 right-2 rounded bg-navy-950/65 px-1.5 py-0.5 text-[0.6rem] text-white/85">Illustrative image</span>}
      </div>
      <div className="flex flex-1 flex-col p-6">
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted">
          <time dateTime={new Date(item.publishedAt).toISOString()}>{fmtDate(item.publishedAt)}</time>
          {item.isSample && <SampleBadge />}
        </div>
        <h3 className="mt-3 font-serif text-xl leading-snug text-brand">
          <Link href={`/news/${item.slug}`} className="transition after:absolute after:inset-0 hover:text-accent">
            {item.title}
          </Link>
        </h3>
        <p className="mt-2 line-clamp-3 flex-1 text-sm leading-relaxed text-muted">{item.excerpt}</p>
      </div>
    </article>
  );
}

export function EventRow({ event: e }: { event: EventItem }) {
  const date = dateParts(e.startsAt);
  return (
    <li className="flex gap-4 rounded-xl border border-line bg-surface p-4 transition hover:border-gold-500/60">
      <time dateTime={new Date(e.startsAt).toISOString()} className="flex w-16 shrink-0 flex-col items-center justify-center rounded-lg bg-navy-900 py-2.5 text-white">
        <span className="text-[0.65rem] font-semibold uppercase tracking-[0.18em] text-gold-300">{date.month}</span>
        <span className="font-serif text-2xl leading-tight">{date.day}</span>
        <span className="text-[0.65rem] text-white/60">{date.year}</span>
      </time>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          {e.category === "national" && (
            <Badge>
              <T en="National observance" bn="জাতীয় দিবস" />
            </Badge>
          )}
          {e.isSample && <SampleBadge />}
        </div>
        <h3 className="mt-1.5 font-semibold leading-snug text-ink">{e.title}</h3>
        <p className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted">
          <span className="inline-flex items-center gap-1.5">
            <CalendarDays className="size-3.5 text-accent" aria-hidden="true" />
            {date.weekday}
            {hasTime(e.startsAt) ? `, ${fmtTime(e.startsAt)}` : ""}
            {e.endsAt ? ` – ${fmtDate(e.endsAt, "short")}` : ""}
          </span>
          {e.location && (
            <span className="inline-flex items-center gap-1.5">
              <MapPin className="size-3.5 text-accent" aria-hidden="true" />
              {e.location}
            </span>
          )}
        </p>
      </div>
    </li>
  );
}
