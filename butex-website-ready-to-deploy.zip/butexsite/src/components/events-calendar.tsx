"use client";

import { useMemo, useState } from "react";
import { CalendarDays, ChevronLeft, ChevronRight, MapPin } from "lucide-react";
import { dateKey, fmtDate, fmtTime, hasTime } from "@/lib/format";
import { EmptyState, SampleBadge } from "./ui";

export type CalendarEvent = {
  id: number;
  title: string;
  description: string;
  location: string;
  category: string;
  startsAt: string;
  endsAt: string | null;
  isSample: boolean;
};

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const pad = (n: number) => String(n).padStart(2, "0");
const monthFmt = new Intl.DateTimeFormat("en-GB", { month: "long", year: "numeric", timeZone: "UTC" });
const dayFmt = new Intl.DateTimeFormat("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" });
const keyToUtc = (key: string) => {
  const [y, m, d] = key.split("-").map(Number);
  return Date.UTC(y, m - 1, d);
};

function EventCard({ event: e }: { event: CalendarEvent }) {
  return (
    <li className="rounded-xl border border-line bg-surface p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className={`size-2 rounded-full ${e.category === "national" ? "bg-emerald-600" : "bg-gold-500"}`} aria-hidden="true" />
        <span className="text-[0.68rem] font-semibold uppercase tracking-[0.14em] text-muted">{e.category === "national" ? "National observance" : `${e.category} event`}</span>
        {e.isSample && <SampleBadge />}
      </div>
      <p className="mt-2 font-semibold leading-snug text-ink">{e.title}</p>
      <p className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted">
        <span className="inline-flex items-center gap-1.5">
          <CalendarDays className="size-3.5 text-accent" aria-hidden="true" />
          {fmtDate(e.startsAt, "short")}
          {hasTime(e.startsAt) ? `, ${fmtTime(e.startsAt)}` : ""}
          {e.endsAt ? ` – ${fmtDate(e.endsAt, "short")}` : ""}
        </span>
        {e.location && (
          <span className="inline-flex items-center gap-1.5">
            <MapPin className="size-3.5 text-accent" aria-hidden="true" />
            {e.location}
          </span>
        )}
      </p>
      {e.description && <p className="mt-2 text-sm leading-relaxed text-muted">{e.description}</p>}
    </li>
  );
}

export function EventsCalendar({ events, today }: { events: CalendarEvent[]; today: string }) {
  const [ty, tm] = today.split("-").map(Number);
  const [cursor, setCursor] = useState({ y: ty, m: tm });
  const [selected, setSelected] = useState(today);

  const byDay = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const e of events) {
      const start = keyToUtc(dateKey(e.startsAt));
      const end = e.endsAt ? Math.max(start, keyToUtc(dateKey(e.endsAt))) : start;
      for (let t = start, i = 0; t <= end && i < 62; t += 86_400_000, i++) {
        const key = new Date(t).toISOString().slice(0, 10);
        const list = map.get(key);
        if (list) list.push(e);
        else map.set(key, [e]);
      }
    }
    return map;
  }, [events]);

  const first = new Date(Date.UTC(cursor.y, cursor.m - 1, 1));
  const daysInMonth = new Date(Date.UTC(cursor.y, cursor.m, 0)).getUTCDate();
  const cells: (string | null)[] = [
    ...Array<null>(first.getUTCDay()).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => `${cursor.y}-${pad(cursor.m)}-${pad(i + 1)}`),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  const move = (delta: number) =>
    setCursor(({ y, m }) => {
      const d = new Date(Date.UTC(y, m - 1 + delta, 1));
      return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1 };
    });

  const selectedEvents = byDay.get(selected) ?? [];
  const upcoming = events.filter((e) => dateKey(e.endsAt ?? e.startsAt) >= today).slice(0, 8);

  return (
    <div className="grid gap-8 lg:grid-cols-[1.6fr_1fr]">
      <div>
        <div className="overflow-hidden rounded-2xl border border-line bg-surface">
          <div className="flex items-center justify-between gap-4 border-b border-line px-4 py-4 sm:px-6">
            <h2 className="font-serif text-2xl text-brand" aria-live="polite">
              {monthFmt.format(first)}
            </h2>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setCursor({ y: ty, m: tm });
                  setSelected(today);
                }}
                className="rounded-full border border-line px-4 py-2 text-xs font-semibold text-brand transition hover:border-gold-500 hover:text-accent"
              >
                Today
              </button>
              <button type="button" onClick={() => move(-1)} aria-label="Previous month" className="inline-flex size-9 items-center justify-center rounded-full border border-line text-brand transition hover:border-gold-500 hover:text-accent">
                <ChevronLeft className="size-4" aria-hidden="true" />
              </button>
              <button type="button" onClick={() => move(1)} aria-label="Next month" className="inline-flex size-9 items-center justify-center rounded-full border border-line text-brand transition hover:border-gold-500 hover:text-accent">
                <ChevronRight className="size-4" aria-hidden="true" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-7 border-b border-line bg-surface-2 text-center text-[0.68rem] font-semibold uppercase tracking-[0.14em] text-muted">
            {WEEKDAYS.map((d) => (
              <div key={d} className="py-2.5">
                {d}
              </div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-px bg-line">
            {cells.map((key, i) => {
              if (!key) return <div key={`blank-${i}`} className="min-h-14 bg-bg sm:min-h-24" />;
              const list = byDay.get(key) ?? [];
              const day = Number(key.slice(8));
              const isToday = key === today;
              const isSelected = key === selected;
              const weekend = i % 7 === 5 || i % 7 === 6;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setSelected(key)}
                  aria-pressed={isSelected}
                  aria-label={`${dayFmt.format(new Date(keyToUtc(key)))}${list.length ? `, ${list.length} event${list.length > 1 ? "s" : ""}` : ""}`}
                  className={`relative flex min-h-14 flex-col items-start gap-1 p-1.5 text-left transition sm:min-h-24 sm:p-2 ${
                    isSelected ? "bg-gold-500/15 ring-2 ring-inset ring-gold-500" : weekend ? "bg-bg hover:bg-surface-2" : "bg-surface hover:bg-surface-2"
                  }`}
                >
                  <span className={`inline-flex size-7 items-center justify-center rounded-full text-sm tabular-nums ${isToday ? "bg-navy-900 font-bold text-white dark:bg-gold-500 dark:text-navy-950" : "text-ink"}`}>{day}</span>
                  {list.slice(0, 2).map((e) => (
                    <span key={e.id} className="hidden w-full truncate rounded bg-navy-900/[0.07] px-1.5 py-0.5 text-[0.68rem] leading-tight text-ink sm:block dark:bg-white/10">
                      {e.title.replace(/^Sample event:\s*/i, "")}
                    </span>
                  ))}
                  {list.length > 2 && <span className="hidden text-[0.65rem] text-muted sm:block">+{list.length - 2} more</span>}
                  {list.length > 0 && (
                    <span className="flex gap-0.5 sm:hidden" aria-hidden="true">
                      {list.slice(0, 3).map((e) => (
                        <span key={e.id} className={`size-1.5 rounded-full ${e.category === "national" ? "bg-emerald-600" : "bg-gold-500"}`} />
                      ))}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
        <p className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted">
          <span className="inline-flex items-center gap-1.5">
            <span className="size-2 rounded-full bg-gold-500" aria-hidden="true" /> University event
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="size-2 rounded-full bg-emerald-600" aria-hidden="true" /> National observance
          </span>
          <span>Friday and Saturday are the weekend. Times are shown in Bangladesh Standard Time.</span>
        </p>
      </div>

      <div className="space-y-10">
        <section aria-live="polite">
          <h2 className="text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-accent">{dayFmt.format(new Date(keyToUtc(selected)))}</h2>
          {selectedEvents.length > 0 ? (
            <ul className="mt-3 space-y-3">
              {selectedEvents.map((e) => (
                <EventCard key={e.id} event={e} />
              ))}
            </ul>
          ) : (
            <p className="mt-3 rounded-xl border border-dashed border-line px-4 py-6 text-center text-sm text-muted">No events on this day. Select a highlighted date to see details.</p>
          )}
        </section>

        <section>
          <h2 className="text-[0.72rem] font-semibold uppercase tracking-[0.2em] text-accent">Upcoming</h2>
          {upcoming.length > 0 ? (
            <ul className="mt-3 space-y-3">
              {upcoming.map((e) => (
                <EventCard key={e.id} event={e} />
              ))}
            </ul>
          ) : (
            <div className="mt-3">
              <EmptyState title="No upcoming events.">New events appear here when they are published.</EmptyState>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
