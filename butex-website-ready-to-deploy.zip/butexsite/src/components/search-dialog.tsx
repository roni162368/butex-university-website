"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { ArrowRight, CornerDownLeft, Search, X } from "lucide-react";
import { api, useLang } from "@/lib/client";

type Result = { type: string; title: string; href: string; snippet: string };
type State = { status: "idle" | "loading" | "done" | "error"; results: Result[] };

const QUICK_LINKS = [
  { label: "Admission information", href: "/admission" },
  { label: "Notice board", href: "/notices" },
  { label: "Academic departments", href: "/departments" },
  { label: "Faculty directory", href: "/faculty" },
  { label: "Student portal", href: "/portal" },
];

export function SearchDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const lang = useLang();
  const [query, setQuery] = useState("");
  const [state, setState] = useState<State>({ status: "idle", results: [] });

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open && !dialog.open) {
      dialog.showModal();
      inputRef.current?.focus();
    } else if (!open && dialog.open) {
      dialog.close();
    }
  }, [open]);

  const onQueryChange = (value: string) => {
    setQuery(value);
    setState((s) => (value.trim().length < 2 ? { status: "idle", results: [] } : { status: "loading", results: s.results }));
  };

  useEffect(() => {
    const term = query.trim();
    if (term.length < 2) return;
    const controller = new AbortController();
    const timer = setTimeout(async () => {
      try {
        const data = await api<{ results: Result[] }>(`/api/search?q=${encodeURIComponent(term)}`, { signal: controller.signal });
        setState({ status: "done", results: data.results });
      } catch (err) {
        if (err instanceof DOMException && err.name === "AbortError") return;
        setState({ status: "error", results: [] });
      }
    }, 220);
    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [query]);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    const term = query.trim();
    if (!term) return;
    onClose();
    router.push(`/search?q=${encodeURIComponent(term)}`);
  };

  const groups = state.results.reduce<Record<string, Result[]>>((acc, r) => {
    (acc[r.type] ??= []).push(r);
    return acc;
  }, {});

  return (
    <dialog
      ref={dialogRef}
      onClose={onClose}
      onClick={(e) => {
        if (e.target === dialogRef.current) onClose();
      }}
      aria-label="Search the BUTEX website"
      className="m-0 mx-auto mt-[9vh] max-h-[80vh] w-[calc(100%-2rem)] max-w-2xl overflow-hidden rounded-2xl border border-line bg-surface p-0 text-ink shadow-lift"
    >
      <form onSubmit={submit} role="search" className="flex items-center gap-3 border-b border-line px-5">
        <Search className="size-5 shrink-0 text-accent" aria-hidden="true" />
        <input
          ref={inputRef}
          type="search"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          placeholder={lang === "bn" ? "বিভাগ, নোটিশ, শিক্ষক খুঁজুন…" : "Search departments, notices, faculty…"}
          aria-label="Search"
          autoComplete="off"
          className="h-16 w-full bg-transparent text-lg text-ink outline-none placeholder:text-muted/70 [&::-webkit-search-cancel-button]:hidden"
        />
        <button type="button" onClick={onClose} aria-label="Close search" className="rounded-full p-2 text-muted transition hover:bg-surface-2 hover:text-brand">
          <X className="size-5" aria-hidden="true" />
        </button>
      </form>

      <div className="max-h-[calc(80vh-8.5rem)] overflow-y-auto px-3 py-3" aria-live="polite">
        {state.status === "idle" && (
          <div className="px-2 pb-2">
            <p className="px-2 pb-2 pt-1 text-[0.7rem] font-semibold uppercase tracking-[0.2em] text-muted">Popular destinations</p>
            <ul>
              {QUICK_LINKS.map((l) => (
                <li key={l.href}>
                  <Link href={l.href} onClick={onClose} className="group flex items-center justify-between rounded-lg px-3 py-2.5 text-[0.95rem] text-ink transition hover:bg-surface-2">
                    {l.label}
                    <ArrowRight className="size-4 text-muted transition group-hover:translate-x-0.5 group-hover:text-accent" aria-hidden="true" />
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}

        {state.status === "loading" && state.results.length === 0 && (
          <div className="space-y-3 p-3" role="status" aria-label="Searching">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="space-y-2">
                <div className="skeleton h-4 w-2/3" />
                <div className="skeleton h-3 w-1/2" />
              </div>
            ))}
          </div>
        )}

        {state.status === "error" && (
          <p className="p-4 text-sm text-muted" role="alert">
            Search is unavailable right now. Please try again in a moment.
          </p>
        )}

        {state.status === "done" && state.results.length === 0 && (
          <div className="p-4">
            <p className="font-medium text-ink">No results for “{query.trim()}”.</p>
            <p className="mt-1 text-sm text-muted">Check the spelling, or try a broader term such as a department name or notice category.</p>
          </div>
        )}

        {state.results.length > 0 &&
          Object.entries(groups).map(([type, items]) => (
            <section key={type} className="mb-2">
              <h3 className="px-4 pb-1 pt-2 text-[0.7rem] font-semibold uppercase tracking-[0.2em] text-muted">{type}</h3>
              <ul>
                {items.map((r) => (
                  <li key={`${r.type}-${r.href}-${r.title}`}>
                    <Link href={r.href} onClick={onClose} className="block rounded-lg px-4 py-2.5 transition hover:bg-surface-2 focus-visible:bg-surface-2">
                      <span className="block text-[0.95rem] font-medium text-ink">{r.title}</span>
                      {r.snippet && <span className="mt-0.5 block truncate text-sm text-muted">{r.snippet}</span>}
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          ))}
      </div>

      <div className="flex items-center justify-between border-t border-line bg-bg px-5 py-3 text-xs text-muted">
        <span className="inline-flex items-center gap-1.5">
          <CornerDownLeft className="size-3.5" aria-hidden="true" /> Press Enter to see all results
        </span>
        <span>
          <kbd className="rounded border border-line bg-surface px-1.5 py-0.5 font-sans">Esc</kbd> to close
        </span>
      </div>
    </dialog>
  );
}
