/**
 * Stand-in emblem: a plain 2×2 weave on navy. Replace with the official
 * university crest when the artwork is supplied.
 */
export function Emblem({ className = "size-11" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" className={className} aria-hidden="true" focusable="false">
      <rect width="48" height="48" rx="11" fill="#0a1b36" />
      <rect x="1" y="1" width="46" height="46" rx="10" fill="none" stroke="#c19a45" strokeOpacity="0.55" />
      {/* weft */}
      <rect x="9" y="15.5" width="30" height="6" rx="1.2" fill="#ffffff" />
      <rect x="9" y="26.5" width="30" height="6" rx="1.2" fill="#ffffff" />
      {/* warp */}
      <rect x="15.5" y="9" width="6" height="30" rx="1.2" fill="#d4b872" />
      <rect x="26.5" y="9" width="6" height="30" rx="1.2" fill="#d4b872" />
      {/* over-under crossings */}
      <rect x="13.5" y="15.5" width="10" height="6" fill="#ffffff" />
      <rect x="24.5" y="26.5" width="10" height="6" fill="#ffffff" />
    </svg>
  );
}
