"use client";

import { useState, type FormEvent } from "react";
import { CheckCircle2, Loader2, Send } from "lucide-react";
import { ApiError, api } from "@/lib/client";

type Fields = { name: string; email: string; subject: string; message: string; website: string };
const EMPTY: Fields = { name: "", email: "", subject: "", message: "", website: "" };

function check(f: Fields): Record<string, string> {
  const errors: Record<string, string> = {};
  if (f.name.trim().length < 2) errors.name = "Enter your full name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email.trim())) errors.email = "Enter a valid email address, for example name@example.com.";
  if (f.message.trim().length < 10) errors.message = "Write a message of at least 10 characters.";
  return errors;
}

export function ContactForm() {
  const [fields, setFields] = useState<Fields>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const [formError, setFormError] = useState("");

  const set = (key: keyof Fields) => (e: { target: { value: string } }) => {
    setFields((f) => ({ ...f, [key]: e.target.value }));
    if (errors[key]) setErrors((x) => ({ ...x, [key]: "" }));
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const found = check(fields);
    setErrors(found);
    setFormError("");
    if (Object.keys(found).length > 0) {
      const firstKey = Object.keys(found)[0];
      document.getElementById(`contact-${firstKey}`)?.focus();
      return;
    }
    setStatus("sending");
    try {
      await api("/api/contact", { json: fields });
      setStatus("sent");
      setFields(EMPTY);
    } catch (err) {
      setStatus("idle");
      if (err instanceof ApiError) {
        setErrors(err.fields);
        setFormError(err.message);
      } else {
        setFormError("Your message could not be sent. Please try again.");
      }
    }
  };

  if (status === "sent") {
    return (
      <div role="status" className="rounded-2xl border border-line bg-surface p-8 text-center">
        <CheckCircle2 className="mx-auto size-12 text-emerald-600" aria-hidden="true" />
        <h3 className="mt-4 font-serif text-2xl text-brand">Message received</h3>
        <p className="mx-auto mt-2 max-w-sm leading-relaxed text-muted">Thank you. Your message has been recorded and will be reviewed by the university office.</p>
        <button type="button" onClick={() => setStatus("idle")} className="mt-6 rounded-full border border-line px-5 py-2.5 text-sm font-semibold text-brand transition hover:border-gold-500 hover:text-accent">
          Send another message
        </button>
      </div>
    );
  }

  const input = (key: "name" | "email" | "subject", label: string, type = "text", required = true, autoComplete?: string) => (
    <div>
      <label htmlFor={`contact-${key}`} className="mb-1.5 block text-sm font-semibold text-ink">
        {label} {!required && <span className="font-normal text-muted">(optional)</span>}
      </label>
      <input
        id={`contact-${key}`}
        type={type}
        value={fields[key]}
        onChange={set(key)}
        autoComplete={autoComplete}
        maxLength={200}
        aria-invalid={errors[key] ? "true" : undefined}
        aria-describedby={errors[key] ? `contact-${key}-error` : undefined}
        className="field"
      />
      {errors[key] && (
        <p id={`contact-${key}-error`} className="mt-1.5 text-sm text-orange-700 dark:text-orange-400">
          {errors[key]}
        </p>
      )}
    </div>
  );

  return (
    <form onSubmit={submit} noValidate className="space-y-5 rounded-2xl border border-line bg-surface p-6 sm:p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        {input("name", "Full name", "text", true, "name")}
        {input("email", "Email address", "email", true, "email")}
      </div>
      {input("subject", "Subject", "text", false)}
      <div>
        <label htmlFor="contact-message" className="mb-1.5 block text-sm font-semibold text-ink">
          Message
        </label>
        <textarea
          id="contact-message"
          rows={6}
          value={fields.message}
          onChange={set("message")}
          maxLength={4000}
          aria-invalid={errors.message ? "true" : undefined}
          aria-describedby={errors.message ? "contact-message-error" : undefined}
          className="field resize-y"
        />
        {errors.message && (
          <p id="contact-message-error" className="mt-1.5 text-sm text-orange-700 dark:text-orange-400">
            {errors.message}
          </p>
        )}
      </div>
      {/* Honeypot: hidden from people, tempting to bots. */}
      <div className="hidden" aria-hidden="true">
        <label htmlFor="contact-website">Website</label>
        <input id="contact-website" type="text" tabIndex={-1} autoComplete="off" value={fields.website} onChange={set("website")} />
      </div>
      {formError && (
        <p role="alert" className="rounded-lg border border-orange-700/30 bg-orange-500/10 px-4 py-3 text-sm text-orange-800 dark:text-orange-300">
          {formError}
        </p>
      )}
      <button
        type="submit"
        disabled={status === "sending"}
        className="inline-flex items-center justify-center gap-2 rounded-full bg-navy-900 px-7 py-3 text-sm font-semibold text-white transition hover:bg-navy-700 disabled:opacity-70 dark:bg-gold-500 dark:text-navy-950 dark:hover:bg-gold-400"
      >
        {status === "sending" ? <Loader2 className="size-4 animate-spin" aria-hidden="true" /> : <Send className="size-4" aria-hidden="true" />}
        {status === "sending" ? "Sending…" : "Send message"}
      </button>
    </form>
  );
}
